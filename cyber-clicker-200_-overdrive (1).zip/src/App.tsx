import React, { useCallback, useEffect, useRef, useState } from 'react';
import { DopamineLayer } from './components/DopamineLayer';
import { Drawer } from './components/Drawer';
import { MediaModal } from './components/MediaModal';
import { MinigameModal, MinigameModalMode } from './components/MinigameModal';
import { UnboxModal } from './components/UnboxModal';
import {
  createDefaultState,
  DOPAMINE_CATALOG,
  DOPAMINE_CHEST_TIERS,
  formatNumber,
  getClickStats,
  getCurrentRank,
  getEnergyForLevel,
  getPassiveCPS,
  getRebirthMultiplier,
  getRelicBonuses,
  getUnlockedSlotCount,
  getUpgradeCost,
  loadGameState,
  MAX_LEVEL,
  MINIGAMES_CATALOG,
  RELICS_CATALOG,
  saveGameState,
  SKINS_CATALOG,
  TIERS,
  UPGRADES_CATALOG,
} from './game/catalogs';
import { sfx } from './game/sound';
import {
  DrawerTab,
  GameState,
  Mission,
  MissionType,
  ToastItem,
  ToastTheme,
  UnboxState,
  UpgradeKey,
} from './game/types';

interface TargetMotion {
  posX: number;
  posY: number;
  dirX: number;
  dirY: number;
}

interface BgStar {
  x: number;
  y: number;
  r: number;
  vy: number;
  alpha: number;
}

interface ClickParticle {
  x: number;
  y: number;
  vx: number;
  vy: number;
  life: number;
  decay: number;
  size: number;
  color: string;
}

function generateDynamicMission(level: number, counter: number): Mission {
  const types: MissionType[] = ['clicks', 'crits', 'combo', 'energy'];
  const type = types[counter % types.length];
  const scale = Math.max(1, Math.floor(level / 4) + 1);
  const id = `m_${Date.now()}_${counter}`;

  if (type === 'clicks') {
    const target = 25 + scale * 15;
    return {
      id,
      type,
      title: `Haz ${target} clicks en tus objetivos`,
      target,
      progress: 0,
      isThreshold: false,
      rewardGems: 5 + Math.floor(scale * 1.5),
      completed: false,
    };
  }
  if (type === 'crits') {
    const target = 4 + Math.floor(scale * 1.5);
    return {
      id,
      type,
      title: `Consigue ${target} Golpes Críticos`,
      target,
      progress: 0,
      isThreshold: false,
      rewardGems: 7 + Math.floor(scale * 2),
      completed: false,
    };
  }
  if (type === 'combo') {
    const target = +(2.0 + Math.min(4.0, scale * 0.25)).toFixed(1);
    return {
      id,
      type,
      title: `Alcanza una Racha de x${target}`,
      target,
      progress: 1.0,
      isThreshold: true,
      rewardGems: 8 + Math.floor(scale * 2),
      completed: false,
    };
  }
  const target = Math.floor(150 * Math.pow(1.24, Math.min(35, scale)));
  return {
    id,
    type,
    title: `Genera ${formatNumber(target)} de Energía`,
    target,
    progress: 0,
    isThreshold: false,
    rewardGems: 6 + Math.floor(scale * 2),
    completed: false,
  };
}

function ensureMissionsList(
  missions: Mission[],
  level: number,
  counter: number,
): { missions: Mission[]; counter: number } {
  const next = [...missions];
  let c = counter;
  while (next.length < 3) {
    c += 1;
    next.push(generateDynamicMission(level, c));
  }
  return { missions: next, counter: c };
}

function advanceMissions(
  missions: Mission[],
  type: MissionType,
  amount: number,
  thresholdVal = 0,
): Mission[] {
  let changed = false;
  const next = missions.map((m) => {
    if (m.completed || m.type !== type) return m;
    changed = true;
    const progress = m.isThreshold
      ? Math.max(m.progress, thresholdVal)
      : m.progress + amount;
    const completed = progress >= m.target;
    return { ...m, progress, completed };
  });
  return changed ? next : missions;
}

export default function App() {
  const [gameState, setGameState] = useState<GameState>(() => {
    const loaded = loadGameState();
    const ensured = ensureMissionsList(
      loaded.missions,
      loaded.level,
      loaded.missionCounter,
    );
    return {
      ...loaded,
      missions: ensured.missions,
      missionCounter: ensured.counter,
    };
  });

  const [drawerOpen, setDrawerOpen] = useState(false);
  const [activeTab, setActiveTab] = useState<DrawerTab>('upgrades');
  const [mediaModalOpen, setMediaModalOpen] = useState(false);
  const [minigameMode, setMinigameMode] = useState<MinigameModalMode>({
    view: 'closed',
  });
  const [unbox, setUnbox] = useState<UnboxState | null>(null);
  const [toasts, setToasts] = useState<ToastItem[]>([]);
  const [muted, setMuted] = useState(false);
  const [shaking, setShaking] = useState(false);
  const [comboUI, setComboUI] = useState<{ mult: number; pct: number }>({
    mult: 1.0,
    pct: 0,
  });
  const [antiCheatOverlay, setAntiCheatOverlay] = useState<{
    active: boolean;
    reason: string;
    remSec: number;
  }>({ active: false, reason: '', remSec: 0 });
  const [primaryAvatarMedia, setPrimaryAvatarMedia] = useState<
    HTMLImageElement | HTMLVideoElement | null
  >(null);
  const [bombTestNonce, setBombTestNonce] = useState(0);
  const [photoTestNonce, setPhotoTestNonce] = useState(0);
  const [bombCountdownSec, setBombCountdownSec] = useState(120);
  const [photoCountdownSec, setPhotoCountdownSec] = useState(300);

  // Refs synced for 60fps loops
  const stateRef = useRef<GameState>(gameState);
  stateRef.current = gameState;

  const minigameModeRef = useRef<MinigameModalMode>(minigameMode);
  minigameModeRef.current = minigameMode;

  const unboxRef = useRef<UnboxState | null>(unbox);
  unboxRef.current = unbox;

  const pendingMinigameQueueRef = useRef<number[]>([]);
  const slotRefs = useRef<(HTMLDivElement | null)[]>([]);
  const slotVideoRefs = useRef<(HTMLVideoElement | null)[]>([]);
  const targetMotionsRef = useRef<TargetMotion[]>([]);
  const bgCanvasRef = useRef<HTMLCanvasElement | null>(null);
  const particlesRef = useRef<ClickParticle[]>([]);
  const starsRef = useRef<BgStar[]>([]);

  const comboMultRef = useRef(1.0);
  const comboTimerRef = useRef(0);
  const antiCheatRef = useRef<{
    timestamps: number[];
    coords: { x: number; y: number }[];
    lockedUntil: number;
  }>({ timestamps: [], coords: [], lockedUntil: 0 });

  const showToast = useCallback(
    (title: string, subtitle: string, theme: ToastTheme = 'cyan') => {
      const id = `${Date.now()}_${Math.random().toString(36).slice(2, 7)}`;
      setToasts((prev) => [...prev.slice(-3), { id, title, subtitle, theme }]);
      window.setTimeout(() => {
        setToasts((prev) => prev.filter((t) => t.id !== id));
      }, 4200);
    },
    [],
  );

  // Sync primary avatar media element (image, gif, or video) for minigame canvases
  useEffect(() => {
    const slot0 = gameState.slotMedia[0];
    if (!slot0 || slot0.type === 'default' || !slot0.src) {
      setPrimaryAvatarMedia(null);
      return;
    }
    if (slot0.type === 'video') {
      const vidEl = slotVideoRefs.current[0];
      setPrimaryAvatarMedia(vidEl || null);
      return;
    }
    const img = new Image();
    img.onload = () => setPrimaryAvatarMedia(img);
    img.onerror = () => setPrimaryAvatarMedia(null);
    img.src = slot0.src;
  }, [gameState.slotMedia]);

  // Apply level-ups cleanly across arbitrary energy jumps & queue all crossed % 10 minigames
  const applyEnergyAndLevelUp = useCallback(
    (
      draft: GameState,
      energyDelta: number,
      toastFn: (title: string, subtitle: string, theme: ToastTheme) => void,
    ): { nextState: GameState; newlyQueuedLvls: number[] } => {
      const nextEnergy = draft.energy + energyDelta;
      const nextTotal = draft.totalEnergyEarned + energyDelta;
      let missions = advanceMissions(draft.missions, 'energy', energyDelta);

      let newLvl = draft.level;
      while (
        newLvl < MAX_LEVEL &&
        nextTotal >= getEnergyForLevel(newLvl + 1)
      ) {
        newLvl++;
      }

      const newlyQueuedLvls: number[] = [];
      let gems = draft.gems;
      let triggered = draft.triggeredMinigameLevels;

      if (newLvl > draft.level) {
        const prevLvl = draft.level;
        const gemMult = 1 + getRelicBonuses(draft.relics).gemMult;
        const gemsEarned = Math.ceil(
          ((newLvl - prevLvl) * 3 + Math.floor(newLvl / 5)) * gemMult,
        );
        gems += gemsEarned;
        sfx.playLevelUp();
        toastFn(
          `⬆️ ¡NIVEL ${newLvl}!`,
          `Rango: ${getCurrentRank(newLvl).name} • +${gemsEarned} 💎`,
          'cyan',
        );

        const nextTriggered = [...triggered];
        for (let m = prevLvl + 1; m <= newLvl; m++) {
          if (m % 10 === 0 && !nextTriggered.includes(m)) {
            nextTriggered.push(m);
            newlyQueuedLvls.push(m);
          }
        }
        triggered = nextTriggered;
      }

      const ensured = ensureMissionsList(missions, newLvl, draft.missionCounter);
      missions = ensured.missions;

      return {
        nextState: {
          ...draft,
          energy: nextEnergy,
          totalEnergyEarned: nextTotal,
          level: newLvl,
          gems,
          triggeredMinigameLevels: triggered,
          missions,
          missionCounter: ensured.counter,
        },
        newlyQueuedLvls,
      };
    },
    [],
  );

  const enqueueMinigames = useCallback((lvls: number[]) => {
    if (lvls.length === 0) return;
    pendingMinigameQueueRef.current.push(...lvls);
    if (minigameModeRef.current.view === 'closed') {
      const nextLvl = pendingMinigameQueueRef.current.shift();
      if (nextLvl !== undefined) {
        setMinigameMode({ view: 'play', lvl: nextLvl, isPractice: false });
      }
    }
  }, []);

  // Ensure target motion array matches unlocked slots without resetting existing positions
  const unlockedSlots = getUnlockedSlotCount(gameState.rebirths);
  const targetSize = 112 + gameState.upgrades.magnetSize * 4;

  useEffect(() => {
    const w = window.innerWidth;
    const h = window.innerHeight;
    const arr = targetMotionsRef.current;
    while (arr.length < unlockedSlots) {
      const i = arr.length;
      const spd = 2.0 + i * 0.25;
      arr.push({
        posX: Math.max(
          20,
          Math.min(w - targetSize - 20, w * (0.25 + i * 0.16)),
        ),
        posY: Math.max(
          95,
          Math.min(h - targetSize - 20, h * (0.35 + (i % 2) * 0.15)),
        ),
        dirX: (i % 2 === 0 ? 1 : -1) * spd,
        dirY: (i < 2 ? 1 : -1) * (spd * 0.85),
      });
    }
    if (arr.length > unlockedSlots) {
      arr.length = unlockedSlots;
    }
  }, [unlockedSlots, targetSize]);

  // Background canvas resize & target position clamping
  useEffect(() => {
    const handleResize = () => {
      const c = bgCanvasRef.current;
      if (c) {
        c.width = window.innerWidth;
        c.height = window.innerHeight;
        starsRef.current = Array.from({ length: 65 }, () => ({
          x: Math.random() * c.width,
          y: Math.random() * c.height,
          r: Math.random() * 1.6 + 0.4,
          vy: Math.random() * 0.25 + 0.08,
          alpha: Math.random() * 0.6 + 0.2,
        }));
      }
      const curSize = 112 + stateRef.current.upgrades.magnetSize * 4;
      const maxX = Math.max(20, window.innerWidth - curSize - 10);
      const maxY = Math.max(95, window.innerHeight - curSize - 10);
      for (const m of targetMotionsRef.current) {
        m.posX = Math.max(10, Math.min(maxX, m.posX));
        m.posY = Math.max(90, Math.min(maxY, m.posY));
      }
    };

    handleResize();
    window.addEventListener('resize', handleResize);
    return () => window.removeEventListener('resize', handleResize);
  }, []);

  // Main 60fps loop: background starfield, particles, bouncing targets, passive CPS, combo decay, autosave
  useEffect(() => {
    let lastTime = performance.now();
    let passiveAcc = 0;
    let saveAcc = 0;
    let hudComboTick = 0;
    let rafId = 0;

    const tick = (now: number) => {
      const dt = Math.min(0.1, (now - lastTime) / 1000);
      lastTime = now;

      const st = stateRef.current;
      const isModalOpen =
        minigameModeRef.current.view !== 'closed' || unboxRef.current !== null;

      // Update background canvas
      const bg = bgCanvasRef.current;
      const bctx = bg?.getContext('2d');
      if (bg && bctx) {
        bctx.clearRect(0, 0, bg.width, bg.height);
        for (const s of starsRef.current) {
          s.y += s.vy;
          if (s.y > bg.height) {
            s.y = 0;
            s.x = Math.random() * bg.width;
          }
          bctx.fillStyle = `rgba(0, 243, 255, ${s.alpha})`;
          bctx.beginPath();
          bctx.arc(s.x, s.y, s.r, 0, Math.PI * 2);
          bctx.fill();
        }
        const parts = particlesRef.current;
        for (let i = parts.length - 1; i >= 0; i--) {
          const p = parts[i];
          p.x += p.vx;
          p.y += p.vy;
          p.vy += 0.08;
          p.life -= p.decay;
          if (p.life <= 0) {
            parts.splice(i, 1);
            continue;
          }
          bctx.globalAlpha = p.life;
          bctx.fillStyle = p.color;
          bctx.beginPath();
          bctx.arc(p.x, p.y, p.size, 0, Math.PI * 2);
          bctx.fill();
        }
        bctx.globalAlpha = 1;
      }

      // Move floating targets when no blocking modal is open
      if (!isModalOpen) {
        const curSize = 112 + st.upgrades.magnetSize * 4;
        const speedBase =
          (1 + st.level * 0.011) *
          (st.stabilizer ? 0.85 : 1.0) *
          Math.max(0.45, 1 - st.upgrades.magnetSize * 0.032);
        const w = window.innerWidth;
        const h = window.innerHeight;
        const motions = targetMotionsRef.current;
        for (let i = 0; i < motions.length; i++) {
          const m = motions[i];
          m.posX += m.dirX * speedBase * (dt * 60);
          m.posY += m.dirY * speedBase * (dt * 60);
          if (m.posX <= 10) {
            m.posX = 10;
            m.dirX = Math.abs(m.dirX);
          }
          if (m.posX >= w - curSize - 10) {
            m.posX = Math.max(10, w - curSize - 10);
            m.dirX = -Math.abs(m.dirX);
          }
          if (m.posY <= 90) {
            m.posY = 90;
            m.dirY = Math.abs(m.dirY);
          }
          if (m.posY >= h - curSize - 10) {
            m.posY = Math.max(90, h - curSize - 10);
            m.dirY = -Math.abs(m.dirY);
          }
          const el = slotRefs.current[i];
          if (el) {
            el.style.left = `${m.posX}px`;
            el.style.top = `${m.posY}px`;
          }
        }
      }

      // Passive CPS accumulation (pausado mientras se juega un minijuego para no subir nivel en ausencia)
      const isPlayingMinigame = minigameModeRef.current.view === 'play';
      if (isPlayingMinigame) {
        passiveAcc = 0;
      } else {
        const cps = getPassiveCPS(st);
        if (cps > 0) {
          passiveAcc += cps * dt;
          if (passiveAcc >= 1) {
            const whole = Math.floor(passiveAcc);
            passiveAcc -= whole;
            setGameState((prev) => {
              const res = applyEnergyAndLevelUp(prev, whole, showToast);
              if (res.newlyQueuedLvls.length > 0) {
                queueMicrotask(() => enqueueMinigames(res.newlyQueuedLvls));
              }
              return res.nextState;
            });
          }
        }

        // Combo decay
        if (comboTimerRef.current > 0) {
          comboTimerRef.current -= dt;
          if (comboTimerRef.current <= 0) {
            comboTimerRef.current = 0;
            comboMultRef.current = 1.0;
            setComboUI({ mult: 1.0, pct: 0 });
          } else {
            hudComboTick += dt;
            if (hudComboTick >= 0.08) {
              hudComboTick = 0;
              const maxT = 2.2 + st.upgrades.comboMaster * 0.12;
              setComboUI({
                mult: comboMultRef.current,
                pct: Math.min(100, (comboTimerRef.current / maxT) * 100),
              });
            }
          }
        }
      }

      // Anti-cheat overlay timer
      if (antiCheatRef.current.lockedUntil > now) {
        const remSec = Math.max(0, (antiCheatRef.current.lockedUntil - now) / 1000);
        setAntiCheatOverlay((prev) =>
          prev.active ? { ...prev, remSec } : prev,
        );
      } else if (antiCheatRef.current.lockedUntil > 0) {
        antiCheatRef.current.lockedUntil = 0;
        setAntiCheatOverlay({ active: false, reason: '', remSec: 0 });
      }

      // Autosave every 4s
      saveAcc += dt;
      if (saveAcc >= 4) {
        saveAcc = 0;
        saveGameState(stateRef.current);
      }

      rafId = requestAnimationFrame(tick);
    };

    rafId = requestAnimationFrame(tick);
    return () => cancelAnimationFrame(rafId);
  }, [applyEnergyAndLevelUp, enqueueMinigames, showToast]);

  // Save before unload
  useEffect(() => {
    const onBeforeUnload = () => saveGameState(stateRef.current);
    window.addEventListener('beforeunload', onBeforeUnload);
    return () => window.removeEventListener('beforeunload', onBeforeUnload);
  }, []);

  const triggerLockout = useCallback((reason: string) => {
    const ac = antiCheatRef.current;
    ac.timestamps = [];
    ac.coords = [];
    ac.lockedUntil = performance.now() + 8000;
    comboMultRef.current = 1.0;
    comboTimerRef.current = 0;
    setComboUI({ mult: 1.0, pct: 0 });
    sfx.playAlert();
    setAntiCheatOverlay({ active: true, reason, remSec: 8.0 });
    setGameState((prev) => {
      const next = {
        ...prev,
        stats: {
          ...prev.stats,
          anticheatInfractions: prev.stats.anticheatInfractions + 1,
        },
      };
      saveGameState(next);
      return next;
    });
  }, []);

  const registerAntiCheatClick = useCallback(
    (
      isTrusted: boolean,
      x: number,
      y: number,
      allowStaticCoords = false,
    ): boolean => {
      const now = performance.now();
      const ac = antiCheatRef.current;
      if (now < ac.lockedUntil) return false;

      if (!isTrusted) {
        triggerLockout('Click sintético / automatizado detectado.');
        return false;
      }

      ac.timestamps.push(now);
      ac.coords.push({ x: Math.round(x), y: Math.round(y) });
      if (ac.timestamps.length > 18) {
        ac.timestamps.shift();
        ac.coords.shift();
      }

      const recent1Sec = ac.timestamps.filter((t) => now - t <= 1000);
      if (recent1Sec.length >= 18) {
        triggerLockout('Cadencia sobrehumana (>18 clicks/seg sostenidos).');
        return false;
      }

      if (ac.timestamps.length >= 12) {
        const last12 = ac.timestamps.slice(-12);
        const intervals: number[] = [];
        for (let i = 1; i < last12.length; i++) {
          intervals.push(last12[i] - last12[i - 1]);
        }
        const mean = intervals.reduce((a, b) => a + b, 0) / intervals.length;
        const stdDev = Math.sqrt(
          intervals.reduce((a, b) => a + Math.pow(b - mean, 2), 0) /
            intervals.length,
        );
        if (mean < 140 && stdDev < 2.8) {
          triggerLockout(
            `Intervalos robóticos idénticos detectados (Desviación: ${stdDev.toFixed(2)}ms).`,
          );
          return false;
        }
      }

      if (!allowStaticCoords && ac.coords.length >= 15) {
        const last15Coords = ac.coords.slice(-15);
        const last15Times = ac.timestamps.slice(-15);
        const intervals: number[] = [];
        for (let i = 1; i < last15Times.length; i++) {
          intervals.push(last15Times[i] - last15Times[i - 1]);
        }
        const mean = intervals.reduce((a, b) => a + b, 0) / intervals.length;
        if (
          mean < 150 &&
          last15Coords.every(
            (c) => c.x === last15Coords[0].x && c.y === last15Coords[0].y,
          )
        ) {
          triggerLockout(
            'Clicks rápidos repetidos en el mismo píxel exacto mientras el objetivo se mueve.',
          );
          return false;
        }
      }

      return true;
    },
    [triggerLockout],
  );

  const spawnClickFX = useCallback((x: number, y: number, text: string, isCrit: boolean) => {
    const count = isCrit ? 22 : 10;
    const palette = isCrit
      ? ['#ffd166', '#ff2a55', '#ffffff', '#00f3ff']
      : ['#00f3ff', '#a855f7', '#10b981'];
    for (let i = 0; i < count; i++) {
      const ang = (Math.PI * 2 * i) / count + Math.random() * 0.4;
      const spd = (isCrit ? 4.5 : 2.5) + Math.random() * 4.5;
      particlesRef.current.push({
        x,
        y,
        vx: Math.cos(ang) * spd,
        vy: Math.sin(ang) * spd,
        life: 1.0,
        decay: 0.028,
        size: isCrit ? 4.5 : 3,
        color: palette[Math.floor(Math.random() * palette.length)],
      });
    }

    const el = document.createElement('div');
    el.className = 'floating-text';
    el.textContent = text;
    el.style.left = `${x + (Math.random() * 24 - 12)}px`;
    el.style.top = `${y - 10}px`;
    el.style.fontSize = isCrit ? '1.4rem' : '1.05rem';
    el.style.color = isCrit ? '#ffd166' : '#00f3ff';
    document.body.appendChild(el);
    window.setTimeout(() => el.remove(), 850);

    if (isCrit) {
      setShaking(false);
      window.requestAnimationFrame(() => setShaking(true));
      window.setTimeout(() => setShaking(false), 260);
    }
  }, []);

  const handleTargetClick = (
    e: React.MouseEvent<HTMLDivElement>,
    _slotIdx: number,
  ) => {
    e.preventDefault();
    if (!registerAntiCheatClick(e.isTrusted, e.clientX, e.clientY, false)) return;

    const st = stateRef.current;
    const clickStats = getClickStats(st);
    const isCrit = Math.random() < clickStats.critChance;

    const comboStep = 0.1 + st.upgrades.comboMaster * 0.03;
    const maxCap = 5.0 + st.upgrades.comboMaster * 0.5;
    const nextCombo = Math.min(
      maxCap,
      +(comboMultRef.current + comboStep).toFixed(2),
    );
    const maxTime = 2.2 + st.upgrades.comboMaster * 0.12;
    comboMultRef.current = nextCombo;
    comboTimerRef.current = maxTime;
    setComboUI({ mult: nextCombo, pct: 100 });

    let gained = clickStats.clickValue * nextCombo;
    if (isCrit) {
      gained *= clickStats.critMultiplier;
      sfx.playCrit();
    } else {
      sfx.playClick(nextCombo);
    }
    gained = Math.max(1, Math.floor(gained));

    const foundGem =
      st.upgrades.gemMiner > 0 && Math.random() < st.upgrades.gemMiner * 0.01
        ? 1
        : 0;

    spawnClickFX(
      e.clientX,
      e.clientY,
      isCrit ? `¡CRÍTICO! +${formatNumber(gained)}` : `+${formatNumber(gained)}`,
      isCrit,
    );

    setGameState((prev) => {
      let missions = advanceMissions(prev.missions, 'clicks', 1);
      if (isCrit) missions = advanceMissions(missions, 'crits', 1);
      missions = advanceMissions(missions, 'combo', 0, nextCombo);

      const updated: GameState = {
        ...prev,
        gems: prev.gems + foundGem,
        missions,
        stats: {
          ...prev.stats,
          totalClicks: prev.stats.totalClicks + 1,
          totalCrits: prev.stats.totalCrits + (isCrit ? 1 : 0),
          maxCombo: Math.max(prev.stats.maxCombo, nextCombo),
        },
      };

      const res = applyEnergyAndLevelUp(updated, gained, showToast);
      if (res.newlyQueuedLvls.length > 0) {
        queueMicrotask(() => enqueueMinigames(res.newlyQueuedLvls));
      }
      return res.nextState;
    });
  };

  // Store & Upgrades actions
  const handleBuyUpgrade = (id: UpgradeKey) => {
    const upg = UPGRADES_CATALOG.find((u) => u.id === id);
    if (!upg) return;
    setGameState((prev) => {
      const lvl = prev.upgrades[id] || 0;
      if (lvl >= upg.max) return prev;
      const cost = getUpgradeCost(upg, lvl);
      if (prev.energy < cost) return prev;
      sfx.playBuy();
      const next: GameState = {
        ...prev,
        energy: prev.energy - cost,
        upgrades: { ...prev.upgrades, [id]: lvl + 1 },
        stats: { ...prev.stats, upgradesBought: prev.stats.upgradesBought + 1 },
      };
      saveGameState(next);
      return next;
    });
  };

  const handleStartUnbox = (
    kind: 'capsule' | 'bomb' | 'chest',
    tierId: number,
  ) => {
    if (unboxRef.current) return;
    const cur = stateRef.current;

    let tierObj = TIERS[tierId];
    if (kind === 'chest') {
      const chest = DOPAMINE_CHEST_TIERS[tierId];
      if (!chest) return;
      const pool = DOPAMINE_CATALOG.filter(
        (d) => d.chestTier === chest.id && !cur.unlockedDopamine.includes(d.id),
      );
      if (pool.length === 0) {
        showToast(
          '✅ Cofre Completo',
          `Ya desbloqueaste todos los artículos del Cofre ${chest.name}.`,
          'gold',
        );
        return;
      }
      tierObj = {
        id: chest.id,
        name: chest.name,
        color: chest.color,
        costGems: chest.costGems,
        hits: chest.hits,
        minTierDrop: chest.id,
        maxTierDrop: chest.id,
      };
    } else if (kind === 'capsule') {
      if (!tierObj) return;
      const pool = RELICS_CATALOG.filter(
        (r) =>
          r.tier >= tierObj.minTierDrop &&
          r.tier <= tierObj.maxTierDrop &&
          !cur.relics.includes(r.id),
      );
      if (pool.length === 0) {
        showToast(
          '✅ Colección Completa',
          `Ya tienes todas las reliquias de la Cápsula ${tierObj.name}.`,
          'gold',
        );
        return;
      }
    } else {
      if (!tierObj) return;
      const pool = SKINS_CATALOG.filter(
        (s) =>
          s.tier >= tierObj.minTierDrop &&
          s.tier <= tierObj.maxTierDrop &&
          !cur.unlockedSkins.includes(s.id),
      );
      if (pool.length === 0) {
        showToast(
          '✅ Colección Completa',
          `Ya tienes todas las skins de la Bomba ${tierObj.name}.`,
          'gold',
        );
        return;
      }
    }

    if (cur.gems < tierObj.costGems) {
      sfx.playAlert();
      showToast(
        '💎 Cristales Insuficientes',
        `Necesitas ${formatNumber(tierObj.costGems)} 💎 para abrir ${tierObj.name}.`,
        'rose',
      );
      return;
    }

    setGameState((prev) => {
      const next = { ...prev, gems: prev.gems - tierObj.costGems };
      saveGameState(next);
      return next;
    });

    setUnbox({
      kind,
      tier: tierObj,
      hits: 0,
      maxHits: tierObj.hits,
      done: false,
    });
  };

  const handleUnboxHit = (e: React.MouseEvent<HTMLDivElement>) => {
    if (!registerAntiCheatClick(e.isTrusted, e.clientX, e.clientY, true)) return;
    setUnbox((prev) => {
      if (!prev || prev.done) return prev;
      const nextHits = prev.hits + 1;
      const prog = nextHits / prev.maxHits;
      if (prev.kind === 'capsule' || prev.kind === 'chest') sfx.playCrack(prog);
      else sfx.playFuseTick(prog);

      if (nextHits < prev.maxHits) {
        return { ...prev, hits: nextHits };
      }

      sfx.playExplosion();
      const cur = stateRef.current;

      if (prev.kind === 'chest') {
        const pool = DOPAMINE_CATALOG.filter(
          (d) =>
            d.chestTier === prev.tier.id &&
            !cur.unlockedDopamine.includes(d.id),
        );
        const won = pool[Math.floor(Math.random() * pool.length)];
        if (won) {
          setGameState((gs) => {
            const unlockedDopamine = gs.unlockedDopamine.includes(won.id)
              ? gs.unlockedDopamine
              : [...gs.unlockedDopamine, won.id];
            const enabledDopamine = gs.enabledDopamine.includes(won.id)
              ? gs.enabledDopamine
              : [...gs.enabledDopamine, won.id];
            const next = { ...gs, unlockedDopamine, enabledDopamine };
            saveGameState(next);
            return next;
          });
          if (won.id === 'dop_bomb_2m') {
            window.setTimeout(() => setBombTestNonce((n) => n + 1), 600);
          }
        }
        return { ...prev, hits: nextHits, done: true, wonDopamine: won };
      }

      if (prev.kind === 'capsule') {
        const pool = RELICS_CATALOG.filter(
          (r) =>
            r.tier >= prev.tier.minTierDrop &&
            r.tier <= prev.tier.maxTierDrop &&
            !cur.relics.includes(r.id),
        );
        const won = pool[Math.floor(Math.random() * pool.length)];
        if (won) {
          setGameState((gs) => {
            if (gs.relics.includes(won.id)) return gs;
            const next = { ...gs, relics: [...gs.relics, won.id] };
            saveGameState(next);
            return next;
          });
        }
        return { ...prev, hits: nextHits, done: true, wonRelic: won };
      }

      const pool = SKINS_CATALOG.filter(
        (s) =>
          s.tier >= prev.tier.minTierDrop &&
          s.tier <= prev.tier.maxTierDrop &&
          !cur.unlockedSkins.includes(s.id),
      );
      const won = pool[Math.floor(Math.random() * pool.length)];
      if (won) {
        setGameState((gs) => {
          const unlockedSkins = gs.unlockedSkins.includes(won.id)
            ? gs.unlockedSkins
            : [...gs.unlockedSkins, won.id];
          const next = { ...gs, unlockedSkins, equippedSkin: won.id };
          saveGameState(next);
          return next;
        });
      }
      return { ...prev, hits: nextHits, done: true, wonSkin: won };
    });
  };

  const handleToggleDopamine = (id: string) => {
    setGameState((prev) => {
      if (!prev.unlockedDopamine.includes(id)) return prev;
      const isEnabled = prev.enabledDopamine.includes(id);
      const enabledDopamine = isEnabled
        ? prev.enabledDopamine.filter((x) => x !== id)
        : [...prev.enabledDopamine, id];
      const next = { ...prev, enabledDopamine };
      saveGameState(next);
      return next;
    });
    sfx.playClick(2);
  };

  const handleSetAllDopamine = (enabled: boolean) => {
    setGameState((prev) => {
      const enabledDopamine = enabled ? [...prev.unlockedDopamine] : [];
      const next = { ...prev, enabledDopamine };
      saveGameState(next);
      return next;
    });
    sfx.playBuy();
  };

  const handleUploadDopaminePhoto = (
    e: React.ChangeEvent<HTMLInputElement>,
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const result = ev.target?.result;
      if (typeof result !== 'string') return;
      setGameState((prev) => {
        const next = { ...prev, dopaminePhotoSrc: result };
        saveGameState(next);
        return next;
      });
      setPhotoTestNonce((n) => n + 1);
      showToast(
        '🖼️ Foto Dopamínica Guardada',
        'Aparecerá en grande en el fondo cada 5 minutos.',
        'gold',
      );
    };
    reader.readAsDataURL(file);
  };

  const handleClearDopaminePhoto = () => {
    setGameState((prev) => {
      const next = { ...prev, dopaminePhotoSrc: '' };
      saveGameState(next);
      return next;
    });
  };

  const handleClaimMission = (id: string) => {
    setGameState((prev) => {
      const m = prev.missions.find((x) => x.id === id);
      if (!m || !m.completed) return prev;
      const gemMult = 1 + getRelicBonuses(prev.relics).gemMult;
      const rew = Math.ceil(m.rewardGems * gemMult);
      const remaining = prev.missions.filter((x) => x.id !== id);
      const ensured = ensureMissionsList(
        remaining,
        prev.level,
        prev.missionCounter,
      );
      sfx.playBuy();
      showToast('🎯 Misión Completada', `+${rew} 💎 reclamados`, 'purple');
      const next: GameState = {
        ...prev,
        gems: prev.gems + rew,
        missions: ensured.missions,
        missionCounter: ensured.counter,
      };
      saveGameState(next);
      return next;
    });
  };

  const handleClaimMilestone = (lvl: number) => {
    setGameState((prev) => {
      if (prev.level < lvl || prev.claimedMilestones.includes(lvl)) return prev;
      const gemMult = 1 + getRelicBonuses(prev.relics).gemMult;
      const rew = Math.ceil(lvl * 2 * gemMult);
      sfx.playLevelUp();
      showToast(
        `🏆 Hito Nivel ${lvl}`,
        `+${rew} 💎 reclamados por tu progreso.`,
        'gold',
      );
      const next: GameState = {
        ...prev,
        gems: prev.gems + rew,
        claimedMilestones: [...prev.claimedMilestones, lvl],
      };
      saveGameState(next);
      return next;
    });
  };

  const handleEquipSkin = (id: string) => {
    setGameState((prev) => {
      if (!prev.unlockedSkins.includes(id)) return prev;
      const next = { ...prev, equippedSkin: id };
      saveGameState(next);
      return next;
    });
    sfx.playClick(3);
  };

  const handleRebirth = () => {
    const cur = stateRef.current;
    if (cur.level < MAX_LEVEL) return;

    const newRebirths = cur.rebirths + 1;
    const bonusGems = 50 * newRebirths;
    sfx.playExplosion();
    comboMultRef.current = 1.0;
    comboTimerRef.current = 0;
    setComboUI({ mult: 1.0, pct: 0 });
    pendingMinigameQueueRef.current = [];
    setDrawerOpen(false);

    setGameState((prev) => {
      const def = createDefaultState();
      const ensured = ensureMissionsList([], 1, prev.missionCounter);
      const next: GameState = {
        ...prev,
        energy: 0,
        totalEnergyEarned: 0,
        level: 1,
        rebirths: newRebirths,
        gems: prev.gems + bonusGems,
        upgrades: def.upgrades,
        claimedMilestones: [],
        triggeredMinigameLevels: [],
        missions: ensured.missions,
        missionCounter: ensured.counter,
      };
      saveGameState(next);
      return next;
    });

    let unlockMsg = `Multiplicador permanente: ${getRebirthMultiplier(newRebirths).toFixed(1)}x (+${bonusGems} 💎)`;
    if (newRebirths === 1) unlockMsg += ' • ¡Slot #2 Desbloqueado!';
    else if (newRebirths === 2) unlockMsg += ' • ¡Slot #3 Desbloqueado!';
    else if (newRebirths === 3) unlockMsg += ' • ¡Soporte GIFs Desbloqueado!';
    else if (newRebirths === 4) unlockMsg += ' • ¡Slot #4 y Videos Desbloqueados!';

    showToast(`♻️ ¡RENACIMIENTO R${newRebirths}!`, unlockMsg, 'purple');
  };

  const handleSlotUpload = (
    e: React.ChangeEvent<HTMLInputElement>,
    slotIdx: number,
  ) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    if (!file) return;

    const rebirths = stateRef.current.rebirths;
    const isVideo = file.type.startsWith('video/');
    const isGif =
      file.type === 'image/gif' || file.name.toLowerCase().endsWith('.gif');

    if (isVideo && rebirths < 4) {
      sfx.playAlert();
      showToast(
        '🎬 Video Bloqueado',
        'Necesitas Renacimiento R4+ para usar videos.',
        'rose',
      );
      return;
    }
    if (isGif && rebirths < 3) {
      sfx.playAlert();
      showToast(
        '🎞️ GIF Bloqueado',
        'Necesitas Renacimiento R3+ para usar GIFs animados.',
        'rose',
      );
      return;
    }

    const oldMedia = stateRef.current.slotMedia[slotIdx];
    if (oldMedia?.src?.startsWith('blob:')) {
      URL.revokeObjectURL(oldMedia.src);
    }

    if (isVideo) {
      const url = URL.createObjectURL(file);
      setGameState((prev) => {
        const slotMedia = [...prev.slotMedia];
        slotMedia[slotIdx] = { type: 'video', src: url };
        const next = { ...prev, slotMedia };
        saveGameState(next);
        return next;
      });
      showToast(
        '🎬 Video Cargado',
        `Slot #${slotIdx + 1} actualizado con video en bucle.`,
        'purple',
      );
      return;
    }

    const reader = new FileReader();
    reader.onload = (ev) => {
      const result = ev.target?.result;
      if (typeof result !== 'string') return;
      setGameState((prev) => {
        const slotMedia = [...prev.slotMedia];
        slotMedia[slotIdx] = { type: isGif ? 'gif' : 'image', src: result };
        const next = { ...prev, slotMedia };
        saveGameState(next);
        return next;
      });
      showToast(
        isGif ? '🎞️ GIF Cargado' : '🖼️ Imagen Cargada',
        `Slot #${slotIdx + 1} actualizado.`,
        'cyan',
      );
    };
    reader.readAsDataURL(file);
  };

  const handleSlotClear = (slotIdx: number) => {
    setGameState((prev) => {
      const old = prev.slotMedia[slotIdx];
      if (old?.src?.startsWith('blob:')) {
        URL.revokeObjectURL(old.src);
      }
      const slotMedia = [...prev.slotMedia];
      slotMedia[slotIdx] = { type: 'default', src: '' };
      const next = { ...prev, slotMedia };
      saveGameState(next);
      return next;
    });
  };

  const handleToggleStabilizer = () => {
    setGameState((prev) => {
      const next = { ...prev, stabilizer: !prev.stabilizer };
      saveGameState(next);
      return next;
    });
  };

  const handleFullReset = () => {
    for (const m of stateRef.current.slotMedia) {
      if (m?.src?.startsWith('blob:')) URL.revokeObjectURL(m.src);
    }
    localStorage.clear();
    const def = createDefaultState();
    const ensured = ensureMissionsList([], 1, 0);
    comboMultRef.current = 1.0;
    comboTimerRef.current = 0;
    pendingMinigameQueueRef.current = [];
    setComboUI({ mult: 1.0, pct: 0 });
    setMinigameMode({ view: 'closed' });
    setUnbox(null);
    setDrawerOpen(false);
    setGameState({
      ...def,
      missions: ensured.missions,
      missionCounter: ensured.counter,
    });
    showToast(
      '♻️ Sistema Reiniciado',
      'Todo el progreso ha sido borrado desde cero.',
      'rose',
    );
  };

  const handleLaunchMinigame = (lvl: number, isPractice: boolean) => {
    const st = stateRef.current;
    const unlocked =
      st.level >= lvl ||
      st.rebirths > 0 ||
      st.completedMinigames.includes(lvl);
    if (!unlocked) {
      sfx.playAlert();
      showToast(
        '🔒 Minijuego Bloqueado',
        `Alcanza el Nivel ${lvl} para desbloquear esta prueba.`,
        'rose',
      );
      return;
    }
    setMinigameMode({ view: 'play', lvl, isPractice });
  };

  const advanceQueueOrCloseMinigame = useCallback(() => {
    const nextQueued = pendingMinigameQueueRef.current.shift();
    if (nextQueued !== undefined) {
      setMinigameMode({ view: 'play', lvl: nextQueued, isPractice: false });
    } else {
      setMinigameMode({ view: 'closed' });
    }
  }, []);

  const handleCompleteMinigame = useCallback(
    (lvl: number, timeSec: number, isPractice: boolean) => {
      const def = MINIGAMES_CATALOG.find((m) => m.lvl === lvl);
      const prevBest = stateRef.current.minigameRecords[lvl];
      const isRecord = prevBest === undefined || timeSec < prevBest;
      const firstClear = !stateRef.current.completedMinigames.includes(lvl);
      const gemMult = 1 + getRelicBonuses(stateRef.current.relics).gemMult;

      let gemReward: number;
      if (firstClear || !isPractice) {
        const speedBonus = Math.max(1, Math.round(25 / Math.max(1.5, timeSec)));
        gemReward = Math.ceil((Math.floor(lvl * 0.5) + speedBonus) * gemMult);
      } else if (isRecord) {
        gemReward = Math.ceil(Math.max(2, Math.floor(lvl * 0.1)) * gemMult);
      } else {
        gemReward = Math.max(1, Math.ceil(1 * gemMult));
      }

      sfx.playLevelUp();

      setGameState((prev) => {
        const completedMinigames = prev.completedMinigames.includes(lvl)
          ? prev.completedMinigames
          : [...prev.completedMinigames, lvl];
        const minigameRecords = {
          ...prev.minigameRecords,
          [lvl]: isRecord ? timeSec : prev.minigameRecords[lvl],
        };
        const next: GameState = {
          ...prev,
          gems: prev.gems + gemReward,
          completedMinigames,
          minigameRecords,
        };
        saveGameState(next);
        return next;
      });

      showToast(
        `🏆 ¡${def?.name || `Nivel ${lvl}`} Completado!`,
        `Tiempo: ${timeSec}s ${isRecord ? '(¡NUEVO RÉCORD!)' : ''} • +${gemReward} 💎`,
        'gold',
      );

      advanceQueueOrCloseMinigame();
    },
    [advanceQueueOrCloseMinigame, showToast],
  );

  const handlePinballRivalWin = useCallback(
    (rivalSrc: string) => {
      setGameState((prev) => {
        const slotMedia = [...prev.slotMedia];
        slotMedia[0] = { type: 'image', src: rivalSrc };
        const next = { ...prev, slotMedia };
        saveGameState(next);
        return next;
      });
      showToast(
        '🏆 ¡Nuevo Avatar Ganador!',
        'La bola rival ganó el duelo Pinball y ahora es tu foto.',
        'purple',
      );
    },
    [showToast],
  );

  // Derived HUD metrics
  const rank = getCurrentRank(gameState.level);
  const clickStats = getClickStats(gameState);
  const cps = getPassiveCPS(gameState);
  const rebirthMult = getRebirthMultiplier(gameState.rebirths);

  const curThreshold = getEnergyForLevel(gameState.level);
  const nextThreshold =
    gameState.level < MAX_LEVEL
      ? getEnergyForLevel(gameState.level + 1)
      : curThreshold;
  const xpProgress =
    gameState.level >= MAX_LEVEL
      ? 100
      : Math.max(
          0,
          Math.min(
            100,
            ((gameState.totalEnergyEarned - curThreshold) /
              Math.max(1, nextThreshold - curThreshold)) *
              100,
          ),
        );

  const activeSkin =
    SKINS_CATALOG.find((s) => s.id === gameState.equippedSkin) ||
    SKINS_CATALOG[0];
  const activeSkinTier = TIERS[activeSkin.tier] || TIERS[0];
  const completedMissionsCount = gameState.missions.filter(
    (m) => m.completed,
  ).length;
  const firstMission = gameState.missions[0];

  return (
    <div
      className={`text-slate-100 select-none relative w-screen h-screen overflow-hidden ${
        shaking ? 'shake' : ''
      }`}
    >
      <canvas ref={bgCanvasRef} id="bg-canvas" />

      {/* Capa de Artículos Dopamínicos en segundo plano */}
      <DopamineLayer
        unlockedDopamine={gameState.unlockedDopamine}
        enabledDopamine={gameState.enabledDopamine}
        dopaminePhotoSrc={gameState.dopaminePhotoSrc}
        paused={minigameMode.view === 'play'}
        bombTestNonce={bombTestNonce}
        photoTestNonce={photoTestNonce}
        onTimersUpdate={(bSec, pSec) => {
          setBombCountdownSec(bSec);
          setPhotoCountdownSec(pSec);
        }}
      />

      {/* Zona de Objetivos Flotantes Multi-Slot */}
      <main id="game-arena" className="fixed inset-0 z-10 overflow-hidden">
        {Array.from({ length: unlockedSlots }, (_, i) => {
          const media = gameState.slotMedia[i] || { type: 'default', src: '' };
          return (
            <div
              key={i}
              ref={(el) => {
                slotRefs.current[i] = el;
              }}
              onClick={(e) => handleTargetClick(e, i)}
              className="target-slot"
              style={{
                width: `${targetSize}px`,
                height: `${targetSize}px`,
                left: `${targetMotionsRef.current[i]?.posX ?? window.innerWidth * 0.45}px`,
                top: `${targetMotionsRef.current[i]?.posY ?? window.innerHeight * 0.45}px`,
                ['--skin-color' as string]: activeSkinTier.color,
              }}
            >
              <div
                className={`target-core ${activeSkin.fx}`}
                style={{
                  border: activeSkin.border,
                  boxShadow: activeSkin.shadow,
                }}
              >
                {media.type === 'video' && media.src ? (
                  <video
                    ref={(el) => {
                      slotVideoRefs.current[i] = el;
                      if (i === 0 && el) {
                        el.onloadeddata = () => setPrimaryAvatarMedia(el);
                      }
                    }}
                    src={media.src}
                    autoPlay
                    loop
                    muted
                    playsInline
                    className="w-full h-full object-cover pointer-events-none"
                  />
                ) : (media.type === 'image' || media.type === 'gif') &&
                  media.src ? (
                  <img
                    src={media.src}
                    alt={`Objetivo ${i + 1}`}
                    className="w-full h-full object-cover pointer-events-none"
                  />
                ) : (
                  <svg
                    viewBox="0 0 100 100"
                    className="w-4/5 h-4/5 pointer-events-none"
                  >
                    <circle
                      cx="50"
                      cy="50"
                      r="42"
                      fill="none"
                      stroke={activeSkinTier.color}
                      strokeWidth="2.5"
                      strokeDasharray="16 8"
                      className="orb-ring-1"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r="30"
                      fill="none"
                      stroke="#ffffff"
                      strokeWidth="2"
                      strokeDasharray="10 6"
                      opacity="0.7"
                      className="orb-ring-2"
                    />
                    <circle
                      cx="50"
                      cy="50"
                      r="17"
                      fill={activeSkinTier.color}
                      opacity="0.9"
                    />
                    <text
                      x="50"
                      y="55"
                      textAnchor="middle"
                      fill="#060811"
                      fontFamily="Orbitron"
                      fontWeight="900"
                      fontSize="14"
                    >
                      #{i + 1}
                    </text>
                  </svg>
                )}
              </div>
              {unlockedSlots > 1 && (
                <div className="absolute -bottom-2 left-1/2 -translate-x-1/2 px-2 py-0.5 rounded-full bg-slate-950/90 border border-cyan-500/40 text-[9px] font-orbitron font-bold text-cyan-300 pointer-events-none">
                  SLOT {i + 1}
                </div>
              )}
            </div>
          );
        })}
      </main>

      {/* HUD Superior */}
      <header className="fixed top-0 left-0 right-0 z-30 p-2.5 sm:p-4 pointer-events-none">
        <div className="max-w-7xl mx-auto flex flex-wrap items-center justify-between gap-2">
          <div className="pointer-events-auto glass-panel rounded-2xl px-3.5 py-2 flex items-center gap-3 sm:gap-5">
            <div>
              <div className="text-[9px] uppercase tracking-widest text-cyan-400 font-orbitron font-bold">
                Energía
              </div>
              <div className="text-lg sm:text-2xl font-orbitron font-black text-white tabular-nums leading-tight">
                {formatNumber(gameState.energy)}
              </div>
              <div className="text-[10px] text-slate-400 tabular-nums">
                +{formatNumber(cps)} / seg • {formatNumber(clickStats.clickValue)}/click
              </div>
            </div>

            <div className="h-8 w-px bg-slate-700/70" />

            <div>
              <div className="text-[9px] uppercase tracking-widest text-amber-400 font-orbitron font-bold">
                Cristales
              </div>
              <div className="text-lg sm:text-2xl font-orbitron font-black text-amber-300 tabular-nums flex items-center gap-1 leading-tight">
                <span>💎</span>
                <span>{formatNumber(gameState.gems)}</span>
              </div>
              <div className="text-[10px] text-fuchsia-300 font-bold">
                R{gameState.rebirths} ({rebirthMult.toFixed(1)}x)
              </div>
            </div>
          </div>

          {/* Progreso Nivel 1 - 200 */}
          <div className="pointer-events-auto glass-panel rounded-2xl px-4 py-2 flex-1 max-w-md min-w-[230px]">
            <div className="flex items-center justify-between mb-1">
              <div className="flex items-center gap-1.5">
                <span className="font-orbitron font-bold text-xs sm:text-sm text-white">
                  NV. {gameState.level}
                  <span className="text-slate-400 text-[10px]"> / 200</span>
                </span>
                <span
                  className={`text-[9px] sm:text-[10px] px-2 py-0.5 rounded-full font-orbitron font-bold uppercase border ${rank.color}`}
                >
                  {rank.name}
                </span>
              </div>
              <span className="text-[10px] font-rajdhani font-semibold text-cyan-300 tabular-nums">
                {gameState.level >= MAX_LEVEL
                  ? '¡NIVEL 200 MAX!'
                  : `Sig: ${formatNumber(Math.max(0, nextThreshold - gameState.totalEnergyEarned))}`}
              </span>
            </div>
            <div className="w-full h-2.5 bg-slate-900 rounded-full overflow-hidden border border-slate-700/80 p-0.5">
              <div
                className="h-full rounded-full bg-gradient-to-r from-cyan-400 via-blue-500 to-purple-500 transition-all duration-150"
                style={{ width: `${xpProgress}%` }}
              />
            </div>
          </div>

          {/* Botones Rápidos */}
          <div className="pointer-events-auto flex items-center gap-2">
            <button
              onClick={() => setMediaModalOpen(true)}
              className="glass-panel hover:border-purple-400/70 px-3 py-2.5 rounded-xl font-orbitron font-bold text-xs text-purple-300 transition active:scale-95 flex items-center gap-1.5 cursor-pointer"
              title="Gestionar Fotos / GIFs / Videos"
            >
              <span>🖼️</span>
              <span className="hidden md:inline">Multimedia</span>
            </button>

            <button
              onClick={() => setMinigameMode({ view: 'hub' })}
              className="glass-panel hover:border-amber-400/70 px-3 py-2.5 rounded-xl font-orbitron font-bold text-xs text-amber-300 transition active:scale-95 flex items-center gap-1.5 cursor-pointer"
              title="Centro de Minijuegos (Cada 10 niveles)"
            >
              <span>🎮</span>
              <span className="hidden md:inline">Minijuegos</span>
            </button>

            <button
              onClick={() => {
                const nextMuted = !muted;
                sfx.muted = nextMuted;
                setMuted(nextMuted);
              }}
              className="glass-panel hover:border-cyan-400/70 p-2.5 rounded-xl text-cyan-300 transition active:scale-95 cursor-pointer"
              title="Silenciar / Activar Audio"
            >
              {muted ? '🔇' : '🔊'}
            </button>

            <button
              onClick={() => setDrawerOpen((o) => !o)}
              className="relative bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-orbitron font-extrabold text-xs sm:text-sm px-4 py-2.5 rounded-xl shadow-[0_0_20px_rgba(0,243,255,0.45)] transition active:scale-95 flex items-center gap-1.5 cursor-pointer"
            >
              <span>⚡</span>
              <span>ARSENAL</span>
              {completedMissionsCount > 0 && (
                <span className="absolute -top-1.5 -right-1.5 w-5 h-5 bg-rose-500 text-white text-[10px] rounded-full flex items-center justify-center font-bold animate-bounce shadow-lg">
                  {completedMissionsCount}
                </span>
              )}
            </button>
          </div>
        </div>
      </header>

      {/* Indicador de Combo */}
      {comboUI.mult > 1.0 && (
        <div className="fixed top-24 left-1/2 -translate-x-1/2 z-20 pointer-events-none">
          <div className="glass-panel px-4 py-1.5 rounded-full border-amber-400/60 flex items-center gap-2.5 shadow-[0_0_20px_rgba(255,209,102,0.3)]">
            <span className="text-xs font-orbitron font-bold text-amber-300">
              RACHA
            </span>
            <span className="text-lg font-orbitron font-black text-white">
              x{comboUI.mult.toFixed(1)}
            </span>
            <div className="w-16 h-1.5 bg-slate-800 rounded-full overflow-hidden">
              <div
                className="h-full bg-amber-400"
                style={{ width: `${comboUI.pct}%` }}
              />
            </div>
          </div>
        </div>
      )}

      {/* Widget Misión Rápida */}
      <div className="fixed bottom-4 left-4 z-20 pointer-events-auto hidden sm:block max-w-xs">
        <div
          onClick={() => {
            setDrawerOpen(true);
            setActiveTab('missions');
          }}
          className="glass-panel rounded-2xl px-3.5 py-2.5 cursor-pointer hover:border-purple-400/60 transition"
        >
          <div className="flex items-center justify-between gap-4 mb-1">
            <span className="text-[10px] font-orbitron font-bold uppercase tracking-wider text-purple-300">
              🎯 Misión Activa
            </span>
            <span className="text-[10px] font-orbitron font-bold text-amber-300">
              {firstMission ? `+${firstMission.rewardGems} 💎` : ''}
            </span>
          </div>
          <div className="text-xs font-medium text-slate-200 truncate">
            {firstMission ? firstMission.title : 'Todas completadas'}
          </div>
          <div className="w-full h-1.5 bg-slate-800 rounded-full mt-1.5 overflow-hidden">
            <div
              className="h-full bg-gradient-to-r from-purple-500 to-pink-500 transition-all duration-200"
              style={{
                width: `${
                  firstMission
                    ? Math.min(100, (firstMission.progress / firstMission.target) * 100)
                    : 100
                }%`,
              }}
            />
          </div>
        </div>
      </div>

      {/* Notificaciones Toast */}
      <div className="fixed bottom-4 right-4 z-[60] flex flex-col gap-2 pointer-events-none max-w-sm">
        {toasts.map((t) => {
          const borderTheme =
            t.theme === 'gold'
              ? 'border-amber-400'
              : t.theme === 'purple'
                ? 'border-purple-400'
                : t.theme === 'rose'
                  ? 'border-rose-500'
                  : 'border-cyan-400';
          return (
            <div
              key={t.id}
              className={`glass-panel rounded-2xl px-4 py-3 border-l-4 ${borderTheme} shadow-2xl animate-fade-in`}
            >
              <div className="font-orbitron font-bold text-xs text-white">
                {t.title}
              </div>
              <div className="text-[11px] text-slate-300 mt-0.5">{t.subtitle}</div>
            </div>
          );
        })}
      </div>

      {/* Cajón Lateral Arsenal & Tienda */}
      <Drawer
        open={drawerOpen}
        activeTab={activeTab}
        gameState={gameState}
        bombCountdownSec={bombCountdownSec}
        photoCountdownSec={photoCountdownSec}
        onClose={() => setDrawerOpen(false)}
        onSelectTab={setActiveTab}
        onBuyUpgrade={handleBuyUpgrade}
        onStartUnbox={handleStartUnbox}
        onToggleDopamine={handleToggleDopamine}
        onSetAllDopamine={handleSetAllDopamine}
        onUploadDopaminePhoto={handleUploadDopaminePhoto}
        onClearDopaminePhoto={handleClearDopaminePhoto}
        onTestDopamineBomb={() => setBombTestNonce((n) => n + 1)}
        onTestDopaminePhoto={() => setPhotoTestNonce((n) => n + 1)}
        onClaimMission={handleClaimMission}
        onClaimMilestone={handleClaimMilestone}
        onEquipSkin={handleEquipSkin}
        onRebirth={handleRebirth}
        onOpenMediaModal={() => {
          setDrawerOpen(false);
          setMediaModalOpen(true);
        }}
        onToggleStabilizer={handleToggleStabilizer}
        onFullReset={handleFullReset}
      />

      {/* Modal Multimedia */}
      <MediaModal
        open={mediaModalOpen}
        rebirths={gameState.rebirths}
        slotMedia={gameState.slotMedia}
        onUpload={handleSlotUpload}
        onClear={handleSlotClear}
        onClose={() => setMediaModalOpen(false)}
      />

      {/* Modal Cápsula / Bomba */}
      <UnboxModal
        unbox={unbox}
        onHit={handleUnboxHit}
        onClose={() => setUnbox(null)}
      />

      {/* Modal Minijuegos */}
      <MinigameModal
        mode={minigameMode}
        playerLevel={gameState.level}
        rebirths={gameState.rebirths}
        completedMinigames={gameState.completedMinigames}
        minigameRecords={gameState.minigameRecords}
        primaryAvatarMedia={primaryAvatarMedia}
        onClose={advanceQueueOrCloseMinigame}
        onLaunch={handleLaunchMinigame}
        onComplete={handleCompleteMinigame}
        onPinballRivalWin={handlePinballRivalWin}
        onShowToast={showToast}
      />

      {/* Alerta Anti-Autoclicker */}
      {antiCheatOverlay.active && (
        <div className="fixed inset-0 z-[70] bg-slate-950/90 backdrop-blur-xl flex items-center justify-center p-4">
          <div className="security-lockout max-w-md w-full bg-slate-900 border-2 border-rose-500 rounded-3xl p-6 text-center">
            <div className="w-16 h-16 mx-auto mb-3 rounded-2xl bg-rose-500/20 border border-rose-500 flex items-center justify-center text-3xl">
              🛡️
            </div>
            <h2 className="font-orbitron font-black text-xl text-rose-400 tracking-wider">
              AUTOMATIZACIÓN DETECTADA
            </h2>
            <p className="text-xs text-slate-300 mt-2 leading-relaxed">
              {antiCheatOverlay.reason}
            </p>
            <div className="mt-4 bg-slate-950 rounded-2xl p-3 border border-slate-800">
              <div className="text-[10px] uppercase tracking-widest text-slate-400 font-orbitron">
                Tiempo de Bloqueo
              </div>
              <div className="text-3xl font-orbitron font-black text-amber-400 tabular-nums mt-1">
                {antiCheatOverlay.remSec.toFixed(1)}s
              </div>
            </div>
          </div>
        </div>
      )}
    </div>
  );
}
