import React, { useEffect, useRef, useState } from 'react';
import { sfx } from '../game/sound';

interface DopamineLayerProps {
  unlockedDopamine: string[];
  enabledDopamine: string[];
  dopaminePhotoSrc: string;
  paused: boolean;
  bombTestNonce: number;
  photoTestNonce: number;
  onTimersUpdate?: (bombRemainingSec: number, photoRemainingSec: number) => void;
}

const PARROT_QUOTES = [
  '¡DALE CLICK!',
  '¡MÁS ENERGÍA!',
  '¡OVERDRIVE!',
  '¡VAMOS CRACK!',
  '¡DOPAMINA PURA!',
];

const DVD_COLORS = ['#00f3ff', '#ff2a55', '#ffd166', '#a855f7', '#10b981', '#fb923c'];

export const DopamineLayer: React.FC<DopamineLayerProps> = ({
  unlockedDopamine,
  enabledDopamine,
  dopaminePhotoSrc,
  paused,
  bombTestNonce,
  photoTestNonce,
  onTimersUpdate,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const activeSetRef = useRef<Set<string>>(new Set());
  const pausedRef = useRef(paused);
  pausedRef.current = paused;
  const onTimersUpdateRef = useRef(onTimersUpdate);
  onTimersUpdateRef.current = onTimersUpdate;

  const bombCountdownRef = useRef<number>(120);
  const photoCountdownRef = useRef<number>(300);
  const bombAnimRef = useRef<{
    active: boolean;
    t: number;
    tx: number;
    ty: number;
    exploded: boolean;
    particles: { x: number; y: number; vx: number; vy: number; r: number; color: string; life: number }[];
  }>({ active: false, t: 0, tx: 400, ty: 300, exploded: false, particles: [] });

  const [photoVisible, setPhotoVisible] = useState(false);
  const photoShowTimerRef = useRef(0);
  const [parrotQuoteIdx, setParrotQuoteIdx] = useState(0);

  const isActive = (id: string) =>
    unlockedDopamine.includes(id) && enabledDopamine.includes(id);

  useEffect(() => {
    const set = new Set<string>();
    for (const id of enabledDopamine) {
      if (unlockedDopamine.includes(id)) set.add(id);
    }
    activeSetRef.current = set;
  }, [unlockedDopamine, enabledDopamine]);

  const parrotEnabled = isActive('dop_parrot');
  const photoEnabled = isActive('dop_photo_5m');
  const bombEnabled = isActive('dop_bomb_2m');

  // Cycle parrot speech quote
  useEffect(() => {
    if (!parrotEnabled) return;
    const id = window.setInterval(() => {
      setParrotQuoteIdx((i) => (i + 1) % PARROT_QUOTES.length);
    }, 3200);
    return () => window.clearInterval(id);
  }, [parrotEnabled]);

  const launchBombDrop = () => {
    const c = canvasRef.current;
    const w = c ? c.width : window.innerWidth;
    const h = c ? c.height : window.innerHeight;
    bombAnimRef.current = {
      active: true,
      t: 0,
      tx: w * (0.25 + Math.random() * 0.5),
      ty: h * (0.35 + Math.random() * 0.35),
      exploded: false,
      particles: [],
    };
  };

  // Trigger test bomb drop when requested from panel
  useEffect(() => {
    if (bombTestNonce > 0 && bombEnabled) {
      launchBombDrop();
      bombCountdownRef.current = 120;
    }
  }, [bombTestNonce, bombEnabled]);

  // Trigger test photo popup when requested from panel
  useEffect(() => {
    if (photoTestNonce > 0 && photoEnabled) {
      photoShowTimerRef.current = 5.5;
      setPhotoVisible(true);
      photoCountdownRef.current = 300;
    }
  }, [photoTestNonce, photoEnabled]);

  // Reset countdowns when toggled off
  useEffect(() => {
    if (!bombEnabled) {
      bombCountdownRef.current = 120;
      bombAnimRef.current.active = false;
    }
  }, [bombEnabled]);

  useEffect(() => {
    if (!photoEnabled) {
      photoCountdownRef.current = 300;
      photoShowTimerRef.current = 0;
      setPhotoVisible(false);
    }
  }, [photoEnabled]);

  // Main 60fps canvas animation for all active dopamine items
  useEffect(() => {
    const canvas = canvasRef.current;
    if (!canvas) return;
    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const resize = () => {
      canvas.width = window.innerWidth;
      canvas.height = window.innerHeight;
    };
    resize();
    window.addEventListener('resize', resize);

    // Persistent simulation state across frames
    const sim = {
      num67: { x: 180, y: 180, vx: 135, vy: 105 },
      dvd: { x: 260, y: 240, vx: 155, vy: 120, colorIdx: 0 },
      confetti: Array.from({ length: 55 }, () => ({
        x: Math.random() * window.innerWidth,
        y: Math.random() * window.innerHeight,
        vy: 60 + Math.random() * 90,
        vx: (Math.random() - 0.5) * 40,
        rot: Math.random() * Math.PI * 2,
        vr: (Math.random() - 0.5) * 6,
        color: DVD_COLORS[Math.floor(Math.random() * DVD_COLORS.length)],
        w: 6 + Math.random() * 6,
      })),
      matrixDrops: Array.from({ length: 42 }, (_, i) => ({
        x: ((i + 0.5) / 42) * window.innerWidth,
        y: Math.random() * window.innerHeight,
        spd: 110 + Math.random() * 140,
      })),
      nyan: { x: -160, y: window.innerHeight * 0.28 },
      ufo: { x: window.innerWidth * 0.5, t: 0 },
      parkour: { scroll: 0, jumpT: 0 },
      fireworks: [] as {
        x: number;
        y: number;
        age: number;
        color: string;
        sparks: { dx: number; dy: number }[];
      }[],
      fwTimer: 0,
      towersT: 0,
      tower1Particles: [] as { x: number; y: number; vx: number; vy: number; s: number; life: number; c: string }[],
      tower2Particles: [] as { x: number; y: number; vx: number; vy: number; s: number; life: number; c: string }[],
      tower1Exploded: false,
      tower2Exploded: false,
    };

    let lastTime = performance.now();
    let timerReportAcc = 0;
    let rafId = 0;

    const frame = (now: number) => {
      const dt = Math.min(0.05, Math.max(0, (now - lastTime) / 1000));
      lastTime = now;

      const W = canvas.width;
      const H = canvas.height;
      ctx.clearRect(0, 0, W, H);

      const act = activeSetRef.current;

      // Update timed events (2m bomb & 5m photo) only when unpaused
      if (!pausedRef.current) {
        if (act.has('dop_bomb_2m')) {
          bombCountdownRef.current -= dt;
          if (bombCountdownRef.current <= 0) {
            bombCountdownRef.current = 120;
            launchBombDrop();
          }
        }
        if (act.has('dop_photo_5m')) {
          photoCountdownRef.current -= dt;
          if (photoCountdownRef.current <= 0) {
            photoCountdownRef.current = 300;
            photoShowTimerRef.current = 5.5;
            setPhotoVisible(true);
          }
          if (photoShowTimerRef.current > 0) {
            photoShowTimerRef.current -= dt;
            if (photoShowTimerRef.current <= 0) {
              photoShowTimerRef.current = 0;
              setPhotoVisible(false);
            }
          }
        }
        timerReportAcc += dt;
        if (timerReportAcc >= 1) {
          timerReportAcc = 0;
          onTimersUpdateRef.current?.(
            Math.max(0, Math.ceil(bombCountdownRef.current)),
            Math.max(0, Math.ceil(photoCountdownRef.current)),
          );
        }
      }

      // 1. Matrix rain
      if (act.has('dop_matrix')) {
        ctx.font = 'bold 13px monospace';
        ctx.textAlign = 'center';
        const chars = '01OVERDRIVE67⚡';
        for (let i = 0; i < sim.matrixDrops.length; i++) {
          const d = sim.matrixDrops[i];
          d.y += d.spd * dt;
          if (d.y > H + 100) {
            d.y = -20;
            d.x = ((i + Math.random() * 0.5) / sim.matrixDrops.length) * W;
          }
          for (let k = 0; k < 6; k++) {
            ctx.fillStyle = k === 0 ? 'rgba(167, 243, 208, 0.55)' : `rgba(16, 185, 129, ${0.32 - k * 0.05})`;
            const ch = chars[(i + k + Math.floor(now / 140)) % chars.length];
            ctx.fillText(ch, d.x, d.y - k * 15);
          }
        }
      }

      // 2. Fireworks
      if (act.has('dop_fireworks')) {
        sim.fwTimer += dt;
        if (sim.fwTimer > 1.4) {
          sim.fwTimer = 0;
          const color = DVD_COLORS[Math.floor(Math.random() * DVD_COLORS.length)];
          const sparks = Array.from({ length: 18 }, (_, k) => {
            const ang = (Math.PI * 2 * k) / 18;
            const spd = 65 + Math.random() * 75;
            return { dx: Math.cos(ang) * spd, dy: Math.sin(ang) * spd };
          });
          sim.fireworks.push({
            x: W * (0.15 + Math.random() * 0.7),
            y: H * (0.15 + Math.random() * 0.45),
            age: 0,
            color,
            sparks,
          });
        }
        for (let i = sim.fireworks.length - 1; i >= 0; i--) {
          const fw = sim.fireworks[i];
          fw.age += dt;
          if (fw.age > 1.5) {
            sim.fireworks.splice(i, 1);
            continue;
          }
          const alpha = Math.max(0, 1 - fw.age / 1.5);
          ctx.fillStyle = fw.color;
          ctx.globalAlpha = alpha * 0.75;
          for (const sp of fw.sparks) {
            const sx = fw.x + sp.dx * fw.age;
            const sy = fw.y + sp.dy * fw.age + 25 * fw.age * fw.age;
            ctx.beginPath();
            ctx.arc(sx, sy, 3, 0, Math.PI * 2);
            ctx.fill();
          }
          ctx.globalAlpha = 1;
        }
      }

      // 3. UFO Tractor Beam
      if (act.has('dop_ufo')) {
        sim.ufo.t += dt;
        sim.ufo.x = W * 0.5 + Math.sin(sim.ufo.t * 0.65) * (W * 0.34);
        const uy = 115 + Math.cos(sim.ufo.t * 1.6) * 14;
        // Tractor beam
        const grad = ctx.createLinearGradient(sim.ufo.x, uy, sim.ufo.x, uy + 210);
        grad.addColorStop(0, 'rgba(34, 211, 238, 0.34)');
        grad.addColorStop(1, 'rgba(34, 211, 238, 0)');
        ctx.fillStyle = grad;
        ctx.beginPath();
        ctx.moveTo(sim.ufo.x - 16, uy + 10);
        ctx.lineTo(sim.ufo.x + 16, uy + 10);
        ctx.lineTo(sim.ufo.x + 65, uy + 210);
        ctx.lineTo(sim.ufo.x - 65, uy + 210);
        ctx.closePath();
        ctx.fill();
        // Saucer dome & body
        ctx.fillStyle = 'rgba(56, 189, 248, 0.55)';
        ctx.beginPath();
        ctx.arc(sim.ufo.x, uy - 6, 18, Math.PI, 0);
        ctx.fill();
        ctx.fillStyle = '#334155';
        ctx.strokeStyle = '#22d3ee';
        ctx.lineWidth = 2;
        ctx.beginPath();
        ctx.ellipse(sim.ufo.x, uy + 4, 38, 11, 0, 0, Math.PI * 2);
        ctx.fill();
        ctx.stroke();
      }

      // 4. Nyan Cyber Cat
      if (act.has('dop_nyan')) {
        sim.nyan.x += 170 * dt;
        if (sim.nyan.x > W + 160) {
          sim.nyan.x = -160;
          sim.nyan.y = H * (0.2 + Math.random() * 0.5);
        }
        const ny = sim.nyan.y + Math.sin(now / 120) * 6;
        const rainbow = ['#ff2a55', '#fb923c', '#facc15', '#22c55e', '#38bdf8', '#a855f7'];
        rainbow.forEach((col, idx) => {
          ctx.fillStyle = col;
          ctx.globalAlpha = 0.45;
          ctx.fillRect(sim.nyan.x - 135, ny - 15 + idx * 5, 130, 5);
        });
        ctx.globalAlpha = 0.85;
        ctx.fillStyle = '#f472b6';
        ctx.fillRect(sim.nyan.x - 14, ny - 14, 34, 26);
        ctx.fillStyle = '#94a3b8';
        ctx.fillRect(sim.nyan.x + 12, ny - 12, 18, 18);
        ctx.font = '18px sans-serif';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('🐱', sim.nyan.x + 21, ny - 3);
        ctx.globalAlpha = 1;
      }

      // 5. Plane crashing into two towers & towers crumbling
      if (act.has('dop_towers')) {
        sim.towersT += dt;
        const cycle = 16.5;
        if (sim.towersT >= cycle) {
          sim.towersT = 0;
          sim.tower1Exploded = false;
          sim.tower2Exploded = false;
          sim.tower1Particles = [];
          sim.tower2Particles = [];
        }
        const tt = sim.towersT;
        const tBaseY = H - 24;
        const tW = Math.min(72, W * 0.08);
        const tH = Math.min(230, H * 0.42);
        const t1X = W * 0.68;
        const t2X = W * 0.8;

        const t1Progress = tt < 3.6 ? 0 : Math.min(1, (tt - 3.6) / 3.4);
        const t2Progress = tt < 5.6 ? 0 : Math.min(1, (tt - 5.6) / 3.4);
        const rebuildFade = tt > 13.8 ? Math.min(1, (tt - 13.8) / 2.2) : 0;

        const drawTower = (tx: number, collapse: number) => {
          const curH = rebuildFade > 0 ? tH * rebuildFade : tH * (1 - collapse * 0.92);
          const tilt = rebuildFade > 0 ? 0 : collapse * 0.16;
          ctx.save();
          ctx.translate(tx + tW / 2, tBaseY);
          ctx.rotate(tilt);
          ctx.globalAlpha = rebuildFade > 0 ? 0.35 + rebuildFade * 0.3 : 0.65 * (1 - collapse * 0.45);
          ctx.fillStyle = '#0f172a';
          ctx.strokeStyle = collapse > 0.1 && rebuildFade === 0 ? '#ff2a55' : '#38bdf8';
          ctx.lineWidth = 2;
          ctx.fillRect(-tW / 2, -curH, tW, curH);
          ctx.strokeRect(-tW / 2, -curH, tW, curH);

          // Lit windows
          ctx.fillStyle = collapse > 0.1 && rebuildFade === 0 ? '#fb923c' : '#22d3ee';
          const rows = Math.floor(curH / 20);
          for (let r = 0; r < rows; r++) {
            for (let c = 0; c < 3; c++) {
              ctx.fillRect(-tW / 2 + 10 + c * ((tW - 20) / 3), -curH + 10 + r * 18, 8, 9);
            }
          }
          ctx.restore();
          ctx.globalAlpha = 1;
        };

        drawTower(t1X, t1Progress);
        drawTower(t2X, t2Progress);

        // Spawn debris on impact
        if (tt >= 3.6 && !sim.tower1Exploded) {
          sim.tower1Exploded = true;
          for (let i = 0; i < 28; i++) {
            sim.tower1Particles.push({
              x: t1X + tW / 2,
              y: tBaseY - tH * 0.72,
              vx: (Math.random() - 0.35) * 210,
              vy: -60 - Math.random() * 140,
              s: 4 + Math.random() * 6,
              life: 1,
              c: i % 2 === 0 ? '#ff2a55' : '#fbbf24',
            });
          }
        }
        if (tt >= 5.6 && !sim.tower2Exploded) {
          sim.tower2Exploded = true;
          for (let i = 0; i < 28; i++) {
            sim.tower2Particles.push({
              x: t2X + tW / 2,
              y: tBaseY - tH * 0.62,
              vx: (Math.random() - 0.35) * 210,
              vy: -60 - Math.random() * 140,
              s: 4 + Math.random() * 6,
              life: 1,
              c: i % 2 === 0 ? '#ff2a55' : '#38bdf8',
            });
          }
        }

        // Plane flying from left into towers
        if (tt < 5.7) {
          const planeX = -60 + (tt / 5.6) * (t2X + 40);
          const planeY = tBaseY - tH * 0.72 + Math.sin(tt * 3) * 6;
          ctx.save();
          ctx.translate(planeX, planeY);
          ctx.fillStyle = '#e2e8f0';
          ctx.beginPath();
          ctx.moveTo(26, 0);
          ctx.lineTo(-22, -8);
          ctx.lineTo(-16, 0);
          ctx.lineTo(-22, 8);
          ctx.closePath();
          ctx.fill();
          ctx.fillStyle = '#38bdf8';
          ctx.fillRect(-10, -18, 12, 36);
          ctx.restore();
        }

        const updateDebris = (arr: typeof sim.tower1Particles) => {
          for (let i = arr.length - 1; i >= 0; i--) {
            const p = arr[i];
            p.vy += 280 * dt;
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.life -= dt * 0.35;
            if (p.life <= 0 || p.y > H) {
              arr.splice(i, 1);
              continue;
            }
            ctx.globalAlpha = p.life;
            ctx.fillStyle = p.c;
            ctx.fillRect(p.x, p.y, p.s, p.s);
          }
          ctx.globalAlpha = 1;
        };
        updateDebris(sim.tower1Particles);
        updateDebris(sim.tower2Particles);
      }

      // 6. Infinite Parkour Runner at bottom
      if (act.has('dop_parkour')) {
        sim.parkour.scroll += 220 * dt;
        sim.parkour.jumpT += dt;
        const baseY = H - 28;
        ctx.strokeStyle = 'rgba(0, 243, 255, 0.38)';
        ctx.lineWidth = 3;
        ctx.beginPath();
        ctx.moveTo(0, baseY);
        ctx.lineTo(W, baseY);
        ctx.stroke();

        const obsSpacing = 210;
        const runnerX = W * 0.16;
        let jumpOffset = 0;
        for (let ox = -(sim.parkour.scroll % obsSpacing); ox < W + 40; ox += obsSpacing) {
          ctx.fillStyle = 'rgba(255, 42, 85, 0.55)';
          ctx.fillRect(ox, baseY - 22, 16, 22);
          const dist = Math.abs(ox - runnerX);
          if (dist < 48) {
            jumpOffset = Math.max(jumpOffset, Math.cos((dist / 48) * (Math.PI / 2)) * 46);
          }
        }
        ctx.fillStyle = '#00f3ff';
        ctx.beginPath();
        ctx.arc(runnerX, baseY - 12 - jumpOffset, 10, 0, Math.PI * 2);
        ctx.fill();
      }

      // 7. Bouncing DVD Logo
      if (act.has('dop_dvd')) {
        const d = sim.dvd;
        const bw = 96;
        const bh = 44;
        d.x += d.vx * dt;
        d.y += d.vy * dt;
        if (d.x <= 10) {
          d.x = 10;
          d.vx = Math.abs(d.vx);
          d.colorIdx = (d.colorIdx + 1) % DVD_COLORS.length;
        }
        if (d.x + bw >= W - 10) {
          d.x = W - bw - 10;
          d.vx = -Math.abs(d.vx);
          d.colorIdx = (d.colorIdx + 1) % DVD_COLORS.length;
        }
        if (d.y <= 80) {
          d.y = 80;
          d.vy = Math.abs(d.vy);
          d.colorIdx = (d.colorIdx + 1) % DVD_COLORS.length;
        }
        if (d.y + bh >= H - 10) {
          d.y = H - bh - 10;
          d.vy = -Math.abs(d.vy);
          d.colorIdx = (d.colorIdx + 1) % DVD_COLORS.length;
        }
        const col = DVD_COLORS[d.colorIdx];
        ctx.globalAlpha = 0.55;
        ctx.strokeStyle = col;
        ctx.lineWidth = 3;
        ctx.strokeRect(d.x, d.y, bw, bh);
        ctx.fillStyle = col;
        ctx.font = '900 20px Orbitron';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.fillText('DVD', d.x + bw / 2, d.y + bh / 2);
        ctx.globalAlpha = 1;
      }

      // 8. Giant Bouncing Glitch "67"
      if (act.has('dop_67')) {
        const n = sim.num67;
        n.x += n.vx * dt;
        n.y += n.vy * dt;
        if (n.x < 90) {
          n.x = 90;
          n.vx = Math.abs(n.vx);
        }
        if (n.x > W - 90) {
          n.x = W - 90;
          n.vx = -Math.abs(n.vx);
        }
        if (n.y < 120) {
          n.y = 120;
          n.vy = Math.abs(n.vy);
        }
        if (n.y > H - 70) {
          n.y = H - 70;
          n.vy = -Math.abs(n.vy);
        }
        const pulse = 1 + Math.sin(now / 190) * 0.12;
        ctx.save();
        ctx.translate(n.x, n.y);
        ctx.scale(pulse, pulse);
        ctx.font = '900 84px Orbitron';
        ctx.textAlign = 'center';
        ctx.textBaseline = 'middle';
        ctx.globalAlpha = 0.48;
        ctx.fillStyle = '#ff2a55';
        ctx.fillText('67', -4, -3);
        ctx.fillStyle = '#00f3ff';
        ctx.fillText('67', 4, 3);
        ctx.globalAlpha = 0.72;
        ctx.fillStyle = '#ffffff';
        ctx.fillText('67', 0, 0);
        ctx.restore();
        ctx.globalAlpha = 1;
      }

      // 9. Confetti shower
      if (act.has('dop_confetti')) {
        for (const cf of sim.confetti) {
          cf.y += cf.vy * dt;
          cf.x += cf.vx * dt;
          cf.rot += cf.vr * dt;
          if (cf.y > H + 20) {
            cf.y = -15;
            cf.x = Math.random() * W;
          }
          ctx.save();
          ctx.translate(cf.x, cf.y);
          ctx.rotate(cf.rot);
          ctx.globalAlpha = 0.55;
          ctx.fillStyle = cf.color;
          ctx.fillRect(-cf.w / 2, -3, cf.w, 6);
          ctx.restore();
        }
        ctx.globalAlpha = 1;
      }

      // 10. 2-Minute Map Bomb Drop & Explosion
      if (bombAnimRef.current.active) {
        const ba = bombAnimRef.current;
        ba.t += dt;
        const dropDur = 0.95;

        if (ba.t < dropDur) {
          const prog = ba.t / dropDur;
          const curY = -60 + prog * (ba.ty + 60);

          // Target reticle on ground
          ctx.strokeStyle = '#ff2a55';
          ctx.lineWidth = 3;
          ctx.globalAlpha = 0.65 + Math.sin(now / 60) * 0.25;
          ctx.beginPath();
          ctx.arc(ba.tx, ba.ty, 36 * (1.2 - prog * 0.5), 0, Math.PI * 2);
          ctx.stroke();

          // Falling Bomb
          ctx.globalAlpha = 0.95;
          ctx.fillStyle = '#1e293b';
          ctx.strokeStyle = '#ffd166';
          ctx.lineWidth = 3;
          ctx.beginPath();
          ctx.arc(ba.tx, curY, 26, 0, Math.PI * 2);
          ctx.fill();
          ctx.stroke();
          ctx.font = '26px sans-serif';
          ctx.textAlign = 'center';
          ctx.textBaseline = 'middle';
          ctx.fillText('💣', ba.tx, curY);
        } else {
          if (!ba.exploded) {
            ba.exploded = true;
            if (!pausedRef.current) sfx.playExplosion();
            for (let i = 0; i < 48; i++) {
              const ang = (Math.PI * 2 * i) / 48 + Math.random() * 0.2;
              const spd = 90 + Math.random() * 290;
              ba.particles.push({
                x: ba.tx,
                y: ba.ty,
                vx: Math.cos(ang) * spd,
                vy: Math.sin(ang) * spd,
                r: 4 + Math.random() * 8,
                color: i % 3 === 0 ? '#ffd166' : i % 3 === 1 ? '#ff2a55' : '#fb923c',
                life: 1,
              });
            }
          }

          const expT = ba.t - dropDur;
          const shockR = expT * 420;
          const shockAlpha = Math.max(0, 1 - expT / 1.4);
          if (shockAlpha > 0) {
            ctx.strokeStyle = '#ffd166';
            ctx.lineWidth = 8 * shockAlpha;
            ctx.globalAlpha = shockAlpha * 0.85;
            ctx.beginPath();
            ctx.arc(ba.tx, ba.ty, shockR, 0, Math.PI * 2);
            ctx.stroke();

            ctx.fillStyle = 'rgba(255, 42, 85, 0.35)';
            ctx.beginPath();
            ctx.arc(ba.tx, ba.ty, Math.max(10, 140 * shockAlpha), 0, Math.PI * 2);
            ctx.fill();
          }

          for (let i = ba.particles.length - 1; i >= 0; i--) {
            const p = ba.particles[i];
            p.x += p.vx * dt;
            p.y += p.vy * dt;
            p.vy += 180 * dt;
            p.life -= dt * 0.55;
            if (p.life <= 0) {
              ba.particles.splice(i, 1);
              continue;
            }
            ctx.globalAlpha = p.life;
            ctx.fillStyle = p.color;
            ctx.beginPath();
            ctx.arc(p.x, p.y, p.r, 0, Math.PI * 2);
            ctx.fill();
          }

          if (expT > 2.2 && ba.particles.length === 0) {
            ba.active = false;
          }
        }
        ctx.globalAlpha = 1;
      }

      rafId = requestAnimationFrame(frame);
    };

    rafId = requestAnimationFrame(frame);
    return () => {
      cancelAnimationFrame(rafId);
      window.removeEventListener('resize', resize);
    };
  }, []);

  return (
    <div className="fixed inset-0 z-[5] pointer-events-none overflow-hidden">
      <canvas ref={canvasRef} className="w-full h-full block" />

      {/* Loro Animador (SVG animado en el fondo izquierdo) */}
      {parrotEnabled && (
        <div className="fixed bottom-20 left-5 sm:left-8 flex flex-col items-center opacity-80 animate-bounce">
          <div className="mb-1 px-2.5 py-1 rounded-xl bg-slate-900/90 border border-emerald-400/60 text-[10px] font-orbitron font-bold text-emerald-300 shadow-lg">
            {PARROT_QUOTES[parrotQuoteIdx]}
          </div>
          <svg viewBox="0 0 120 120" className="w-24 h-24 drop-shadow-[0_0_14px_rgba(16,185,129,0.6)]">
            {/* Cuerpo verde */}
            <ellipse cx="60" cy="68" rx="22" ry="30" fill="#10b981" stroke="#34d399" strokeWidth="2.5" />
            {/* Pecho amarillo/rojo */}
            <ellipse cx="64" cy="72" rx="13" ry="20" fill="#facc15" />
            {/* Ala animada */}
            <path
              d="M42 56 Q22 72 40 90 Q54 78 52 58 Z"
              fill="#06b6d4"
              stroke="#22d3ee"
              strokeWidth="2"
              className="origin-center animate-pulse"
            />
            {/* Cabeza */}
            <circle cx="62" cy="38" r="17" fill="#ef4444" stroke="#fca5a5" strokeWidth="2" />
            {/* Ojo */}
            <circle cx="68" cy="35" r="5.5" fill="#ffffff" />
            <circle cx="69.5" cy="35" r="2.6" fill="#0f172a" />
            {/* Pico */}
            <path d="M77 35 Q94 37 86 50 Q78 46 76 42 Z" fill="#f59e0b" />
            {/* Plumas cola */}
            <path d="M52 94 L44 114 L58 100 L64 116 L68 96 Z" fill="#a855f7" />
          </svg>
        </div>
      )}

      {/* Foto Gigante cada 5 Minutos */}
      {photoEnabled && photoVisible && (
        <div className="fixed inset-0 flex items-center justify-center p-6 animate-fade-in">
          <div className="max-w-md w-full rounded-3xl border-4 border-amber-400/75 bg-slate-950/75 p-2 shadow-[0_0_55px_rgba(250,204,21,0.45)] opacity-75">
            {dopaminePhotoSrc ? (
              <img
                src={dopaminePhotoSrc}
                alt="Foto Dopamínica"
                className="w-full max-h-[55vh] object-contain rounded-2xl"
              />
            ) : (
              <div className="py-16 px-6 text-center">
                <div className="text-5xl mb-2">🖼️</div>
                <div className="font-orbitron font-bold text-sm text-amber-300">
                  FOTO DOPAMÍNICA (CADA 5 MIN)
                </div>
                <p className="text-xs text-slate-300 mt-1">
                  Elige tu foto personalizada en Arsenal → 🎛️ Fondo
                </p>
              </div>
            )}
          </div>
        </div>
      )}
    </div>
  );
};
