import React, { useState } from 'react';
import {
  DOPAMINE_CATALOG,
  DOPAMINE_CHEST_TIERS,
  formatNumber,
  getCurrentRank,
  getRebirthMultiplier,
  getRelicBonuses,
  getUpgradeCost,
  MAX_LEVEL,
  MINIGAMES_CATALOG,
  RELICS_CATALOG,
  SKINS_CATALOG,
  TIERS,
  UPGRADES_CATALOG,
} from '../game/catalogs';
import { DrawerTab, GameState, UpgradeKey } from '../game/types';

interface DrawerProps {
  open: boolean;
  activeTab: DrawerTab;
  gameState: GameState;
  bombCountdownSec: number;
  photoCountdownSec: number;
  onClose: () => void;
  onSelectTab: (tab: DrawerTab) => void;
  onBuyUpgrade: (id: UpgradeKey) => void;
  onStartUnbox: (kind: 'capsule' | 'bomb' | 'chest', tierId: number) => void;
  onToggleDopamine: (id: string) => void;
  onSetAllDopamine: (enabled: boolean) => void;
  onUploadDopaminePhoto: (e: React.ChangeEvent<HTMLInputElement>) => void;
  onClearDopaminePhoto: () => void;
  onTestDopamineBomb: () => void;
  onTestDopaminePhoto: () => void;
  onClaimMission: (id: string) => void;
  onClaimMilestone: (lvl: number) => void;
  onEquipSkin: (id: string) => void;
  onRebirth: () => void;
  onOpenMediaModal: () => void;
  onToggleStabilizer: () => void;
  onFullReset: () => void;
}

export const Drawer: React.FC<DrawerProps> = ({
  open,
  activeTab,
  gameState,
  bombCountdownSec,
  photoCountdownSec,
  onClose,
  onSelectTab,
  onBuyUpgrade,
  onStartUnbox,
  onToggleDopamine,
  onSetAllDopamine,
  onUploadDopaminePhoto,
  onClearDopaminePhoto,
  onTestDopamineBomb,
  onTestDopaminePhoto,
  onClaimMission,
  onClaimMilestone,
  onEquipSkin,
  onRebirth,
  onOpenMediaModal,
  onToggleStabilizer,
  onFullReset,
}) => {
  const [confirmReset, setConfirmReset] = useState(false);

  const hasMissionAlert = gameState.missions.some((m) => m.completed);
  const rank = getCurrentRank(gameState.level);
  const relicBonuses = getRelicBonuses(gameState.relics);
  const curMult = getRebirthMultiplier(gameState.rebirths);
  const nextMult = getRebirthMultiplier(gameState.rebirths + 1);

  const tabs: { id: DrawerTab; label: string; alert?: boolean; special?: boolean }[] = [
    { id: 'upgrades', label: '⚡ Mejoras' },
    { id: 'capsules', label: '💊 Cápsulas' },
    { id: 'bombs', label: '💣 Bombas' },
    { id: 'chests', label: '🎁 Cofres', special: true },
    { id: 'dopamine', label: '🎛️ Fondo' },
    { id: 'missions', label: '🎯 Misiones', alert: hasMissionAlert },
    { id: 'relics', label: '🔮 Reliquias' },
    { id: 'skins', label: '🎨 Skins' },
    { id: 'rebirth', label: '♻️ Renacer', special: true },
    { id: 'stats', label: '📊 Info' },
  ];

  return (
    <aside
      className={`fixed top-0 right-0 h-full w-full sm:w-[490px] z-40 glass-panel border-l border-cyan-500/30 transform transition-transform duration-300 ease-out flex flex-col ${
        open ? 'translate-x-0' : 'translate-x-full'
      }`}
    >
      <div className="p-3.5 border-b border-slate-800 flex items-center justify-between bg-slate-950/70">
        <div>
          <h2 className="font-orbitron font-bold text-base text-cyan-300 tracking-wider">
            ARSENAL & TIENDA OVERDRIVE
          </h2>
          <p className="text-[11px] text-slate-400">
            11 Tiers de Cápsulas, Bombas de Skins y Renacimiento
          </p>
        </div>
        <button
          onClick={onClose}
          className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-rose-500/20 hover:text-rose-400 border border-slate-700 flex items-center justify-center text-slate-300 font-bold cursor-pointer"
        >
          ✕
        </button>
      </div>

      <div className="grid grid-cols-3 sm:grid-cols-5 gap-1 p-2 bg-slate-950/50 border-b border-slate-800">
        {tabs.map((t) => (
          <button
            key={t.id}
            onClick={() => onSelectTab(t.id)}
            className={`relative py-1.5 px-1 rounded-lg text-[10px] font-orbitron font-bold cursor-pointer transition truncate ${
              activeTab === t.id
                ? 'bg-cyan-500/20 text-cyan-300 border border-cyan-400/40'
                : t.special
                  ? 'text-fuchsia-300 hover:text-white'
                  : 'text-slate-400 hover:text-white'
            }`}
          >
            {t.label}
            {t.alert && (
              <span className="ml-1 px-1 bg-amber-400 text-slate-950 rounded-full text-[9px]">
                !
              </span>
            )}
          </button>
        ))}
      </div>

      <div className="flex-1 overflow-y-auto p-3.5 space-y-4">
        {activeTab === 'upgrades' && (
          <div className="space-y-4">
            <div>
              <h3 className="font-orbitron text-xs uppercase text-cyan-400 mb-2">
                ⚡ Mejoras Activas de Click
              </h3>
              <div className="space-y-2">
                {UPGRADES_CATALOG.filter((u) => u.cat === 'active').map((upg) => {
                  const lvl = gameState.upgrades[upg.id] || 0;
                  const cost = getUpgradeCost(upg, lvl);
                  const isMax = lvl >= upg.max;
                  const can = !isMax && gameState.energy >= cost;
                  return (
                    <div
                      key={upg.id}
                      className="bg-slate-900/85 border border-slate-800 rounded-2xl p-2.5 flex items-center justify-between gap-2"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-9 h-9 rounded-xl bg-slate-800 flex items-center justify-center text-lg shrink-0">
                          {upg.icon}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="font-orbitron font-bold text-xs text-white truncate">
                              {upg.name}
                            </span>
                            <span className="text-[10px] px-1.5 rounded bg-slate-800 text-cyan-300 tabular-nums">
                              Nv.{lvl}
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-400 truncate">{upg.desc}</p>
                        </div>
                      </div>
                      <button
                        onClick={() => onBuyUpgrade(upg.id)}
                        disabled={!can}
                        className={`shrink-0 px-2.5 py-1.5 rounded-xl font-orbitron font-bold text-[11px] tabular-nums ${
                          isMax
                            ? 'bg-slate-800 text-slate-500'
                            : can
                              ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 cursor-pointer'
                              : 'bg-slate-800 text-slate-500'
                        }`}
                      >
                        {isMax ? 'MÁX' : `⚡ ${formatNumber(cost)}`}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800">
              <h3 className="font-orbitron text-xs uppercase text-emerald-400 mb-2">
                🤖 Drones & Reactores Pasivos
              </h3>
              <div className="space-y-2">
                {UPGRADES_CATALOG.filter((u) => u.cat === 'passive').map((upg) => {
                  const lvl = gameState.upgrades[upg.id] || 0;
                  const cost = getUpgradeCost(upg, lvl);
                  const isMax = lvl >= upg.max;
                  const can = !isMax && gameState.energy >= cost;
                  return (
                    <div
                      key={upg.id}
                      className="bg-slate-900/85 border border-slate-800 rounded-2xl p-2.5 flex items-center justify-between gap-2"
                    >
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-9 h-9 rounded-xl bg-slate-800 flex items-center justify-center text-lg shrink-0">
                          {upg.icon}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="font-orbitron font-bold text-xs text-white truncate">
                              {upg.name}
                            </span>
                            <span className="text-[10px] px-1.5 rounded bg-slate-800 text-cyan-300 tabular-nums">
                              Nv.{lvl}
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-400 truncate">{upg.desc}</p>
                        </div>
                      </div>
                      <button
                        onClick={() => onBuyUpgrade(upg.id)}
                        disabled={!can}
                        className={`shrink-0 px-2.5 py-1.5 rounded-xl font-orbitron font-bold text-[11px] tabular-nums ${
                          isMax
                            ? 'bg-slate-800 text-slate-500'
                            : can
                              ? 'bg-cyan-500 hover:bg-cyan-400 text-slate-950 cursor-pointer'
                              : 'bg-slate-800 text-slate-500'
                        }`}
                      >
                        {isMax ? 'MÁX' : `⚡ ${formatNumber(cost)}`}
                      </button>
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'capsules' && (
          <div className="space-y-3">
            <div className="bg-cyan-950/30 border border-cyan-500/30 rounded-2xl p-3 text-xs">
              <div className="font-orbitron font-bold text-cyan-300">
                💊 Cápsulas de Artefactos (11 Tiers)
              </div>
              <p className="text-slate-300 text-[11px] mt-0.5">
                ¡Rómpelas a clicks! Las reliquias de mayor rango (
                <b>Inigualable, Legado, Final Boss</b>) SOLO salen en las cápsulas
                superiores.
              </p>
            </div>
            <div className="space-y-2.5">
              {TIERS.map((tier) => {
                const tierRelics = RELICS_CATALOG.filter(
                  (r) => r.tier >= tier.minTierDrop && r.tier <= tier.maxTierDrop,
                );
                const unowned = tierRelics.filter(
                  (r) => !gameState.relics.includes(r.id),
                );
                const allOwned = unowned.length === 0;
                return (
                  <div
                    key={tier.id}
                    className={`bg-slate-900/85 border rounded-2xl p-3 flex items-center justify-between gap-2 tier-${tier.id}`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div
                        className="w-11 h-11 rounded-xl bg-slate-950 border border-current flex items-center justify-center text-2xl shrink-0"
                        style={{ boxShadow: `0 0 12px ${tier.color}44` }}
                      >
                        💊
                      </div>
                      <div className="min-w-0">
                        <div className="font-orbitron font-black text-xs truncate">
                          Cápsula {tier.name}
                        </div>
                        <div className="text-[10px] text-slate-300">
                          {tier.minTierDrop === tier.maxTierDrop
                            ? `Exclusiva Tier ${tier.name}`
                            : `Contiene Tiers ${TIERS[tier.minTierDrop].name} - ${TIERS[tier.maxTierDrop].name}`}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          Golpes para romper: {tier.hits} • Restantes: {unowned.length}
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => onStartUnbox('capsule', tier.id)}
                      disabled={allOwned}
                      className={`shrink-0 px-3 py-2 rounded-xl font-orbitron font-bold text-xs transition tabular-nums ${
                        allOwned
                          ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                          : 'bg-amber-400 hover:bg-amber-300 text-slate-950 shadow-md cursor-pointer'
                      }`}
                    >
                      {allOwned ? 'COMPLETO' : `${formatNumber(tier.costGems)} 💎`}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === 'bombs' && (
          <div className="space-y-3">
            <div className="bg-rose-950/30 border border-rose-500/30 rounded-2xl p-3 text-xs">
              <div className="font-orbitron font-bold text-rose-300">
                💣 Bombas de Skins (11 Tiers)
              </div>
              <p className="text-slate-300 text-[11px] mt-0.5">
                ¡Detónalas a clicks! Las skins exclusivas (
                <b>Inigualable, Legado, Final Boss</b>) SOLO se obtienen detonando las
                bombas de élite.
              </p>
            </div>
            <div className="space-y-2.5">
              {TIERS.map((tier) => {
                const tierSkins = SKINS_CATALOG.filter(
                  (s) => s.tier >= tier.minTierDrop && s.tier <= tier.maxTierDrop,
                );
                const unowned = tierSkins.filter(
                  (s) => !gameState.unlockedSkins.includes(s.id),
                );
                const allOwned = unowned.length === 0;
                return (
                  <div
                    key={tier.id}
                    className={`bg-slate-900/85 border rounded-2xl p-3 flex items-center justify-between gap-2 tier-${tier.id}`}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div
                        className="w-11 h-11 rounded-xl bg-slate-950 border border-current flex items-center justify-center text-2xl shrink-0"
                        style={{ boxShadow: `0 0 12px ${tier.color}44` }}
                      >
                        💣
                      </div>
                      <div className="min-w-0">
                        <div className="font-orbitron font-black text-xs truncate">
                          Bomba {tier.name}
                        </div>
                        <div className="text-[10px] text-slate-300">
                          {tier.minTierDrop === tier.maxTierDrop
                            ? `Skins Exclusivas ${tier.name}`
                            : `Skins Tiers ${TIERS[tier.minTierDrop].name} - ${TIERS[tier.maxTierDrop].name}`}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          Clicks detonación: {tier.hits} • Restantes: {unowned.length}
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => onStartUnbox('bomb', tier.id)}
                      disabled={allOwned}
                      className={`shrink-0 px-3 py-2 rounded-xl font-orbitron font-bold text-xs transition tabular-nums ${
                        allOwned
                          ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                          : 'bg-rose-500 hover:bg-rose-400 text-white shadow-md cursor-pointer'
                      }`}
                    >
                      {allOwned ? 'COMPLETO' : `${formatNumber(tier.costGems)} 💎`}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === 'chests' && (
          <div className="space-y-3">
            <div className="bg-fuchsia-950/35 border border-fuchsia-500/35 rounded-2xl p-3 text-xs">
              <div className="font-orbitron font-bold text-fuchsia-300">
                🎁 Cofres Dopamínicos (Efectos de Fondo)
              </div>
              <p className="text-slate-300 text-[11px] mt-0.5">
                Desbloquea animaciones caóticas y eventos en el fondo mientras tu bola
                sigue moviéndose (67, Loro Animador, Avión y Torres, Bomba cada 2m, Foto
                cada 5m y más). Todos se activan por defecto y puedes gestionarlos en{' '}
                <b>🎛️ Fondo</b>.
              </p>
              <button
                onClick={() => onSelectTab('dopamine')}
                className="mt-2 px-3 py-1.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/40 text-cyan-200 font-orbitron font-bold text-[10px] cursor-pointer"
              >
                🎛️ Abrir Panel de Fondo ({gameState.enabledDopamine.length}/
                {gameState.unlockedDopamine.length} activos)
              </button>
            </div>

            <div className="space-y-2.5">
              {DOPAMINE_CHEST_TIERS.map((chest) => {
                const items = DOPAMINE_CATALOG.filter((d) => d.chestTier === chest.id);
                const unowned = items.filter(
                  (d) => !gameState.unlockedDopamine.includes(d.id),
                );
                const allOwned = unowned.length === 0;
                return (
                  <div
                    key={chest.id}
                    className="bg-slate-900/85 border rounded-2xl p-3 flex items-center justify-between gap-2"
                    style={{ borderColor: `${chest.color}66` }}
                  >
                    <div className="flex items-center gap-2.5 min-w-0">
                      <div
                        className="w-11 h-11 rounded-xl bg-slate-950 border flex items-center justify-center text-2xl shrink-0"
                        style={{
                          borderColor: chest.color,
                          boxShadow: `0 0 12px ${chest.color}44`,
                        }}
                      >
                        🎁
                      </div>
                      <div className="min-w-0">
                        <div
                          className="font-orbitron font-black text-xs truncate"
                          style={{ color: chest.color }}
                        >
                          Cofre Dopamínico {chest.name}
                        </div>
                        <div className="text-[10px] text-slate-300 truncate">
                          {items.map((it) => `${it.icon} ${it.name}`).join(' • ')}
                        </div>
                        <div className="text-[10px] text-slate-400">
                          Golpes: {chest.hits} • Restantes: {unowned.length} /{' '}
                          {items.length}
                        </div>
                      </div>
                    </div>
                    <button
                      onClick={() => onStartUnbox('chest', chest.id)}
                      disabled={allOwned}
                      className={`shrink-0 px-3 py-2 rounded-xl font-orbitron font-bold text-xs transition tabular-nums ${
                        allOwned
                          ? 'bg-slate-800 text-slate-500 cursor-not-allowed'
                          : 'bg-fuchsia-500 hover:bg-fuchsia-400 text-slate-950 shadow-md cursor-pointer'
                      }`}
                    >
                      {allOwned ? 'COMPLETO' : `${formatNumber(chest.costGems)} 💎`}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === 'dopamine' && (
          <div className="space-y-3">
            <div className="bg-slate-900/90 border border-cyan-500/35 rounded-2xl p-3">
              <div className="flex items-center justify-between gap-2">
                <div>
                  <h3 className="font-orbitron font-bold text-xs text-cyan-300 uppercase">
                    🎛️ Panel de Artículos Dopamínicos
                  </h3>
                  <p className="text-[10px] text-slate-400 mt-0.5">
                    Desbloqueados: {gameState.unlockedDopamine.length} /{' '}
                    {DOPAMINE_CATALOG.length} • Todos vienen activos por defecto.
                  </p>
                </div>
                {gameState.unlockedDopamine.length > 0 && (
                  <div className="flex gap-1.5">
                    <button
                      onClick={() => onSetAllDopamine(true)}
                      className="px-2 py-1 rounded-lg bg-emerald-500/20 hover:bg-emerald-500/30 border border-emerald-400/40 text-emerald-300 font-orbitron font-bold text-[9px] cursor-pointer"
                    >
                      Activar Todo
                    </button>
                    <button
                      onClick={() => onSetAllDopamine(false)}
                      className="px-2 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/30 border border-rose-400/40 text-rose-300 font-orbitron font-bold text-[9px] cursor-pointer"
                    >
                      Desactivar
                    </button>
                  </div>
                )}
              </div>
            </div>

            {gameState.unlockedDopamine.length === 0 && (
              <div className="bg-slate-900/70 border border-slate-800 rounded-2xl p-4 text-center">
                <div className="text-2xl mb-1">🎁</div>
                <p className="text-xs text-slate-300">
                  Aún no has abierto ningún Cofre Dopamínico.
                </p>
                <button
                  onClick={() => onSelectTab('chests')}
                  className="mt-2.5 px-3 py-1.5 rounded-xl bg-fuchsia-500 text-slate-950 font-orbitron font-bold text-[10px] cursor-pointer"
                >
                  Ir a 🎁 Cofres Dopamínicos
                </button>
              </div>
            )}

            <div className="space-y-2">
              {DOPAMINE_CATALOG.map((item) => {
                const unlocked = gameState.unlockedDopamine.includes(item.id);
                const enabled = gameState.enabledDopamine.includes(item.id);
                const chestTier = DOPAMINE_CHEST_TIERS[item.chestTier];

                return (
                  <div
                    key={item.id}
                    className={`rounded-2xl p-3 border transition ${
                      !unlocked
                        ? 'bg-slate-950/60 border-slate-800 opacity-50'
                        : enabled
                          ? 'bg-slate-900/90 border-emerald-500/40'
                          : 'bg-slate-900/60 border-slate-700'
                    }`}
                  >
                    <div className="flex items-center justify-between gap-2">
                      <div className="flex items-center gap-2.5 min-w-0">
                        <div className="w-9 h-9 rounded-xl bg-slate-950 border border-slate-700 flex items-center justify-center text-lg shrink-0">
                          {unlocked ? item.icon : '🔒'}
                        </div>
                        <div className="min-w-0">
                          <div className="flex items-center gap-1.5">
                            <span className="font-orbitron font-bold text-xs text-white truncate">
                              {item.name}
                            </span>
                            <span
                              className="text-[8px] font-orbitron uppercase px-1.5 py-0.5 rounded bg-slate-950 border"
                              style={{
                                color: chestTier.color,
                                borderColor: `${chestTier.color}66`,
                              }}
                            >
                              {chestTier.name}
                            </span>
                          </div>
                          <p className="text-[10px] text-slate-400">{item.desc}</p>
                        </div>
                      </div>

                      {unlocked ? (
                        <button
                          onClick={() => onToggleDopamine(item.id)}
                          className={`shrink-0 px-3 py-1.5 rounded-xl font-orbitron font-bold text-[10px] cursor-pointer transition ${
                            enabled
                              ? 'bg-emerald-500 text-slate-950 shadow'
                              : 'bg-slate-800 text-slate-400 border border-slate-700'
                          }`}
                        >
                          {enabled ? 'ACTIVO' : 'INACTIVO'}
                        </button>
                      ) : (
                        <span className="shrink-0 text-[9px] font-orbitron text-slate-500">
                          Cofre {chestTier.name}
                        </span>
                      )}
                    </div>

                    {unlocked && item.id === 'dop_bomb_2m' && enabled && (
                      <div className="mt-2 pt-2 border-t border-slate-800 flex items-center justify-between text-[10px]">
                        <span className="text-amber-300 tabular-nums">
                          ⏳ Próxima bomba en: {Math.floor(bombCountdownSec / 60)}:
                          {String(bombCountdownSec % 60).padStart(2, '0')}
                        </span>
                        <button
                          onClick={onTestDopamineBomb}
                          className="px-2.5 py-1 rounded-lg bg-rose-500/20 hover:bg-rose-500/35 border border-rose-400/50 text-rose-200 font-orbitron font-bold text-[9px] cursor-pointer"
                        >
                          💣 Lanzar Bomba Ahora
                        </button>
                      </div>
                    )}

                    {unlocked && item.id === 'dop_photo_5m' && (
                      <div className="mt-2 pt-2 border-t border-slate-800 flex flex-wrap items-center justify-between gap-2 text-[10px]">
                        <span className="text-cyan-300 tabular-nums">
                          {enabled
                            ? `⏳ Próxima foto en: ${Math.floor(photoCountdownSec / 60)}:${String(
                                photoCountdownSec % 60,
                              ).padStart(2, '0')}`
                            : 'Efecto desactivado'}
                        </span>
                        <div className="flex items-center gap-1.5">
                          <label className="cursor-pointer px-2.5 py-1 rounded-lg bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-orbitron font-bold text-[9px]">
                            📸 {gameState.dopaminePhotoSrc ? 'Cambiar Foto' : 'Elegir Foto'}
                            <input
                              type="file"
                              accept="image/*"
                              onChange={onUploadDopaminePhoto}
                              className="hidden"
                            />
                          </label>
                          {gameState.dopaminePhotoSrc && (
                            <button
                              onClick={onClearDopaminePhoto}
                              className="px-2 py-1 rounded-lg bg-slate-800 hover:bg-rose-500/30 text-rose-300 font-bold text-[9px] cursor-pointer"
                            >
                              ✕
                            </button>
                          )}
                          {enabled && (
                            <button
                              onClick={onTestDopaminePhoto}
                              className="px-2.5 py-1 rounded-lg bg-amber-400/20 hover:bg-amber-400/35 border border-amber-400/50 text-amber-200 font-orbitron font-bold text-[9px] cursor-pointer"
                            >
                              🖼️ Mostrar Ahora
                            </button>
                          )}
                        </div>
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === 'missions' && (
          <div className="space-y-4">
            <div>
              <h3 className="font-orbitron text-xs uppercase text-purple-400 mb-2">
                🎯 Misiones Dinámicas
              </h3>
              <div className="space-y-2">
                {gameState.missions.map((m) => {
                  const pct = Math.min(100, (m.progress / m.target) * 100);
                  return (
                    <div
                      key={m.id}
                      className={`rounded-xl p-3 border ${
                        m.completed
                          ? 'bg-purple-950/50 border-amber-400'
                          : 'bg-slate-900/80 border-slate-800'
                      }`}
                    >
                      <div className="flex justify-between text-xs mb-1">
                        <span className="font-semibold text-white">{m.title}</span>
                        <span className="font-orbitron font-bold text-amber-300">
                          +{m.rewardGems} 💎
                        </span>
                      </div>
                      <div className="flex items-center gap-2">
                        <div className="flex-1 h-2 bg-slate-800 rounded-full overflow-hidden">
                          <div
                            className="h-full bg-purple-500 transition-all duration-150"
                            style={{ width: `${pct}%` }}
                          />
                        </div>
                        {m.completed && (
                          <button
                            onClick={() => onClaimMission(m.id)}
                            className="px-2.5 py-1 rounded-lg bg-amber-400 hover:bg-amber-300 text-slate-950 font-orbitron font-bold text-[10px] cursor-pointer"
                          >
                            Reclamar
                          </button>
                        )}
                      </div>
                    </div>
                  );
                })}
              </div>
            </div>

            <div className="pt-3 border-t border-slate-800">
              <h3 className="font-orbitron text-xs uppercase text-amber-400 mb-2">
                🏆 Hitos de Nivel (Cada 10 Niveles)
              </h3>
              <div className="space-y-1.5">
                {MINIGAMES_CATALOG.map((mg) => {
                  const reached = gameState.level >= mg.lvl;
                  const claimed = gameState.claimedMilestones.includes(mg.lvl);
                  const rew = Math.ceil(mg.lvl * 2 * (1 + relicBonuses.gemMult));
                  return (
                    <div
                      key={mg.lvl}
                      className="bg-slate-900/70 border border-slate-800 rounded-xl px-3 py-2 flex items-center justify-between text-xs"
                    >
                      <span>
                        {claimed ? '✅' : reached ? '🎁' : '🔒'} Nivel {mg.lvl} (
                        {mg.name})
                      </span>
                      {claimed ? (
                        <span className="text-emerald-400 text-[10px]">Reclamado</span>
                      ) : reached ? (
                        <button
                          onClick={() => onClaimMilestone(mg.lvl)}
                          className="px-2 py-0.5 rounded bg-amber-400 hover:bg-amber-300 text-slate-950 font-orbitron font-bold text-[10px] cursor-pointer"
                        >
                          +{rew} 💎
                        </button>
                      ) : (
                        <span className="text-slate-500 font-orbitron text-[10px]">
                          +{rew} 💎
                        </span>
                      )}
                    </div>
                  );
                })}
              </div>
            </div>
          </div>
        )}

        {activeTab === 'relics' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-orbitron text-xs uppercase text-amber-300">
                🔮 Colección de Reliquias
              </h3>
              <span className="font-orbitron text-xs text-slate-400 tabular-nums">
                {gameState.relics.length} / {RELICS_CATALOG.length}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {RELICS_CATALOG.map((rel) => {
                const owned = gameState.relics.includes(rel.id);
                const tier = TIERS[rel.tier];
                return (
                  <div
                    key={rel.id}
                    className={`rounded-xl p-2.5 border tier-${rel.tier} ${
                      owned ? 'bg-slate-900/90' : 'bg-slate-950/60 opacity-45'
                    }`}
                  >
                    <div className="flex items-center justify-between mb-1">
                      <span className="text-lg">{owned ? rel.icon : '❓'}</span>
                      <span className="text-[8px] font-orbitron uppercase px-1.5 py-0.5 rounded bg-slate-950 border border-current">
                        {tier.name}
                      </span>
                    </div>
                    <div className="font-orbitron font-bold text-[11px] text-white truncate">
                      {owned ? rel.name : 'Reliquia Oculta'}
                    </div>
                    <div className="text-[10px] text-emerald-400 font-semibold mt-0.5">
                      {owned ? rel.desc : `Cápsula ${tier.name}`}
                    </div>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === 'skins' && (
          <div className="space-y-3">
            <div className="flex items-center justify-between">
              <h3 className="font-orbitron text-xs uppercase text-cyan-300">
                🎨 Armario de Skins
              </h3>
              <span className="font-orbitron text-xs text-slate-400 tabular-nums">
                {gameState.unlockedSkins.length} / {SKINS_CATALOG.length}
              </span>
            </div>
            <div className="grid grid-cols-2 gap-2">
              {SKINS_CATALOG.map((sk) => {
                const owned = gameState.unlockedSkins.includes(sk.id);
                const eq = gameState.equippedSkin === sk.id;
                const tier = TIERS[sk.tier];
                return (
                  <div
                    key={sk.id}
                    className={`rounded-xl p-2.5 border tier-${sk.tier} flex flex-col justify-between gap-2 ${
                      eq
                        ? 'bg-cyan-950/50 ring-2 ring-cyan-400'
                        : owned
                          ? 'bg-slate-900/90'
                          : 'bg-slate-950/60 opacity-50'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between mb-1">
                        <span
                          className="w-4 h-4 rounded-full"
                          style={{
                            background: tier.color,
                            boxShadow: `0 0 8px ${tier.color}`,
                          }}
                        />
                        <span className="text-[8px] font-orbitron uppercase px-1.5 py-0.5 rounded bg-slate-950 border border-current">
                          {tier.name}
                        </span>
                      </div>
                      <div className="font-orbitron font-bold text-[11px] text-white truncate">
                        {owned ? sk.name : 'Skin Bloqueada'}
                      </div>
                    </div>
                    {owned ? (
                      <button
                        onClick={() => onEquipSkin(sk.id)}
                        className={`w-full py-1 rounded-lg font-orbitron font-bold text-[10px] cursor-pointer ${
                          eq
                            ? 'bg-cyan-400 text-slate-950'
                            : 'bg-slate-800 hover:bg-slate-700 text-cyan-300'
                        }`}
                      >
                        {eq ? 'Equipada' : 'Equipar'}
                      </button>
                    ) : (
                      <div className="text-[9px] text-slate-400 text-center">
                        Bomba {tier.name}
                      </div>
                    )}
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {activeTab === 'rebirth' && (
          <div className="space-y-4">
            <div className="bg-gradient-to-br from-fuchsia-950/60 via-purple-950/50 to-slate-900 border border-fuchsia-500/40 rounded-2xl p-4">
              <div className="flex items-center justify-between mb-2">
                <span className="font-orbitron font-black text-base text-fuchsia-300">
                  ♻️ RENACIMIENTO
                </span>
                <span className="px-2.5 py-0.5 rounded-full bg-fuchsia-500/20 border border-fuchsia-400 font-orbitron font-bold text-xs text-white">
                  Nivel R{gameState.rebirths}
                </span>
              </div>
              <p className="text-xs text-slate-300 leading-relaxed">
                Al alcanzar el <b>Nivel 200</b>, puedes reiniciar tu Energía, Nivel y
                Mejoras básicas para evolucionar permanentemente:
              </p>
              <ul className="text-xs text-slate-200 space-y-1.5 mt-3 bg-slate-950/60 p-3 rounded-xl border border-slate-800">
                <li>
                  ✨ <b>Multiplicador Permanente:</b>{' '}
                  <span className="text-emerald-400 font-bold">
                    {curMult.toFixed(1)}x → {nextMult.toFixed(1)}x
                  </span>
                </li>
                <li>
                  🖼️ <b>Renacimiento 1:</b> ¡2 Objetivos simultáneos en pantalla!
                </li>
                <li>
                  🖼️ <b>Renacimiento 2:</b> ¡3 Objetivos simultáneos en pantalla!
                </li>
                <li>
                  🎞️ <b>Renacimiento 3:</b> ¡Desbloquea soporte para{' '}
                  <b>GIFs animados</b>!
                </li>
                <li>
                  🎬 <b>Renacimiento 4+:</b> ¡Desbloquea soporte para{' '}
                  <b>Videos en bucle</b> + 4 Slots!
                </li>
                <li>
                  🔒{' '}
                  <i>
                    Conservas todos tus Cristales, Reliquias, Skins y Récords de
                    Minijuegos.
                  </i>
                </li>
              </ul>

              <button
                onClick={onRebirth}
                disabled={gameState.level < MAX_LEVEL}
                className={`mt-4 w-full py-3 rounded-xl font-orbitron font-black text-xs uppercase tracking-wider transition ${
                  gameState.level >= MAX_LEVEL
                    ? 'bg-gradient-to-r from-fuchsia-500 to-amber-500 hover:from-fuchsia-400 hover:to-amber-400 text-slate-950 shadow-lg cursor-pointer'
                    : 'bg-slate-800 text-slate-500 cursor-not-allowed'
                }`}
              >
                {gameState.level >= MAX_LEVEL
                  ? `♻️ ¡RENACER AHORA (R${gameState.rebirths + 1})!`
                  : `Requiere Nivel 200 (Actual: ${gameState.level})`}
              </button>
            </div>

            <button
              onClick={onOpenMediaModal}
              className="w-full py-2.5 rounded-xl bg-cyan-500/20 hover:bg-cyan-500/30 border border-cyan-400/40 text-cyan-300 font-orbitron font-bold text-xs cursor-pointer"
            >
              🖼️ Configurar Fotos / GIFs / Videos en tus Slots
            </button>
          </div>
        )}

        {activeTab === 'stats' && (
          <div className="space-y-4">
            <div className="bg-slate-900/80 rounded-2xl p-4 border border-slate-800 space-y-2 text-xs">
              <h3 className="font-orbitron text-xs uppercase text-cyan-400 mb-2">
                📊 Telemetría Global
              </h3>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Rango Actual:</span>
                <span className="font-bold text-cyan-300">
                  {rank.name} (Nv.{gameState.level})
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Renacimientos:</span>
                <span className="font-bold text-fuchsia-400">
                  R{gameState.rebirths} ({curMult.toFixed(1)}x)
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Bono de Reliquias:</span>
                <span className="font-bold text-emerald-400">
                  +{Math.round(relicBonuses.energyMult * 100)}% Energía / +
                  {Math.round(relicBonuses.cpsMult * 100)}% CPS
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Energía Histórica:</span>
                <span className="font-orbitron text-slate-200 tabular-nums">
                  {formatNumber(gameState.totalEnergyEarned)}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Clicks Totales:</span>
                <span className="font-orbitron text-slate-200 tabular-nums">
                  {gameState.stats.totalClicks.toLocaleString('es-ES')}
                </span>
              </div>
              <div className="flex justify-between py-1 border-b border-slate-800">
                <span className="text-slate-400">Críticos:</span>
                <span className="font-orbitron text-amber-300 tabular-nums">
                  {gameState.stats.totalCrits.toLocaleString('es-ES')}
                </span>
              </div>
              <div className="flex justify-between py-1">
                <span className="text-slate-400">Bloqueos Anti-Cheat:</span>
                <span className="font-orbitron text-rose-400 tabular-nums">
                  {gameState.stats.anticheatInfractions}
                </span>
              </div>
            </div>

            <div className="bg-slate-900/80 rounded-2xl p-4 border border-slate-800">
              <div className="flex items-center justify-between mb-1">
                <span className="font-orbitron text-xs text-cyan-300">
                  Estabilizador de Velocidad
                </span>
                <span className="text-xs font-bold text-emerald-400">
                  {gameState.stabilizer ? 'Activo' : 'Desactivado'}
                </span>
              </div>
              <button
                onClick={onToggleStabilizer}
                className="mt-2 w-full py-2 rounded-xl bg-cyan-500/20 border border-cyan-500/40 text-cyan-300 text-xs font-orbitron font-bold cursor-pointer"
              >
                Alternar Estabilizador
              </button>
            </div>

            <div className="bg-rose-950/20 rounded-2xl p-4 border border-rose-500/30">
              <h3 className="font-orbitron text-xs uppercase text-rose-400 mb-2">
                ⚠️ Reinicio Total
              </h3>
              {!confirmReset ? (
                <button
                  onClick={() => setConfirmReset(true)}
                  className="w-full py-2 rounded-xl bg-rose-600/80 hover:bg-rose-600 text-white font-orbitron font-bold text-xs cursor-pointer"
                >
                  Borrar Todo el Progreso
                </button>
              ) : (
                <div className="flex gap-2">
                  <button
                    onClick={() => {
                      setConfirmReset(false);
                      onFullReset();
                    }}
                    className="flex-1 py-2 rounded-xl bg-rose-600 text-white font-orbitron font-bold text-xs cursor-pointer"
                  >
                    Sí, Borrar
                  </button>
                  <button
                    onClick={() => setConfirmReset(false)}
                    className="flex-1 py-2 rounded-xl bg-slate-800 text-slate-300 font-orbitron font-bold text-xs cursor-pointer"
                  >
                    Cancelar
                  </button>
                </div>
              )}
            </div>
          </div>
        )}
      </div>
    </aside>
  );
};
