import React from 'react';
import { getUnlockedSlotCount } from '../game/catalogs';
import { SlotMedia } from '../game/types';

interface MediaModalProps {
  open: boolean;
  rebirths: number;
  slotMedia: SlotMedia[];
  onUpload: (e: React.ChangeEvent<HTMLInputElement>, slotIdx: number) => void;
  onClear: (slotIdx: number) => void;
  onClose: () => void;
}

export const MediaModal: React.FC<MediaModalProps> = ({
  open,
  rebirths,
  slotMedia,
  onUpload,
  onClear,
  onClose,
}) => {
  if (!open) return null;

  const unlockedSlots = getUnlockedSlotCount(rebirths);
  const allowGif = rebirths >= 3;
  const allowVideo = rebirths >= 4;

  let acceptStr = 'image/png,image/jpeg,image/webp';
  let formatHint = 'Imagen (PNG/JPG/WebP)';
  if (allowVideo) {
    acceptStr = 'image/*,video/mp4,video/webm';
    formatHint = 'Imagen, GIF o Video (MP4/WebM)';
  } else if (allowGif) {
    acceptStr = 'image/*';
    formatHint = 'Imagen o GIF animado';
  }

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/88 backdrop-blur-md flex items-center justify-center p-4">
      <div className="glass-panel max-w-xl w-full rounded-3xl p-5 sm:p-6 border border-cyan-500/40 max-h-[90vh] overflow-y-auto">
        <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-4">
          <div>
            <h2 className="font-orbitron font-bold text-lg text-cyan-300">
              🖼️ MULTIMEDIA DE OBJETIVOS
            </h2>
            <p className="text-xs text-slate-400">
              Desbloquea más espacios, GIFs y Videos al Renacer
            </p>
          </div>
          <button
            onClick={onClose}
            className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-rose-500/20 text-slate-300 font-bold cursor-pointer"
          >
            ✕
          </button>
        </div>

        <div className="bg-slate-900/80 rounded-2xl p-3 border border-fuchsia-500/30 mb-4 text-xs space-y-1">
          <div className="font-orbitron font-bold text-fuchsia-300">
            Progresión de Slots por Renacimiento:
          </div>
          <div className="grid grid-cols-2 sm:grid-cols-4 gap-1.5 text-[11px] pt-1">
            <div className="p-1.5 rounded bg-slate-950 border border-slate-800">
              <span className="text-cyan-400 font-bold">R0:</span> 1 Imagen
            </div>
            <div className="p-1.5 rounded bg-slate-950 border border-slate-800">
              <span className="text-cyan-400 font-bold">R1:</span> 2 Imágenes
            </div>
            <div className="p-1.5 rounded bg-slate-950 border border-slate-800">
              <span className="text-cyan-400 font-bold">R2:</span> 3 Imágenes
            </div>
            <div className="p-1.5 rounded bg-slate-950 border border-slate-800">
              <span className="text-amber-400 font-bold">R3+:</span> GIFs y Videos
            </div>
          </div>
        </div>

        <div className="space-y-3">
          {[0, 1, 2, 3].map((i) => {
            const isUnlocked = i < unlockedSlots;
            const reqRebirth = i === 0 ? 0 : i === 1 ? 1 : i === 2 ? 2 : 4;
            const curMedia = slotMedia[i] || { type: 'default', src: '' };

            return (
              <div
                key={i}
                className={`rounded-2xl p-3.5 border ${
                  isUnlocked
                    ? 'bg-slate-900/90 border-cyan-500/30'
                    : 'bg-slate-950/60 border-slate-800 opacity-60'
                }`}
              >
                <div className="flex items-center justify-between gap-3">
                  <div>
                    <div className="font-orbitron font-bold text-xs text-white flex items-center gap-2">
                      <span>SLOT #{i + 1}</span>
                      <span
                        className={`px-2 py-0.5 rounded text-[10px] ${
                          isUnlocked
                            ? 'bg-emerald-500/20 text-emerald-300'
                            : 'bg-rose-500/20 text-rose-300'
                        }`}
                      >
                        {isUnlocked
                          ? 'DESBLOQUEADO'
                          : `Requiere Renacimiento R${reqRebirth}`}
                      </span>
                    </div>
                    <p className="text-[11px] text-slate-400 mt-0.5">
                      Formatos permitidos: {formatHint}
                    </p>
                  </div>
                  {isUnlocked && (
                    <div className="flex items-center gap-1.5">
                      <label className="cursor-pointer bg-cyan-500 hover:bg-cyan-400 text-slate-950 font-orbitron font-bold text-[11px] px-3 py-1.5 rounded-xl">
                        Subir Archivo
                        <input
                          type="file"
                          accept={acceptStr}
                          onChange={(e) => onUpload(e, i)}
                          className="hidden"
                        />
                      </label>
                      {curMedia.type !== 'default' && (
                        <button
                          onClick={() => onClear(i)}
                          className="px-2.5 py-1.5 rounded-xl bg-slate-800 hover:bg-rose-500/30 text-rose-300 text-xs font-bold cursor-pointer"
                        >
                          ✕
                        </button>
                      )}
                    </div>
                  )}
                </div>
              </div>
            );
          })}
        </div>
      </div>
    </div>
  );
};
