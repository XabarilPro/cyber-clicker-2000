import React, { useCallback, useEffect, useRef, useState } from 'react';
import { MINIGAMES_CATALOG } from '../game/catalogs';
import { sfx } from '../game/sound';
import { MinigameDef, ToastTheme } from '../game/types';

export type MinigameModalMode =
  | { view: 'closed' }
  | { view: 'hub' }
  | { view: 'play'; lvl: number; isPractice: boolean };

interface MinigameModalProps {
  mode: MinigameModalMode;
  playerLevel: number;
  rebirths: number;
  completedMinigames: number[];
  minigameRecords: Record<number, number>;
  primaryAvatarMedia: HTMLImageElement | HTMLVideoElement | null;
  onClose: () => void;
  onLaunch: (lvl: number, isPractice: boolean) => void;
  onComplete: (lvl: number, timeSec: number, isPractice: boolean) => void;
  onPinballRivalWin: (rivalSrc: string) => void;
  onShowToast: (title: string, subtitle: string, theme: ToastTheme) => void;
}

interface InternalMgState {
  def: MinigameDef;
  isPractice: boolean;
  canvas: HTMLCanvasElement;
  ctx: CanvasRenderingContext2D;
  startTime: number;
  elapsed: number;
  running: boolean;
  keys: Record<string, boolean>;
  pointer: { x: number; y: number; down: boolean };
  // eslint-disable-next-line @typescript-eslint/no-explicit-any
  data: Record<string, any>;
}

function drawAvatarCircle(
  ctx: CanvasRenderingContext2D,
  x: number,
  y: number,
  r: number,
  mediaObj: HTMLImageElement | HTMLVideoElement | null,
  fallbackColor = '#00f3ff',
  label = '',
) {
  ctx.save();
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.closePath();
  ctx.clip();

  let hasVisual = false;
  if (mediaObj) {
    if (mediaObj instanceof HTMLVideoElement) {
      hasVisual = mediaObj.readyState >= 2 && mediaObj.videoWidth > 0;
    } else {
      hasVisual = mediaObj.complete && mediaObj.naturalWidth > 0;
    }
  }

  if (hasVisual && mediaObj) {
    ctx.drawImage(mediaObj, x - r, y - r, r * 2, r * 2);
  } else {
    ctx.fillStyle = fallbackColor;
    ctx.fillRect(x - r, y - r, r * 2, r * 2);
    ctx.fillStyle = '#060811';
    ctx.font = `bold ${Math.max(10, Math.floor(r))}px Orbitron`;
    ctx.textAlign = 'center';
    ctx.textBaseline = 'middle';
    ctx.fillText(label || '⚡', x, y);
  }
  ctx.restore();

  ctx.strokeStyle = fallbackColor;
  ctx.lineWidth = 3;
  ctx.beginPath();
  ctx.arc(x, y, r, 0, Math.PI * 2);
  ctx.stroke();
}

export const MinigameModal: React.FC<MinigameModalProps> = ({
  mode,
  playerLevel,
  rebirths,
  completedMinigames,
  minigameRecords,
  primaryAvatarMedia,
  onClose,
  onLaunch,
  onComplete,
  onPinballRivalWin,
  onShowToast,
}) => {
  const canvasRef = useRef<HTMLCanvasElement | null>(null);
  const timerRef = useRef<HTMLDivElement | null>(null);
  const mgStateRef = useRef<InternalMgState | null>(null);
  const rafIdRef = useRef<number | null>(null);
  const lastTimeRef = useRef<number>(performance.now());
  const timeoutsRef = useRef<number[]>([]);
  const avatarRef = useRef<HTMLImageElement | HTMLVideoElement | null>(primaryAvatarMedia);

  const [pinballReadyToRelease, setPinballReadyToRelease] = useState(false);

  useEffect(() => {
    avatarRef.current = primaryAvatarMedia;
  }, [primaryAvatarMedia]);

  const clearPendingTimeouts = useCallback(() => {
    timeoutsRef.current.forEach((id) => window.clearTimeout(id));
    timeoutsRef.current = [];
  }, []);

  const stopLoop = useCallback(() => {
    if (rafIdRef.current !== null) {
      cancelAnimationFrame(rafIdRef.current);
      rafIdRef.current = null;
    }
    clearPendingTimeouts();
    if (mgStateRef.current) {
      mgStateRef.current.running = false;
      mgStateRef.current = null;
    }
  }, [clearPendingTimeouts]);

  const finishSuccess = useCallback(() => {
    const st = mgStateRef.current;
    if (!st || !st.running) return;
    st.running = false;
    const timeSec = +st.elapsed.toFixed(2);
    const lvl = st.def.lvl;
    const practice = st.isPractice;
    stopLoop();
    onComplete(lvl, timeSec, practice);
  }, [onComplete, stopLoop]);

  const isUnlocked = useCallback(
    (lvl: number) =>
      playerLevel >= lvl || rebirths > 0 || completedMinigames.includes(lvl),
    [playerLevel, rebirths, completedMinigames],
  );

  // Minigame interactive helpers
  const setSnakeDir = useCallback((dx: number, dy: number) => {
    const st = mgStateRef.current;
    if (!st || !st.running || st.def.type !== 'snake') return;
    const cur = st.data.dir as { x: number; y: number };
    if (cur.x === -dx && cur.y === -dy) return;
    st.data.nextDir = { x: dx, y: dy };
  }, []);

  const shiftLane = useCallback((delta: number) => {
    const st = mgStateRef.current;
    if (!st || !st.running || st.def.type !== 'lane_runner') return;
    st.data.lane = Math.max(0, Math.min(2, (st.data.lane as number) + delta));
  }, []);

  const appendDefuseDigit = useCallback(
    (n: number) => {
      const st = mgStateRef.current;
      if (!st || !st.running || st.def.type !== 'bomb_defuse') return;
      if ((st.data.guess as string).length >= 4) return;
      st.data.guess += String(n);
      if ((st.data.guess as string).length === 4) {
        const val = parseInt(st.data.guess as string, 10);
        if (val === st.data.secret) {
          finishSuccess();
        } else {
          st.data.hint =
            val < st.data.secret
              ? `⬆️ ${val} es MENOR que el código`
              : `⬇️ ${val} es MAYOR que el código`;
          st.data.guess = '';
          sfx.playCrack(0.4);
        }
      }
    },
    [finishSuccess],
  );

  const backspaceDefuseDigit = useCallback(() => {
    const st = mgStateRef.current;
    if (!st || !st.running || st.def.type !== 'bomb_defuse') return;
    st.data.guess = (st.data.guess as string).slice(0, -1);
  }, []);

  const clearDefuseDigit = useCallback(() => {
    const st = mgStateRef.current;
    if (!st || !st.running || st.def.type !== 'bomb_defuse') return;
    st.data.guess = '';
  }, []);

  const handleTap = useCallback(
    (st: InternalMgState) => {
      if (!st.running) return;
      const type = st.def.type;
      const W = st.canvas.width;
      const H = st.canvas.height;

      if (type === 'geo_dash' && st.data.grounded) {
        st.data.vy = -450;
        st.data.grounded = false;
        sfx.playClick(2);
      } else if (type === 'flappy') {
        st.data.vy = -295;
        sfx.playClick(2);
      } else if (type === 'target_shoot') {
        const d = Math.hypot(st.pointer.x - st.data.tx, st.pointer.y - st.data.ty);
        if (d <= st.data.tr + 14) {
          st.data.hits++;
          sfx.playCrit();
          if (st.data.hits >= st.data.goal) return finishSuccess();
          st.data.tx = 50 + Math.random() * (W - 100);
          st.data.ty = 50 + Math.random() * (H - 100);
          const speedMult = 1 + st.data.hits * 0.08;
          const ang = Math.random() * Math.PI * 2;
          const baseSpd = 155 * speedMult;
          st.data.vx = Math.cos(ang) * baseSpd;
          st.data.vy = Math.sin(ang) * baseSpd;
        }
      } else if (type === 'memory' && !st.data.lock) {
        const cols = 4;
        const rows = 3;
        const cw = (W - 80) / cols;
        const ch = (H - 60) / rows;
        const c = Math.floor((st.pointer.x - 40) / cw);
        const r = Math.floor((st.pointer.y - 30) / ch);
        if (c >= 0 && c < cols && r >= 0 && r < rows) {
          const idx = r * cols + c;
          const card = st.data.deck[idx];
          if (card && !card.flipped && !card.matched) {
            card.flipped = true;
            st.data.selected.push(card);
            sfx.playClick(1);
            if (st.data.selected.length === 2) {
              const [a, b] = st.data.selected;
              if (a.icon === b.icon) {
                a.matched = true;
                b.matched = true;
                st.data.selected = [];
                sfx.playBuy();
                if (st.data.deck.every((x: { matched: boolean }) => x.matched)) {
                  finishSuccess();
                }
              } else {
                st.data.lock = true;
                const tid = window.setTimeout(() => {
                  a.flipped = false;
                  b.flipped = false;
                  if (mgStateRef.current === st) {
                    st.data.selected = [];
                    st.data.lock = false;
                  }
                }, 420);
                timeoutsRef.current.push(tid);
              }
            }
          }
        }
      } else if (type === 'simon' && !st.data.showing) {
        const pad = (st.pointer.x > W / 2 ? 1 : 0) + (st.pointer.y > H / 2 ? 2 : 0);
        st.data.activePad = pad;
        const tid = window.setTimeout(() => {
          if (mgStateRef.current === st && !st.data.showing) {
            st.data.activePad = -1;
          }
        }, 180);
        timeoutsRef.current.push(tid);

        if (pad === st.data.seq[st.data.userIdx]) {
          sfx.playClick(pad + 2);
          st.data.userIdx++;
          if (st.data.userIdx >= st.data.step) {
            if (st.data.step >= st.data.seq.length) return finishSuccess();
            st.data.step++;
            st.data.userIdx = 0;
            st.data.showing = true;
            st.data.showIdx = 0;
            st.data.showTimer = 0;
            st.data.gapPhase = true;
            st.data.activePad = -1;
          }
        } else {
          sfx.playAlert();
          st.data.userIdx = 0;
          st.data.showing = true;
          st.data.showIdx = 0;
          st.data.showTimer = 0;
          st.data.gapPhase = true;
          st.data.activePad = -1;
        }
      } else if (type === 'whac_node') {
        const cols = 3;
        const rows = 3;
        const cw = W / cols;
        const ch = H / rows;
        const c = Math.max(0, Math.min(cols - 1, Math.floor(st.pointer.x / cw)));
        const r = Math.max(0, Math.min(rows - 1, Math.floor(st.pointer.y / ch)));
        const hole = r * cols + c;
        if (hole === st.data.activeHole) {
          st.data.hits++;
          sfx.playCrit();
          if (st.data.hits >= st.data.goal) return finishSuccess();
          st.data.activeHole = Math.floor(Math.random() * 9);
          st.data.timer = 0;
        }
      } else if (type === 'lane_runner') {
        if (st.pointer.x < W / 2) shiftLane(-1);
        else shiftLane(1);
      } else if (type === 'boss_omega' || type === 'final_ascend') {
        const d = Math.hypot(st.pointer.x - st.data.bx, st.pointer.y - st.data.by);
        if (d <= 55) {
          st.data.hp--;
          sfx.playCrit();
          if (st.data.hp <= 0) finishSuccess();
        }
      }
    },
    [finishSuccess, shiftLane],
  );

  // Setup and run minigame loop when entering play view
  useEffect(() => {
    if (mode.view !== 'play') {
      stopLoop();
      return;
    }

    const def = MINIGAMES_CATALOG.find((m) => m.lvl === mode.lvl);
    const canvas = canvasRef.current;
    if (!def || !canvas) return;

    const ctx = canvas.getContext('2d');
    if (!ctx) return;

    const parentRect = canvas.parentElement?.getBoundingClientRect();
    const W = Math.max(600, Math.floor(parentRect?.width || 640));
    const H = Math.max(375, Math.floor(parentRect?.height || 380));
    canvas.width = W;
    canvas.height = H;

    const st: InternalMgState = {
      def,
      isPractice: mode.isPractice,
      canvas,
      ctx,
      startTime: performance.now(),
      elapsed: 0,
      running: true,
      keys: {},
      pointer: { x: W / 2, y: H / 2, down: false },
      data: {},
    };

    const type = def.type;
    setPinballReadyToRelease(type === 'pinball_duel');

    const initFlappyPipes = () =>
      Array.from({ length: 6 }, (_, i) => ({
        x: W + i * 240,
        gapY: 95 + Math.random() * (H - 190),
        gapH: 118,
        scored: false,
      }));

    const initDoodlePlats = () =>
      Array.from({ length: 9 }, (_, i) => ({
        x: Math.random() * (W - 90),
        y: H - 40 - i * ((H - 55) / 8),
        w: 90,
      }));

    if (type === 'pinball_duel') {
      const pegs: { x: number; y: number; r: number }[] = [];
      for (let row = 0; row < 6; row++) {
        const cols = row % 2 === 0 ? 7 : 6;
        for (let col = 0; col < cols; col++) {
          pegs.push({
            x: (W / (cols + 1)) * (col + 1),
            y: H * 0.24 + row * (H * 0.11),
            r: 7,
          });
        }
      }
      st.data = {
        released: false,
        pegs,
        rivalImg: null,
        rivalSrc: '',
        balls: [
          {
            id: 'player',
            x: W * 0.42 + (Math.random() * 16 - 8),
            y: 34,
            vx: (Math.random() - 0.5) * 40,
            vy: 0,
            r: 18,
            color: '#00f3ff',
          },
          {
            id: 'rival',
            x: W * 0.58 + (Math.random() * 16 - 8),
            y: 34,
            vx: (Math.random() - 0.5) * 40,
            vy: 0,
            r: 18,
            color: '#ff2a55',
          },
        ],
      };
    } else if (type === 'geo_dash') {
      st.data = {
        playerY: H - 77,
        vy: 0,
        grounded: true,
        rot: 0,
        dist: 0,
        goalDist: 2400,
        spikes: [520, 820, 860, 1180, 1480, 1520, 1850, 2120],
      };
    } else if (type === 'spike_circuit') {
      st.data = {
        ball: { x: W * 0.12, y: 36, vx: 170, vy: 0, r: 17 },
        pauseTimer: 0,
        pausedDone: false,
        trampolineUsed: false,
        ramps: [
          { x1: W * 0.05, y1: H * 0.22, x2: W * 0.58, y2: H * 0.34 },
          { x1: W * 0.86, y1: H * 0.45, x2: W * 0.3, y2: H * 0.6 },
        ],
        trampoline: { x: W * 0.04, y: H * 0.77, w: W * 0.25 },
      };
    } else if (type === 'flappy') {
      st.data = {
        y: H / 2,
        vy: 0,
        passed: 0,
        targetPipes: 6,
        pipes: initFlappyPipes(),
      };
    } else if (type === 'arkanoid') {
      const bricks = [];
      for (let r = 0; r < 3; r++) {
        for (let c = 0; c < 7; c++) {
          bricks.push({
            x: 35 + c * ((W - 70) / 7),
            y: 40 + r * 28,
            w: (W - 90) / 7,
            h: 20,
            alive: true,
          });
        }
      }
      st.data = {
        paddleX: W / 2,
        ball: { x: W / 2, y: H - 60, vx: 230, vy: -240, r: 12 },
        bricks,
      };
    } else if (type === 'meteor_dodge') {
      st.data = { px: W / 2, meteors: [], spawnT: 0, surviveTarget: 12 };
    } else if (type === 'target_shoot') {
      st.data = {
        hits: 0,
        goal: 12,
        tx: W / 2,
        ty: H / 2,
        vx: 145,
        vy: 115,
        tr: 28,
      };
    } else if (type === 'memory') {
      const icons = ['⚡', '💎', '🚀', '🔮', '👑', '🔥'];
      const deck = [...icons, ...icons]
        .sort(() => Math.random() - 0.5)
        .map((ic, idx) => ({ id: idx, icon: ic, flipped: false, matched: false }));
      st.data = { deck, selected: [], lock: false };
    } else if (type === 'snake') {
      const cols = Math.floor(W / 24);
      const rows = Math.floor(H / 24);
      st.data = {
        grid: 24,
        snake: [
          { x: Math.min(8, cols - 2), y: Math.floor(rows / 2) },
          { x: Math.min(7, cols - 3), y: Math.floor(rows / 2) },
        ],
        dir: { x: 1, y: 0 },
        nextDir: { x: 1, y: 0 },
        food: { x: Math.min(14, cols - 2), y: Math.floor(rows / 2) },
        score: 0,
        goal: 8,
        stepT: 0,
      };
    } else if (type === 'simon') {
      const seq = Array.from({ length: 5 }, () => Math.floor(Math.random() * 4));
      st.data = {
        seq,
        step: 1,
        userIdx: 0,
        showing: true,
        showIdx: 0,
        showTimer: 0,
        gapPhase: true,
        activePad: -1,
      };
    } else if (type === 'doodle_jump') {
      st.data = {
        px: W / 2,
        py: H - 80,
        vy: -360,
        climbed: 0,
        goalClimb: 950,
        plats: initDoodlePlats(),
      };
    } else if (type === 'bomb_defuse') {
      st.data = {
        secret: Math.floor(1000 + Math.random() * 9000),
        guess: '',
        hint: 'Introduce 4 dígitos (teclado o botones)',
      };
    } else if (type === 'pong') {
      st.data = {
        py: H / 2,
        aiY: H / 2,
        bx: W / 2,
        by: H / 2,
        vx: 270,
        vy: 160,
        score: 0,
        goal: 3,
      };
    } else if (type === 'maze') {
      st.data = {
        px: 45,
        py: 45,
        walls: [
          { x: W * 0.18, y: 0, w: 22, h: H * 0.68 },
          { x: W * 0.39, y: H * 0.32, w: 22, h: H * 0.68 },
          { x: W * 0.61, y: 0, w: 22, h: H * 0.68 },
          { x: W * 0.81, y: H * 0.32, w: 22, h: H * 0.68 },
        ],
      };
    } else if (type === 'invaders') {
      const enemies = [];
      for (let r = 0; r < 2; r++) {
        for (let c = 0; c < 6; c++) {
          enemies.push({
            x: W * 0.15 + c * ((W * 0.7) / 5),
            y: 45 + r * 45,
            alive: true,
          });
        }
      }
      st.data = { px: W / 2, dir: 1, enemies, bullets: [], fireT: 0 };
    } else if (type === 'whac_node') {
      st.data = {
        hits: 0,
        goal: 12,
        activeHole: Math.floor(Math.random() * 9),
        timer: 0,
      };
    } else if (type === 'gravity_hold') {
      st.data = {
        py: H / 2,
        vy: 0,
        zoneY: H / 2,
        zoneDir: 1,
        holdTime: 0,
        goalHold: 8.0,
      };
    } else if (type === 'lane_runner') {
      st.data = { lane: 1, dodged: 0, goal: 12, obs: [{ lane: 0, y: -40 }] };
    } else if (type === 'boss_omega' || type === 'final_ascend') {
      st.data = {
        hp: type === 'final_ascend' ? 35 : 22,
        maxHp: type === 'final_ascend' ? 35 : 22,
        bx: W / 2,
        by: H / 2,
        vx: 210,
        vy: 150,
      };
    }

    mgStateRef.current = st;
    lastTimeRef.current = performance.now();

    const onKeyDown = (e: KeyboardEvent) => {
      if (!mgStateRef.current || !mgStateRef.current.running) return;
      const cur = mgStateRef.current;
      cur.keys[e.code] = true;
      const t = cur.def.type;

      if (t === 'snake') {
        if (e.code === 'ArrowUp' || e.code === 'KeyW') {
          e.preventDefault();
          setSnakeDir(0, -1);
        } else if (e.code === 'ArrowDown' || e.code === 'KeyS') {
          e.preventDefault();
          setSnakeDir(0, 1);
        } else if (e.code === 'ArrowLeft' || e.code === 'KeyA') {
          e.preventDefault();
          setSnakeDir(-1, 0);
        } else if (e.code === 'ArrowRight' || e.code === 'KeyD') {
          e.preventDefault();
          setSnakeDir(1, 0);
        }
      } else if (t === 'lane_runner') {
        if (e.code === 'ArrowLeft' || e.code === 'KeyA') {
          e.preventDefault();
          shiftLane(-1);
        } else if (e.code === 'ArrowRight' || e.code === 'KeyD') {
          e.preventDefault();
          shiftLane(1);
        }
      } else if (t === 'geo_dash' || t === 'flappy') {
        if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
          e.preventDefault();
          handleTap(cur);
        }
      } else if (t === 'gravity_hold') {
        if (e.code === 'Space' || e.code === 'ArrowUp' || e.code === 'KeyW') {
          e.preventDefault();
        }
      } else if (t === 'bomb_defuse') {
        if (/^[0-9]$/.test(e.key)) {
          e.preventDefault();
          appendDefuseDigit(parseInt(e.key, 10));
        } else if (e.code === 'Backspace') {
          e.preventDefault();
          backspaceDefuseDigit();
        } else if (e.code === 'Delete' || e.code === 'Escape') {
          e.preventDefault();
          clearDefuseDigit();
        }
      }
    };

    const onKeyUp = (e: KeyboardEvent) => {
      if (mgStateRef.current) {
        mgStateRef.current.keys[e.code] = false;
      }
    };

    window.addEventListener('keydown', onKeyDown);
    window.addEventListener('keyup', onKeyUp);

    const spawnSnakeFood = (
      cols: number,
      rows: number,
      snake: { x: number; y: number }[],
    ) => {
      for (let attempt = 0; attempt < 40; attempt++) {
        const fx = Math.floor(Math.random() * cols);
        const fy = Math.floor(Math.random() * rows);
        if (!snake.some((s) => s.x === fx && s.y === fy)) {
          return { x: fx, y: fy };
        }
      }
      return { x: Math.floor(Math.random() * cols), y: Math.floor(Math.random() * rows) };
    };

    const stepFrame = (now: number) => {
      const cur = mgStateRef.current;
      if (!cur || !cur.running) return;

      const dt = Math.min(0.05, Math.max(0, (now - lastTimeRef.current) / 1000));
      lastTimeRef.current = now;

      const t = cur.def.type;
      if (t === 'pinball_duel' && !cur.data.released) {
        cur.elapsed = 0;
      } else {
        cur.elapsed = (now - cur.startTime) / 1000;
      }

      if (timerRef.current) {
        timerRef.current.textContent = cur.elapsed.toFixed(2).padStart(5, '0') + 's';
      }

      const cW = cur.canvas.width;
      const cH = cur.canvas.height;
      const c = cur.ctx;
      const d = cur.data;

      c.clearRect(0, 0, cW, cH);
      c.fillStyle = '#050814';
      c.fillRect(0, 0, cW, cH);

      if (t === 'pinball_duel') {
        c.fillStyle = '#00f3ff';
        for (const p of d.pegs) {
          c.beginPath();
          c.arc(p.x, p.y, p.r, 0, Math.PI * 2);
          c.fill();
        }

        c.fillStyle = 'rgba(16, 185, 129, 0.25)';
        c.fillRect(0, cH - 36, cW, 36);
        c.fillStyle = '#34d399';
        c.font = 'bold 12px Orbitron';
        c.textAlign = 'center';
        c.textBaseline = 'middle';
        c.fillText(
          '🏁 META (LA PRIMERA EN LLEGAR SE QUEDA COMO TU AVATAR) 🏁',
          cW / 2,
          cH - 18,
        );

        if (d.released) {
          const [b0, b1] = d.balls;
          for (const b of d.balls) {
            b.vy += 380 * dt;
            b.x += b.vx * dt;
            b.y += b.vy * dt;

            if (b.x < b.r) {
              b.x = b.r;
              b.vx = Math.abs(b.vx) * 0.85;
            }
            if (b.x > cW - b.r) {
              b.x = cW - b.r;
              b.vx = -Math.abs(b.vx) * 0.85;
            }

            for (const p of d.pegs) {
              const dx = b.x - p.x;
              const dy = b.y - p.y;
              const dist = Math.hypot(dx, dy);
              if (dist < b.r + p.r) {
                const nx = dx / (dist || 1);
                const ny = dy / (dist || 1);
                b.x = p.x + nx * (b.r + p.r + 1);
                b.y = p.y + ny * (b.r + p.r + 1);
                b.vx = nx * 155 + (Math.random() - 0.5) * 90;
                b.vy = ny * 155;
                if (Math.hypot(b.vx, b.vy) < 35) {
                  b.vx += (Math.random() >= 0.5 ? 1 : -1) * 75;
                }
                sfx.playClick(2);
              }
            }
          }

          // Ball-to-ball elastic collision
          const bdx = b1.x - b0.x;
          const bdy = b1.y - b0.y;
          const bdist = Math.hypot(bdx, bdy);
          const minD = b0.r + b1.r;
          if (bdist > 0 && bdist < minD) {
            const nx = bdx / bdist;
            const ny = bdy / bdist;
            const overlap = (minD - bdist) * 0.5;
            b0.x -= nx * overlap;
            b0.y -= ny * overlap;
            b1.x += nx * overlap;
            b1.y += ny * overlap;
            const dvx = b0.vx - b1.vx;
            const dvy = b0.vy - b1.vy;
            const dot = dvx * nx + dvy * ny;
            if (dot > 0) {
              b0.vx -= dot * nx;
              b0.vy -= dot * ny;
              b1.vx += dot * nx;
              b1.vy += dot * ny;
            }
          }

          for (const b of d.balls) {
            if (b.y >= cH - 36 - b.r) {
              if (b.id === 'rival') {
                if (d.rivalSrc) {
                  onPinballRivalWin(d.rivalSrc as string);
                } else {
                  onShowToast(
                    '⚡ ¡Rival Ganó el Duelo!',
                    'La bola rival llegó primero (sin foto rival cargada).',
                    'purple',
                  );
                }
              } else {
                onShowToast(
                  '🏆 ¡Tu Avatar Ganó!',
                  'Tu bola llegó primero a la meta.',
                  'cyan',
                );
              }
              finishSuccess();
              return;
            }
          }
        }

        for (const b of d.balls) {
          const mediaObj = b.id === 'rival' ? d.rivalImg : avatarRef.current;
          drawAvatarCircle(
            c,
            b.x,
            b.y,
            b.r,
            mediaObj,
            b.color,
            b.id === 'player' ? 'TÚ' : 'VS',
          );
        }
      } else if (t === 'geo_dash') {
        const groundY = cH - 55;
        d.dist += 275 * dt;
        if (!d.grounded) {
          d.vy += 1180 * dt;
          d.playerY += d.vy * dt;
          d.rot += 6 * dt;
          if (d.playerY >= groundY - 22) {
            d.playerY = groundY - 22;
            d.vy = 0;
            d.grounded = true;
            d.rot = 0;
          }
        }

        c.fillStyle = '#00f3ff';
        c.fillRect(0, groundY, cW, 4);

        for (const sx of d.spikes) {
          const screenX = sx - d.dist + 110;
          c.fillStyle = '#ff2a55';
          c.beginPath();
          c.moveTo(screenX - 14, groundY);
          c.lineTo(screenX, groundY - 28);
          c.lineTo(screenX + 14, groundY);
          c.fill();

          if (Math.abs(screenX - 110) < 20 && d.playerY > groundY - 38) {
            d.dist = 0;
            sfx.playAlert();
            break;
          }
        }

        const portalX = d.goalDist - d.dist + 110;
        c.fillStyle = '#10b981';
        c.fillRect(portalX, groundY - 90, 22, 90);
        if (portalX <= 120) {
          finishSuccess();
          return;
        }

        c.save();
        c.translate(110, d.playerY);
        c.rotate(d.rot);
        drawAvatarCircle(c, 0, 0, 22, avatarRef.current, '#00f3ff', 'GD');
        c.restore();

        const pct = Math.min(100, Math.round((d.dist / d.goalDist) * 100));
        c.fillStyle = '#94a3b8';
        c.font = 'bold 12px Orbitron';
        c.textAlign = 'left';
        c.fillText(`PROGRESO: ${pct}%`, 16, 24);
      } else if (t === 'spike_circuit') {
        const b = d.ball;
        const prevY = b.y;
        if (d.pauseTimer > 0) {
          d.pauseTimer -= dt;
        } else {
          b.vy += 420 * dt;
          b.x += b.vx * dt;
          b.y += b.vy * dt;
        }

        c.lineWidth = 6;
        d.ramps.forEach(
          (r: { x1: number; y1: number; x2: number; y2: number }, idx: number) => {
            const rampDisabled = d.trampolineUsed && idx === 1;
            c.strokeStyle = rampDisabled ? 'rgba(0, 243, 255, 0.3)' : '#00f3ff';
            c.beginPath();
            c.moveTo(r.x1, r.y1);
            c.lineTo(r.x2, r.y2);
            c.stroke();
            if (rampDisabled) return;

            const minX = Math.min(r.x1, r.x2);
            const maxX = Math.max(r.x1, r.x2);
            if (b.x >= minX && b.x <= maxX) {
              const prog = (b.x - r.x1) / (r.x2 - r.x1);
              const ry = r.y1 + prog * (r.y2 - r.y1);
              if (b.vy >= 0 && prevY + b.r <= ry + 12 && b.y + b.r >= ry - 4) {
                b.y = ry - b.r;
                b.vy = -50;
                b.vx = r.x2 > r.x1 ? cW * 0.3 : -cW * 0.3;
                if (!d.pausedDone && idx === 1 && prog > 0.55) {
                  d.pausedDone = true;
                  d.pauseTimer = 0.65;
                }
              }
            }
          },
        );

        if (b.x > cW - 25) {
          b.x = cW - 25;
          b.vx = -Math.abs(b.vx) * 0.75;
        }
        if (b.x < 25) {
          b.x = 25;
          b.vx = Math.abs(b.vx) * 0.75;
        }

        const tr = d.trampoline;
        c.fillStyle = d.trampolineUsed ? '#6b21a8' : '#a855f7';
        c.fillRect(tr.x, tr.y, tr.w, 12);
        if (
          !d.trampolineUsed &&
          b.vy > 0 &&
          b.x > tr.x &&
          b.x < tr.x + tr.w &&
          prevY + b.r <= tr.y + 14 &&
          b.y + b.r >= tr.y - 4
        ) {
          d.trampolineUsed = true;
          b.y = tr.y - b.r;
          b.vy = -Math.sqrt(2 * 420 * (cH * 0.34));
          b.vx = cW * 0.52;
          sfx.playBuy();
        }

        c.fillStyle = '#ff2a55';
        for (let sx = 15; sx < cW; sx += 28) {
          c.beginPath();
          c.moveTo(sx - 12, cH);
          c.lineTo(sx, cH - 30);
          c.lineTo(sx + 12, cH);
          c.fill();
        }

        drawAvatarCircle(c, b.x, b.y, b.r, avatarRef.current, '#ffd166', '⚙️');

        if (b.y + b.r >= cH - 28) {
          sfx.playExplosion();
          finishSuccess();
          return;
        }
      } else if (t === 'flappy') {
        d.vy += 760 * dt;
        d.y += d.vy * dt;
        if (d.y < 18) {
          d.y = 18;
          d.vy = 0;
        }

        let crashed = d.y > cH - 18;

        for (const p of d.pipes) {
          p.x -= 190 * dt;
          c.fillStyle = '#ff2a55';
          c.fillRect(p.x, 0, 38, p.gapY - p.gapH / 2);
          c.fillRect(p.x, p.gapY + p.gapH / 2, 38, cH);

          if (p.x < 116 && p.x + 38 > 84) {
            if (d.y - 16 < p.gapY - p.gapH / 2 || d.y + 16 > p.gapY + p.gapH / 2) {
              crashed = true;
            }
          }
          if (!crashed && !p.scored && p.x + 38 < 84) {
            p.scored = true;
            d.passed++;
            sfx.playBuy();
            if (d.passed >= d.targetPipes) {
              finishSuccess();
              return;
            }
          }
        }

        if (crashed) {
          sfx.playAlert();
          d.y = cH / 2;
          d.vy = 0;
          d.passed = 0;
          d.pipes = initFlappyPipes();
        }

        drawAvatarCircle(c, 100, d.y, 18, avatarRef.current, '#00f3ff', '🪽');
        c.fillStyle = '#94a3b8';
        c.font = 'bold 12px Orbitron';
        c.textAlign = 'left';
        c.fillText(`COMPUERTAS: ${d.passed} / ${d.targetPipes}`, 16, 24);
      } else if (t === 'arkanoid') {
        if (cur.keys.ArrowLeft || cur.keys.KeyA) cur.pointer.x -= 430 * dt;
        if (cur.keys.ArrowRight || cur.keys.KeyD) cur.pointer.x += 430 * dt;
        cur.pointer.x = Math.max(52, Math.min(cW - 52, cur.pointer.x));
        d.paddleX = cur.pointer.x;

        const b = d.ball;
        b.x += b.vx * dt;
        b.y += b.vy * dt;
        if (b.x < b.r) {
          b.x = b.r;
          b.vx = Math.abs(b.vx);
        }
        if (b.x > cW - b.r) {
          b.x = cW - b.r;
          b.vx = -Math.abs(b.vx);
        }
        if (b.y < b.r) {
          b.y = b.r;
          b.vy = Math.abs(b.vy);
        }
        if (b.vy > 0 && b.y > cH - 32 - b.r && b.y < cH - 18 && Math.abs(b.x - d.paddleX) < 58) {
          b.vy = -Math.abs(b.vy);
          b.vx += (b.x - d.paddleX) * 2.2;
          b.vx = Math.max(-360, Math.min(360, b.vx));
          sfx.playClick(2);
        }
        if (b.y > cH + 15) {
          b.x = cW / 2;
          b.y = cH / 2;
          b.vy = -240;
        }

        let rem = 0;
        for (const br of d.bricks) {
          if (!br.alive) continue;
          rem++;
          c.fillStyle = '#a855f7';
          c.fillRect(br.x, br.y, br.w, br.h);
          if (
            b.x + b.r > br.x &&
            b.x - b.r < br.x + br.w &&
            b.y + b.r > br.y &&
            b.y - b.r < br.y + br.h
          ) {
            br.alive = false;
            b.vy *= -1;
            sfx.playCrit();
          }
        }
        if (rem === 0) {
          finishSuccess();
          return;
        }

        c.fillStyle = '#00f3ff';
        c.fillRect(d.paddleX - 52, cH - 28, 104, 12);
        drawAvatarCircle(c, b.x, b.y, b.r, avatarRef.current, '#ffd166', '⚡');
      } else if (t === 'meteor_dodge') {
        if (cur.keys.ArrowLeft || cur.keys.KeyA) cur.pointer.x -= 400 * dt;
        if (cur.keys.ArrowRight || cur.keys.KeyD) cur.pointer.x += 400 * dt;
        cur.pointer.x = Math.max(22, Math.min(cW - 22, cur.pointer.x));
        d.px = cur.pointer.x;

        d.spawnT += dt;
        if (d.spawnT > 0.24) {
          d.spawnT = 0;
          d.meteors.push({
            x: Math.random() * cW,
            y: -20,
            vy: 260 + Math.random() * 140,
            r: 16,
          });
        }

        for (let i = d.meteors.length - 1; i >= 0; i--) {
          const m = d.meteors[i];
          m.y += m.vy * dt;
          if (m.y > cH + 30) {
            d.meteors.splice(i, 1);
            continue;
          }
          c.fillStyle = '#ff2a55';
          c.beginPath();
          c.arc(m.x, m.y, m.r, 0, Math.PI * 2);
          c.fill();
          if (Math.hypot(m.x - d.px, m.y - (cH - 42)) < m.r + 18) {
            cur.startTime = performance.now();
            cur.elapsed = 0;
            d.meteors = [];
            sfx.playAlert();
            break;
          }
        }

        drawAvatarCircle(c, d.px, cH - 42, 20, avatarRef.current, '#00f3ff', '☄️');
        c.fillStyle = '#94a3b8';
        c.font = 'bold 12px Orbitron';
        c.textAlign = 'left';
        c.fillText(
          `SUPERVIVENCIA: ${cur.elapsed.toFixed(1)}s / ${d.surviveTarget}s`,
          16,
          24,
        );
        if (cur.elapsed >= d.surviveTarget) {
          finishSuccess();
          return;
        }
      } else if (t === 'target_shoot') {
        d.tx += d.vx * dt;
        d.ty += d.vy * dt;
        if (d.tx < d.tr + 16) {
          d.tx = d.tr + 16;
          d.vx = Math.abs(d.vx);
        }
        if (d.tx > cW - d.tr - 16) {
          d.tx = cW - d.tr - 16;
          d.vx = -Math.abs(d.vx);
        }
        if (d.ty < d.tr + 34) {
          d.ty = d.tr + 34;
          d.vy = Math.abs(d.vy);
        }
        if (d.ty > cH - d.tr - 16) {
          d.ty = cH - d.tr - 16;
          d.vy = -Math.abs(d.vy);
        }
        drawAvatarCircle(
          c,
          d.tx,
          d.ty,
          d.tr,
          avatarRef.current,
          '#ff2a55',
          `${d.hits}/${d.goal}`,
        );
        c.fillStyle = '#94a3b8';
        c.font = 'bold 12px Orbitron';
        c.textAlign = 'left';
        c.fillText(`OBJETIVOS: ${d.hits} / ${d.goal}`, 16, 24);
      } else if (t === 'memory') {
        const cols = 4;
        const rows = 3;
        const cw = (cW - 80) / cols;
        const ch = (cH - 60) / rows;
        d.deck.forEach(
          (card: { icon: string; flipped: boolean; matched: boolean }, idx: number) => {
            const col = idx % cols;
            const row = Math.floor(idx / cols);
            const x = 40 + col * cw + 6;
            const y = 30 + row * ch + 6;
            c.fillStyle = card.matched ? '#065f46' : card.flipped ? '#1e293b' : '#0f172a';
            c.strokeStyle = card.matched ? '#10b981' : '#00f3ff';
            c.lineWidth = 2;
            c.fillRect(x, y, cw - 12, ch - 12);
            c.strokeRect(x, y, cw - 12, ch - 12);
            if (card.flipped || card.matched) {
              c.font = '28px sans-serif';
              c.textAlign = 'center';
              c.textBaseline = 'middle';
              c.fillStyle = '#ffffff';
              c.fillText(card.icon, x + (cw - 12) / 2, y + (ch - 12) / 2);
            }
          },
        );
      } else if (t === 'snake') {
        d.stepT += dt;
        const cols = Math.floor(cW / d.grid);
        const rows = Math.floor(cH / d.grid);
        if (d.stepT >= 0.13) {
          d.stepT = 0;
          d.dir = { ...d.nextDir };
          const head = {
            x: (d.snake[0].x + d.dir.x + cols) % cols,
            y: (d.snake[0].y + d.dir.y + rows) % rows,
          };
          const willEat = head.x === d.food.x && head.y === d.food.y;
          const bodyToCheck = willEat ? d.snake : d.snake.slice(0, -1);
          const selfHit = bodyToCheck.some(
            (seg: { x: number; y: number }) => seg.x === head.x && seg.y === head.y,
          );
          if (selfHit) {
            sfx.playAlert();
            d.snake = [
              { x: Math.min(8, cols - 2), y: Math.floor(rows / 2) },
              { x: Math.min(7, cols - 3), y: Math.floor(rows / 2) },
            ];
            d.dir = { x: 1, y: 0 };
            d.nextDir = { x: 1, y: 0 };
            d.score = 0;
            d.food = spawnSnakeFood(cols, rows, d.snake);
          } else {
            d.snake.unshift(head);
            if (willEat) {
              d.score++;
              sfx.playBuy();
              if (d.score >= d.goal) {
                finishSuccess();
                return;
              }
              d.food = spawnSnakeFood(cols, rows, d.snake);
            } else {
              d.snake.pop();
            }
          }
        }

        c.fillStyle = '#ffd166';
        c.beginPath();
        c.arc(d.food.x * d.grid + 12, d.food.y * d.grid + 12, 9, 0, Math.PI * 2);
        c.fill();

        d.snake.forEach((seg: { x: number; y: number }, idx: number) => {
          if (idx === 0) {
            drawAvatarCircle(
              c,
              seg.x * d.grid + 12,
              seg.y * d.grid + 12,
              12,
              avatarRef.current,
              '#00f3ff',
              '🐍',
            );
          } else {
            c.fillStyle = '#06d6a0';
            c.fillRect(seg.x * d.grid + 3, seg.y * d.grid + 3, 18, 18);
          }
        });

        c.fillStyle = '#94a3b8';
        c.font = 'bold 12px Orbitron';
        c.textAlign = 'left';
        c.fillText(`NÚCLEOS: ${d.score} / ${d.goal}`, 16, 22);
      } else if (t === 'simon') {
        if (d.showing) {
          d.showTimer += dt;
          if (d.gapPhase) {
            if (d.showTimer >= 0.16) {
              d.showTimer = 0;
              if (d.showIdx < d.step) {
                d.gapPhase = false;
                d.activePad = d.seq[d.showIdx];
                sfx.playClick(d.activePad + 2);
                d.showIdx++;
              } else {
                d.activePad = -1;
                d.showing = false;
              }
            }
          } else if (d.showTimer >= 0.45) {
            d.showTimer = 0;
            d.activePad = -1;
            d.gapPhase = true;
          }
        }

        const colors = ['#00f3ff', '#ff2a55', '#10b981', '#ffd166'];
        for (let i = 0; i < 4; i++) {
          const x = (i % 2) * (cW / 2) + 20;
          const y = Math.floor(i / 2) * (cH / 2) + 20;
          c.fillStyle = colors[i];
          c.globalAlpha = d.activePad === i ? 1.0 : 0.25;
          c.fillRect(x, y, cW / 2 - 40, cH / 2 - 40);
        }
        c.globalAlpha = 1;
        c.fillStyle = '#e2e8f0';
        c.font = 'bold 12px Orbitron';
        c.textAlign = 'center';
        c.fillText(
          d.showing
            ? `OBSERVA LA SECUENCIA (${d.step}/${d.seq.length})`
            : `TU TURNO (${d.userIdx}/${d.step})`,
          cW / 2,
          cH / 2,
        );
      } else if (t === 'doodle_jump') {
        if (cur.keys.ArrowLeft || cur.keys.KeyA) cur.pointer.x -= 400 * dt;
        if (cur.keys.ArrowRight || cur.keys.KeyD) cur.pointer.x += 400 * dt;
        cur.pointer.x = Math.max(18, Math.min(cW - 18, cur.pointer.x));

        d.px += (cur.pointer.x - d.px) * 10 * dt;
        d.vy += 680 * dt;
        d.py += d.vy * dt;

        if (d.py < cH * 0.4 && d.vy < 0) {
          const diff = cH * 0.4 - d.py;
          d.py = cH * 0.4;
          d.climbed += diff;
          for (const p of d.plats) {
            p.y += diff;
            if (p.y > cH) {
              p.y = 0;
              p.x = Math.random() * (cW - 90);
            }
          }
        }

        if (d.py > cH + 24) {
          sfx.playAlert();
          d.px = cW / 2;
          d.py = cH - 80;
          d.vy = -380;
          d.climbed = 0;
          d.plats = initDoodlePlats();
        }

        for (const p of d.plats) {
          c.fillStyle = '#06d6a0';
          c.fillRect(p.x, p.y, p.w, 10);
          if (
            d.vy > 0 &&
            d.px > p.x - 12 &&
            d.px < p.x + p.w + 12 &&
            Math.abs(d.py + 18 - p.y) < 14
          ) {
            d.vy = -410;
            sfx.playClick(2);
          }
        }

        drawAvatarCircle(c, d.px, d.py, 18, avatarRef.current, '#00f3ff', '🚀');
        const pct = Math.min(100, Math.round((d.climbed / d.goalClimb) * 100));
        c.fillStyle = '#94a3b8';
        c.font = 'bold 12px Orbitron';
        c.textAlign = 'left';
        c.fillText(`ALTURA: ${pct}%`, 16, 24);
        if (d.climbed >= d.goalClimb) {
          finishSuccess();
          return;
        }
      } else if (t === 'bomb_defuse') {
        c.fillStyle = '#00f3ff';
        c.font = 'bold 34px Orbitron';
        c.textAlign = 'center';
        c.fillText(
          (d.guess as string).padEnd(4, '_').split('').join(' '),
          cW / 2,
          cH * 0.45,
        );
        c.fillStyle = '#ffd166';
        c.font = '15px sans-serif';
        c.fillText(d.hint, cW / 2, cH * 0.65);
      } else if (t === 'pong') {
        if (cur.keys.ArrowUp || cur.keys.KeyW) cur.pointer.y -= 390 * dt;
        if (cur.keys.ArrowDown || cur.keys.KeyS) cur.pointer.y += 390 * dt;
        cur.pointer.y = Math.max(42, Math.min(cH - 42, cur.pointer.y));

        d.py = cur.pointer.y;
        d.aiY += (d.by - d.aiY) * 4.5 * dt;
        d.bx += d.vx * dt;
        d.by += d.vy * dt;

        if (d.by < 15) {
          d.by = 15;
          d.vy = Math.abs(d.vy);
        }
        if (d.by > cH - 15) {
          d.by = cH - 15;
          d.vy = -Math.abs(d.vy);
        }

        if (d.vx < 0 && d.bx <= 45 && d.bx >= 20 && Math.abs(d.by - d.py) < 50) {
          d.bx = 46;
          d.vx = Math.min(540, Math.abs(d.vx) * 1.06);
          d.vy += (d.by - d.py) * 2.2;
          sfx.playClick(2);
        }
        if (d.vx > 0 && d.bx >= cW - 45 && d.bx <= cW - 20 && Math.abs(d.by - d.aiY) < 50) {
          d.bx = cW - 46;
          d.vx = -Math.min(540, Math.abs(d.vx) * 1.03);
          sfx.playClick(1);
        }

        if (d.bx > cW) {
          d.score++;
          sfx.playBuy();
          if (d.score >= d.goal) {
            finishSuccess();
            return;
          }
          d.bx = cW / 2;
          d.by = cH / 2;
          d.vx = -265;
          d.vy = (Math.random() > 0.5 ? 1 : -1) * 150;
        }
        if (d.bx < 0) {
          d.bx = cW / 2;
          d.by = cH / 2;
          d.vx = 265;
          d.vy = (Math.random() > 0.5 ? 1 : -1) * 150;
        }

        c.fillStyle = '#00f3ff';
        c.fillRect(18, d.py - 42, 12, 84);
        c.fillStyle = '#ff2a55';
        c.fillRect(cW - 30, d.aiY - 42, 12, 84);
        drawAvatarCircle(c, d.bx, d.by, 15, avatarRef.current, '#ffd166', `${d.score}`);
        c.fillStyle = '#94a3b8';
        c.font = 'bold 12px Orbitron';
        c.textAlign = 'center';
        c.fillText(`GOLES: ${d.score} / ${d.goal}`, cW / 2, 24);
      } else if (t === 'maze') {
        let targetX = cur.pointer.x;
        let targetY = cur.pointer.y;
        const kSpd = 280 * dt;
        if (cur.keys.ArrowLeft || cur.keys.KeyA) {
          cur.pointer.x = Math.max(18, d.px - kSpd);
          targetX = cur.pointer.x;
        }
        if (cur.keys.ArrowRight || cur.keys.KeyD) {
          cur.pointer.x = Math.min(cW - 18, d.px + kSpd);
          targetX = cur.pointer.x;
        }
        if (cur.keys.ArrowUp || cur.keys.KeyW) {
          cur.pointer.y = Math.max(18, d.py - kSpd);
          targetY = cur.pointer.y;
        }
        if (cur.keys.ArrowDown || cur.keys.KeyS) {
          cur.pointer.y = Math.min(cH - 18, d.py + kSpd);
          targetY = cur.pointer.y;
        }

        const steps = 5;
        const stepX = ((targetX - d.px) * Math.min(1, 9 * dt)) / steps;
        const stepY = ((targetY - d.py) * Math.min(1, 9 * dt)) / steps;
        let wallHit = false;
        for (let s = 0; s < steps; s++) {
          d.px += stepX;
          d.py += stepY;
          for (const w of d.walls) {
            if (
              d.px + 14 > w.x &&
              d.px - 14 < w.x + w.w &&
              d.py + 14 > w.y &&
              d.py - 14 < w.y + w.h
            ) {
              wallHit = true;
              break;
            }
          }
          if (wallHit) break;
        }
        if (wallHit) {
          d.px = 45;
          d.py = 45;
          cur.pointer.x = 45;
          cur.pointer.y = 45;
          sfx.playAlert();
        }

        c.fillStyle = '#10b981';
        c.fillRect(cW - 55, cH - 55, 40, 40);
        c.fillStyle = '#ff2a55';
        for (const w of d.walls) {
          c.fillRect(w.x, w.y, w.w, w.h);
        }
        drawAvatarCircle(c, d.px, d.py, 15, avatarRef.current, '#00f3ff', '🌀');
        if (d.px > cW - 60 && d.py > cH - 60) {
          finishSuccess();
          return;
        }
      } else if (t === 'invaders') {
        if (cur.keys.ArrowLeft || cur.keys.KeyA) cur.pointer.x -= 400 * dt;
        if (cur.keys.ArrowRight || cur.keys.KeyD) cur.pointer.x += 400 * dt;
        cur.pointer.x = Math.max(20, Math.min(cW - 20, cur.pointer.x));
        d.px = cur.pointer.x;

        d.fireT += dt;
        if (d.fireT > 0.25) {
          d.fireT = 0;
          d.bullets.push({ x: d.px, y: cH - 48 });
        }

        for (let i = d.bullets.length - 1; i >= 0; i--) {
          const b = d.bullets[i];
          b.y -= 440 * dt;
          if (b.y < -15) {
            d.bullets.splice(i, 1);
            continue;
          }
          c.fillStyle = '#00f3ff';
          c.fillRect(b.x - 2, b.y, 4, 12);
        }

        let hitEdge = false;
        let alive = 0;
        for (const en of d.enemies) {
          if (!en.alive) continue;
          alive++;
          en.x += d.dir * 85 * dt;
          if (en.x >= cW - 28 || en.x <= 28) hitEdge = true;
          c.fillStyle = '#ff2a55';
          c.fillRect(en.x - 16, en.y - 12, 32, 24);

          for (let i = d.bullets.length - 1; i >= 0; i--) {
            const b = d.bullets[i];
            if (Math.abs(b.x - en.x) < 18 && Math.abs(b.y - en.y) < 16) {
              en.alive = false;
              d.bullets.splice(i, 1);
              sfx.playCrit();
              break;
            }
          }
        }
        if (hitEdge) {
          d.dir *= -1;
          for (const en of d.enemies) {
            en.x = Math.max(29, Math.min(cW - 29, en.x));
          }
        }
        if (alive === 0) {
          finishSuccess();
          return;
        }
        drawAvatarCircle(c, d.px, cH - 35, 18, avatarRef.current, '#00f3ff', '👾');
      } else if (t === 'whac_node') {
        d.timer += dt;
        if (d.timer > 0.85) {
          d.timer = 0;
          d.activeHole = Math.floor(Math.random() * 9);
        }
        const cols = 3;
        const rows = 3;
        const cw = cW / cols;
        const ch = cH / rows;
        for (let i = 0; i < 9; i++) {
          const cx = (i % cols) * cw + cw / 2;
          const cy = Math.floor(i / cols) * ch + ch / 2;
          c.strokeStyle = '#334155';
          c.lineWidth = 3;
          c.beginPath();
          c.arc(cx, cy, 32, 0, Math.PI * 2);
          c.stroke();
          if (i === d.activeHole) {
            drawAvatarCircle(c, cx, cy, 28, avatarRef.current, '#ffd166', '⚡');
          }
        }
        c.fillStyle = '#94a3b8';
        c.font = 'bold 12px Orbitron';
        c.textAlign = 'left';
        c.fillText(`NODOS: ${d.hits} / ${d.goal}`, 16, 22);
      } else if (t === 'gravity_hold') {
        const thrust =
          cur.pointer.down || cur.keys.Space || cur.keys.ArrowUp || cur.keys.KeyW;
        d.zoneY += d.zoneDir * 85 * dt;
        if (d.zoneY < 70) {
          d.zoneY = 70;
          d.zoneDir = 1;
        }
        if (d.zoneY > cH - 70) {
          d.zoneY = cH - 70;
          d.zoneDir = -1;
        }
        d.vy += (thrust ? -520 : 380) * dt;
        d.py = Math.max(20, Math.min(cH - 20, d.py + d.vy * dt));
        if (d.py <= 20 || d.py >= cH - 20) d.vy = 0;

        c.fillStyle = 'rgba(16, 185, 129, 0.25)';
        c.fillRect(0, d.zoneY - 45, cW, 90);
        if (Math.abs(d.py - d.zoneY) < 45) d.holdTime += dt;
        drawAvatarCircle(
          c,
          cW / 2,
          d.py,
          20,
          avatarRef.current,
          '#00f3ff',
          `${d.holdTime.toFixed(1)}s`,
        );
        c.fillStyle = '#94a3b8';
        c.font = 'bold 12px Orbitron';
        c.textAlign = 'left';
        c.fillText(
          `ESTABILIDAD: ${d.holdTime.toFixed(1)}s / ${d.goalHold.toFixed(1)}s`,
          16,
          24,
        );
        if (d.holdTime >= d.goalHold) {
          finishSuccess();
          return;
        }
      } else if (t === 'lane_runner') {
        const laneW = cW / 3;
        [1, 2].forEach((i) => {
          c.strokeStyle = '#1e293b';
          c.beginPath();
          c.moveTo(i * laneW, 0);
          c.lineTo(i * laneW, cH);
          c.stroke();
        });
        for (const o of d.obs) {
          o.y += 330 * dt;
          c.fillStyle = '#ff2a55';
          c.fillRect(o.lane * laneW + 25, o.y, laneW - 50, 26);
          if (o.lane === d.lane && Math.abs(o.y - (cH - 45)) < 26) {
            o.y = -40;
            o.lane = Math.floor(Math.random() * 3);
            d.dodged = 0;
            sfx.playAlert();
          }
          if (o.y > cH) {
            o.y = -40;
            o.lane = Math.floor(Math.random() * 3);
            d.dodged++;
            sfx.playClick(2);
            if (d.dodged >= d.goal) {
              finishSuccess();
              return;
            }
          }
        }
        drawAvatarCircle(
          c,
          d.lane * laneW + laneW / 2,
          cH - 45,
          22,
          avatarRef.current,
          '#00f3ff',
          '🏎️',
        );
        c.fillStyle = '#94a3b8';
        c.font = 'bold 12px Orbitron';
        c.textAlign = 'left';
        c.fillText(`ESQUIVADAS: ${d.dodged} / ${d.goal}`, 16, 24);
      } else if (t === 'boss_omega' || t === 'final_ascend') {
        d.bx += d.vx * dt;
        d.by += d.vy * dt;
        if (d.bx < 60) {
          d.bx = 60;
          d.vx = Math.abs(d.vx);
        }
        if (d.bx > cW - 60) {
          d.bx = cW - 60;
          d.vx = -Math.abs(d.vx);
        }
        if (d.by < 60) {
          d.by = 60;
          d.vy = Math.abs(d.vy);
        }
        if (d.by > cH - 60) {
          d.by = cH - 60;
          d.vy = -Math.abs(d.vy);
        }

        c.fillStyle = '#1e293b';
        c.fillRect(cW * 0.2, 16, cW * 0.6, 14);
        c.fillStyle = '#ff0055';
        c.fillRect(cW * 0.2, 16, cW * 0.6 * (d.hp / d.maxHp), 14);

        drawAvatarCircle(c, d.bx, d.by, 46, avatarRef.current, '#ff0055', `${d.hp}`);
      }

      rafIdRef.current = requestAnimationFrame(stepFrame);
    };

    rafIdRef.current = requestAnimationFrame(stepFrame);

    return () => {
      window.removeEventListener('keydown', onKeyDown);
      window.removeEventListener('keyup', onKeyUp);
      stopLoop();
    };
  }, [
    mode,
    stopLoop,
    finishSuccess,
    handleTap,
    setSnakeDir,
    shiftLane,
    appendDefuseDigit,
    backspaceDefuseDigit,
    clearDefuseDigit,
    onPinballRivalWin,
    onShowToast,
  ]);

  const handleRivalUpload = (e: React.ChangeEvent<HTMLInputElement>) => {
    const file = e.target.files?.[0];
    e.target.value = '';
    const st = mgStateRef.current;
    if (!file || !st || st.def.type !== 'pinball_duel') return;
    const reader = new FileReader();
    reader.onload = (ev) => {
      const src = ev.target?.result;
      if (typeof src !== 'string') return;
      const img = new Image();
      img.onload = () => {
        st.data.rivalImg = img;
        st.data.rivalSrc = src;
        onShowToast(
          '📸 Rival Listo',
          'Foto rival cargada. Pulsa ¡SOLTAR BOLAS!',
          'purple',
        );
      };
      img.src = src;
    };
    reader.readAsDataURL(file);
  };

  const handleStartPinball = () => {
    const st = mgStateRef.current;
    if (!st || st.def.type !== 'pinball_duel') return;
    st.data.released = true;
    st.startTime = performance.now();
    lastTimeRef.current = performance.now();
    setPinballReadyToRelease(false);
  };

  if (mode.view === 'closed') return null;

  const activeDef =
    mode.view === 'play'
      ? MINIGAMES_CATALOG.find((m) => m.lvl === mode.lvl)
      : undefined;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/92 backdrop-blur-xl flex items-center justify-center p-2 sm:p-4">
      <div className="glass-panel max-w-4xl w-full rounded-3xl p-4 sm:p-6 border border-cyan-500/40 max-h-[94vh] flex flex-col">
        {mode.view === 'hub' && (
          <div className="flex flex-col h-full max-h-[85vh]">
            <div className="flex items-center justify-between border-b border-slate-800 pb-3 mb-3">
              <div>
                <h2 className="font-orbitron font-black text-lg sm:text-xl text-cyan-300">
                  🎮 CENTRO DE MINIJUEGOS (20 PRUEBAS)
                </h2>
                <p className="text-xs text-slate-400">
                  Se desbloquean cada 10 niveles. Recompensa completa en el primer éxito;
                  repetición rápida otorga bonus por récord o práctica.
                </p>
              </div>
              <button
                onClick={onClose}
                className="w-8 h-8 rounded-xl bg-slate-800 hover:bg-rose-500/20 text-slate-300 font-bold cursor-pointer"
              >
                ✕
              </button>
            </div>
            <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-2.5 overflow-y-auto pr-1 flex-1">
              {MINIGAMES_CATALOG.map((mg) => {
                const unlocked = isUnlocked(mg.lvl);
                const cleared = completedMinigames.includes(mg.lvl);
                const rec = minigameRecords[mg.lvl];
                return (
                  <div
                    key={mg.lvl}
                    className={`rounded-2xl p-3 border flex flex-col justify-between gap-2 ${
                      unlocked
                        ? 'bg-slate-900/90 border-cyan-500/35'
                        : 'bg-slate-950/60 border-slate-800 opacity-55'
                    }`}
                  >
                    <div>
                      <div className="flex items-center justify-between text-xs mb-1">
                        <span className="font-orbitron font-bold text-cyan-400">
                          NV. {mg.lvl}
                        </span>
                        <span className="text-[10px] text-amber-300">
                          {rec ? `Récord: ${rec}s` : cleared ? 'Completado' : 'Sin completar'}
                        </span>
                      </div>
                      <div className="font-orbitron font-bold text-xs text-white">
                        {mg.icon} {mg.name}
                      </div>
                      <p className="text-[10px] text-slate-400 mt-1 line-clamp-2">
                        {mg.desc}
                      </p>
                    </div>
                    <button
                      onClick={() => unlocked && onLaunch(mg.lvl, true)}
                      disabled={!unlocked}
                      className={`w-full py-1.5 rounded-xl font-orbitron font-bold text-[10px] uppercase tracking-wider ${
                        unlocked
                          ? 'bg-cyan-500/20 hover:bg-cyan-500/35 border border-cyan-400/40 text-cyan-200 cursor-pointer'
                          : 'bg-slate-800 text-slate-500 border border-slate-700 cursor-not-allowed'
                      }`}
                    >
                      {unlocked ? 'Jugar' : `Bloqueado (Nv.${mg.lvl})`}
                    </button>
                  </div>
                );
              })}
            </div>
          </div>
        )}

        {mode.view === 'play' && activeDef && (
          <div className="flex flex-col">
            <div className="flex flex-wrap items-center justify-between gap-2 border-b border-slate-800 pb-3 mb-3">
              <div>
                <div className="text-[10px] font-orbitron uppercase tracking-widest text-amber-400">
                  {mode.isPractice
                    ? `PRÁCTICA NV. ${activeDef.lvl}`
                    : `DESAFÍO NIVEL ${activeDef.lvl}`}
                </div>
                <h2 className="font-orbitron font-black text-lg text-white">
                  {activeDef.icon} {activeDef.name}
                </h2>
                <p className="text-xs text-slate-300">{activeDef.desc}</p>
              </div>
              <div className="flex items-center gap-3">
                <div className="bg-slate-900 border border-cyan-500/40 rounded-xl px-3 py-1.5 text-center">
                  <div className="text-[9px] font-orbitron text-slate-400 uppercase">
                    Tiempo
                  </div>
                  <div
                    ref={timerRef}
                    className="font-orbitron font-black text-base text-cyan-300 tabular-nums"
                  >
                    00.00s
                  </div>
                </div>
                <button
                  onClick={() => {
                    stopLoop();
                    onClose();
                  }}
                  className="px-3 py-2 rounded-xl bg-slate-800 hover:bg-rose-500/30 text-slate-300 text-xs font-orbitron font-bold cursor-pointer"
                >
                  Saltar / Cerrar
                </button>
              </div>
            </div>

            {activeDef.type === 'pinball_duel' && pinballReadyToRelease && (
              <div className="mb-3 bg-slate-900/90 border border-purple-500/40 rounded-2xl p-3 flex flex-wrap items-center justify-between gap-2">
                <div className="text-xs">
                  <span className="font-orbitron font-bold text-purple-300">
                    🎱 DUELO AUTOMÁTICO DE FOTOS:
                  </span>
                  <span className="text-slate-300">
                    {' '}
                    Sube una foto rival (opcional) o suelta las bolas directamente.
                  </span>
                </div>
                <div className="flex items-center gap-2">
                  <label className="cursor-pointer bg-purple-500/20 hover:bg-purple-500/30 border border-purple-400/50 text-purple-200 px-3 py-1.5 rounded-xl font-orbitron font-bold text-[11px]">
                    📸 Foto Rival
                    <input
                      type="file"
                      accept="image/*"
                      onChange={handleRivalUpload}
                      className="hidden"
                    />
                  </label>
                  <button
                    onClick={handleStartPinball}
                    className="bg-gradient-to-r from-cyan-500 to-emerald-500 text-slate-950 px-4 py-1.5 rounded-xl font-orbitron font-black text-xs cursor-pointer"
                  >
                    ¡SOLTAR BOLAS!
                  </button>
                </div>
              </div>
            )}

            <div className="relative w-full aspect-[16/10] max-h-[58vh] bg-slate-950 rounded-2xl border border-slate-800 overflow-hidden flex items-center justify-center">
              <canvas
                id="mg-canvas"
                ref={canvasRef}
                onPointerMove={(e) => {
                  const st = mgStateRef.current;
                  const canvas = canvasRef.current;
                  if (!st || !canvas) return;
                  const r = canvas.getBoundingClientRect();
                  st.pointer.x = ((e.clientX - r.left) / r.width) * canvas.width;
                  st.pointer.y = ((e.clientY - r.top) / r.height) * canvas.height;
                }}
                onPointerDown={(e) => {
                  const st = mgStateRef.current;
                  const canvas = canvasRef.current;
                  if (!st || !canvas) return;
                  const r = canvas.getBoundingClientRect();
                  st.pointer.x = ((e.clientX - r.left) / r.width) * canvas.width;
                  st.pointer.y = ((e.clientY - r.top) / r.height) * canvas.height;
                  st.pointer.down = true;
                  handleTap(st);
                }}
                onPointerUp={() => {
                  if (mgStateRef.current) mgStateRef.current.pointer.down = false;
                }}
                onPointerCancel={() => {
                  if (mgStateRef.current) mgStateRef.current.pointer.down = false;
                }}
                className="w-full h-full cursor-crosshair"
              />
            </div>

            <div className="mt-3 flex flex-wrap items-center justify-between gap-2 text-xs text-slate-400">
              <span>
                Controles: Ratón / Pantalla Táctil / Teclado (Flechas, WASD o Espacio)
              </span>
              <div className="flex gap-2">
                {activeDef.type === 'geo_dash' && (
                  <button
                    onPointerDown={() => mgStateRef.current && handleTap(mgStateRef.current)}
                    className="px-4 py-2 rounded-xl bg-cyan-500 text-slate-950 font-orbitron font-bold text-xs cursor-pointer"
                  >
                    ⬆️ SALTAR (Click / Espacio)
                  </button>
                )}
                {activeDef.type === 'flappy' && (
                  <button
                    onPointerDown={() => mgStateRef.current && handleTap(mgStateRef.current)}
                    className="px-4 py-2 rounded-xl bg-cyan-500 text-slate-950 font-orbitron font-bold text-xs cursor-pointer"
                  >
                    🪽 IMPULSAR
                  </button>
                )}
                {activeDef.type === 'snake' && (
                  <div className="flex gap-1">
                    <button
                      onClick={() => setSnakeDir(0, -1)}
                      className="px-3 py-1.5 bg-slate-800 rounded-lg text-xs cursor-pointer"
                    >
                      ⬆️
                    </button>
                    <button
                      onClick={() => setSnakeDir(0, 1)}
                      className="px-3 py-1.5 bg-slate-800 rounded-lg text-xs cursor-pointer"
                    >
                      ⬇️
                    </button>
                    <button
                      onClick={() => setSnakeDir(-1, 0)}
                      className="px-3 py-1.5 bg-slate-800 rounded-lg text-xs cursor-pointer"
                    >
                      ⬅️
                    </button>
                    <button
                      onClick={() => setSnakeDir(1, 0)}
                      className="px-3 py-1.5 bg-slate-800 rounded-lg text-xs cursor-pointer"
                    >
                      ➡️
                    </button>
                  </div>
                )}
                {activeDef.type === 'bomb_defuse' && (
                  <div className="flex flex-wrap gap-1">
                    {[1, 2, 3, 4, 5, 6, 7, 8, 9, 0].map((n) => (
                      <button
                        key={n}
                        onClick={() => appendDefuseDigit(n)}
                        className="px-2.5 py-1 bg-slate-800 hover:bg-cyan-500/30 rounded font-orbitron text-xs text-white cursor-pointer"
                      >
                        {n}
                      </button>
                    ))}
                    <button
                      onClick={clearDefuseDigit}
                      className="px-2.5 py-1 bg-rose-600/80 rounded font-orbitron text-xs text-white cursor-pointer"
                    >
                      C
                    </button>
                  </div>
                )}
                {activeDef.type === 'lane_runner' && (
                  <div className="flex gap-2">
                    <button
                      onClick={() => shiftLane(-1)}
                      className="px-4 py-1.5 bg-cyan-500 text-slate-950 font-orbitron font-bold rounded-xl text-xs cursor-pointer"
                    >
                      ⬅️ Carril
                    </button>
                    <button
                      onClick={() => shiftLane(1)}
                      className="px-4 py-1.5 bg-cyan-500 text-slate-950 font-orbitron font-bold rounded-xl text-xs cursor-pointer"
                    >
                      Carril ➡️
                    </button>
                  </div>
                )}
              </div>
            </div>
          </div>
        )}
      </div>
    </div>
  );
};
