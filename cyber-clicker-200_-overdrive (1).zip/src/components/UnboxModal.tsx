import React from 'react';
import { DOPAMINE_CHEST_TIERS, TIERS } from '../game/catalogs';
import { UnboxState } from '../game/types';

interface UnboxModalProps {
  unbox: UnboxState | null;
  onHit: (e: React.MouseEvent<HTMLDivElement>) => void;
  onClose: () => void;
}

export const UnboxModal: React.FC<UnboxModalProps> = ({ unbox, onHit, onClose }) => {
  if (!unbox) return null;

  const { kind, tier, hits, maxHits, done, wonRelic, wonSkin, wonDopamine } = unbox;
  const ratio = hits / maxHits;
  const scale = 1 + ratio * 0.16;
  const flashColor = hits % 2 === 1 ? '#ff2a55' : tier.color;

  return (
    <div className="fixed inset-0 z-50 bg-slate-950/92 backdrop-blur-xl flex flex-col items-center justify-center p-4">
      <div
        className="max-w-lg w-full glass-panel rounded-3xl p-6 text-center border-2 relative overflow-hidden"
        style={{ borderColor: tier.color }}
      >
        <div
          className="inline-block px-3 py-1 rounded-full font-orbitron font-black text-xs uppercase tracking-widest border mb-2"
          style={{ color: tier.color, borderColor: tier.color }}
        >
          {kind === 'capsule'
            ? 'CÁPSULA'
            : kind === 'chest'
              ? 'COFRE DOPAMÍNICO'
              : 'BOMBA'}{' '}
          {tier.name.toUpperCase()}
        </div>
        <h2 className="font-orbitron font-black text-xl sm:text-2xl text-white">
          {kind === 'capsule'
            ? '¡ROMPE LA CÁPSULA!'
            : kind === 'chest'
              ? '¡ABRE EL COFRE DOPAMÍNICO!'
              : '¡DETONA LA BOMBA!'}
        </h2>
        <p className="text-xs text-slate-300 mt-1">
          {kind === 'capsule'
            ? 'Haz click repetidamente para agrietar el cristal blindado'
            : kind === 'chest'
              ? 'Haz click repetidamente para liberar el caos en tu pantalla de fondo'
              : 'Haz click repetidamente para sobrecargar el detonador'}
        </p>

        <div className="my-6 flex flex-col items-center justify-center">
          {!done && (
            <div
              key={hits}
              onClick={onHit}
              className="hit-pop cursor-pointer relative w-48 h-48 sm:w-56 sm:h-56 flex items-center justify-center transition-transform active:scale-90"
            >
              {kind === 'capsule' ? (
                <svg
                  viewBox="0 0 200 200"
                  className="w-full h-full"
                  style={{
                    transform: `scale(${scale})`,
                    filter: `drop-shadow(0 0 ${14 + ratio * 25}px ${tier.color})`,
                  }}
                >
                  <defs>
                    <linearGradient id="capGrad" x1="0" y1="0" x2="1" y2="1">
                      <stop offset="0%" stopColor={tier.color} />
                      <stop offset="50%" stopColor="#1e293b" />
                      <stop offset="100%" stopColor={tier.color} />
                    </linearGradient>
                  </defs>
                  <rect
                    x="52"
                    y="20"
                    width="96"
                    height="160"
                    rx="48"
                    fill="url(#capGrad)"
                    stroke="#ffffff"
                    strokeWidth="4"
                  />
                  <circle
                    cx="100"
                    cy="100"
                    r={24 + ratio * 16}
                    fill="#ffffff"
                    opacity={0.35 + ratio * 0.5}
                  />
                  {ratio > 0.15 && (
                    <path d="M100 45 L88 78 L106 105" stroke="#ffffff" strokeWidth="3" fill="none" />
                  )}
                  {ratio > 0.35 && (
                    <path d="M106 105 L125 128 L98 155" stroke="#ffffff" strokeWidth="3.5" fill="none" />
                  )}
                  {ratio > 0.55 && (
                    <path d="M88 78 L65 95 L74 125" stroke="#ffd166" strokeWidth="3" fill="none" />
                  )}
                  {ratio > 0.75 && (
                    <path
                      d="M100 45 L122 68 L138 92 M98 155 L118 172"
                      stroke="#ff2a55"
                      strokeWidth="4"
                      fill="none"
                    />
                  )}
                </svg>
              ) : (
                <svg
                  viewBox="0 0 200 200"
                  className="w-full h-full"
                  style={{
                    transform: `scale(${scale})`,
                    filter: `drop-shadow(0 0 ${14 + ratio * 28}px ${flashColor})`,
                  }}
                >
                  <path
                    d="M128 48 Q152 22 172 34"
                    stroke="#cbd5e1"
                    strokeWidth="5"
                    fill="none"
                    strokeLinecap="round"
                  />
                  <circle cx="172" cy="34" r={6 + ratio * 10} fill="#ffd166" />
                  <circle cx="172" cy="34" r={3 + ratio * 5} fill="#ffffff" />
                  <rect
                    x="82"
                    y="34"
                    width="36"
                    height="20"
                    rx="5"
                    fill="#334155"
                    stroke={tier.color}
                    strokeWidth="3"
                  />
                  <circle
                    cx="100"
                    cy="115"
                    r="64"
                    fill="#0f172a"
                    stroke={tier.color}
                    strokeWidth="5"
                  />
                  <circle
                    cx="100"
                    cy="115"
                    r={26 + ratio * 22}
                    fill={flashColor}
                    opacity={0.35 + ratio * 0.55}
                  />
                  <text
                    x="100"
                    y="123"
                    textAnchor="middle"
                    fill="#ffffff"
                    fontFamily="Orbitron"
                    fontWeight="900"
                    fontSize="22"
                  >
                    ☢️
                  </text>
                </svg>
              )}
              {kind === 'chest' && (
                <svg
                  viewBox="0 0 200 200"
                  className="w-full h-full"
                  style={{
                    transform: `scale(${scale})`,
                    filter: `drop-shadow(0 0 ${14 + ratio * 28}px ${tier.color})`,
                  }}
                >
                  <rect
                    x="30"
                    y="78"
                    width="140"
                    height="92"
                    rx="14"
                    fill="#0f172a"
                    stroke={tier.color}
                    strokeWidth="5"
                  />
                  <path
                    d="M26 78 Q100 24 174 78 Z"
                    fill="#1e293b"
                    stroke={tier.color}
                    strokeWidth="5"
                  />
                  <rect
                    x="86"
                    y="66"
                    width="28"
                    height="36"
                    rx="6"
                    fill="#facc15"
                    stroke="#ffffff"
                    strokeWidth="2.5"
                  />
                  <circle
                    cx="100"
                    cy="128"
                    r={18 + ratio * 16}
                    fill={tier.color}
                    opacity={0.3 + ratio * 0.55}
                  />
                  <text
                    x="100"
                    y="136"
                    textAnchor="middle"
                    fontSize="28"
                  >
                    🎁
                  </text>
                </svg>
              )}
            </div>
          )}

          <div className="w-full max-w-xs mt-4">
            <div className="flex justify-between text-xs font-orbitron mb-1">
              <span className="text-cyan-300">
                {kind === 'capsule'
                  ? 'FRACTURA'
                  : kind === 'chest'
                    ? 'ENERGÍA DOPAMÍNICA'
                    : 'CARGA DE DETONACIÓN'}
              </span>
              <span className="text-white font-bold tabular-nums">
                {hits} / {maxHits}
              </span>
            </div>
            <div className="w-full h-3 bg-slate-900 rounded-full overflow-hidden border border-slate-700 p-0.5">
              <div
                className="h-full rounded-full bg-gradient-to-r from-cyan-400 to-rose-500 transition-all duration-100"
                style={{ width: `${Math.min(100, ratio * 100)}%` }}
              />
            </div>
          </div>
        </div>

        {done && (wonRelic || wonSkin || wonDopamine) && (
          <div className="bg-slate-900/90 rounded-2xl p-4 border border-amber-400/50 animate-fade-in">
            <div className="text-xs font-orbitron uppercase text-amber-300 mb-1">
              {wonRelic
                ? `¡RELIQUIA ${TIERS[wonRelic.tier].name.toUpperCase()} OBTENIDA!`
                : wonDopamine
                  ? `¡ARTÍCULO DOPAMÍNICO ${DOPAMINE_CHEST_TIERS[wonDopamine.chestTier].name.toUpperCase()} ACTIVADO!`
                  : `¡SKIN ${TIERS[wonSkin!.tier].name.toUpperCase()} EQUIPADA!`}
            </div>
            <div className="text-4xl my-2">
              {wonRelic ? wonRelic.icon : wonDopamine ? wonDopamine.icon : '🎨'}
            </div>
            <div className="font-orbitron font-black text-lg text-white">
              {wonRelic ? wonRelic.name : wonDopamine ? wonDopamine.name : wonSkin?.name}
            </div>
            <div className="text-xs font-bold text-emerald-400 mt-1">
              {wonRelic
                ? wonRelic.desc
                : wonDopamine
                  ? wonDopamine.desc
                  : 'Equipada automáticamente en tus objetivos'}
            </div>
            <p className="text-[11px] text-slate-400 mt-1">
              {wonDopamine
                ? 'Activado por defecto • Puedes desactivarlo cuando quieras en Arsenal → 🎛️ Fondo'
                : `Tier: ${TIERS[(wonRelic || wonSkin)!.tier].name}`}
            </p>
            <button
              onClick={onClose}
              className="mt-4 w-full py-2.5 rounded-xl bg-gradient-to-r from-cyan-500 to-blue-600 hover:from-cyan-400 hover:to-blue-500 text-slate-950 font-orbitron font-black text-xs uppercase tracking-wider cursor-pointer"
            >
              Continuar
            </button>
          </div>
        )}
      </div>
    </div>
  );
};
