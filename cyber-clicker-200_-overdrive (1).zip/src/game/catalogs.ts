import {
  DopamineChestTier,
  DopamineItemDef,
  GameState,
  MinigameDef,
  RelicDef,
  SkinDef,
  TierDef,
  UpgradeDef,
} from './types';

export const MAX_LEVEL = 200;
export const MAX_ENERGY = 50_000_000;
export const SAVE_STORAGE_KEY = 'cyber_clicker_overdrive_save';

export const RANKS = [
  { minLvl: 1,   name: 'Novato',         bonus: 0.00, color: 'text-slate-300 border-slate-400/40 bg-slate-500/20' },
  { minLvl: 20,  name: 'Aprendiz',       bonus: 0.08, color: 'text-cyan-300 border-cyan-400/40 bg-cyan-500/20' },
  { minLvl: 40,  name: 'Cazador',        bonus: 0.18, color: 'text-emerald-300 border-emerald-400/40 bg-emerald-500/20' },
  { minLvl: 60,  name: 'Maestro',        bonus: 0.30, color: 'text-blue-300 border-blue-400/40 bg-blue-500/20' },
  { minLvl: 80,  name: 'Élite',          bonus: 0.45, color: 'text-indigo-300 border-indigo-400/40 bg-indigo-500/20' },
  { minLvl: 100, name: 'Cibernético',    bonus: 0.65, color: 'text-purple-300 border-purple-400/40 bg-purple-500/20' },
  { minLvl: 120, name: 'Titán',          bonus: 0.90, color: 'text-pink-300 border-pink-400/40 bg-pink-500/20' },
  { minLvl: 140, name: 'Leyenda',        bonus: 1.25, color: 'text-amber-300 border-amber-400/40 bg-amber-500/20' },
  { minLvl: 160, name: 'Mítico',         bonus: 1.70, color: 'text-orange-300 border-orange-400/40 bg-orange-500/20' },
  { minLvl: 180, name: 'Dios del Click', bonus: 2.30, color: 'text-yellow-300 border-yellow-400/60 bg-yellow-500/25' },
];

export const TIERS: TierDef[] = [
  { id: 0,  name: 'Común',       color: '#94a3b8', costGems: 10,   hits: 4,  minTierDrop: 0,  maxTierDrop: 1 },
  { id: 1,  name: 'Rara',        color: '#38bdf8', costGems: 25,   hits: 5,  minTierDrop: 0,  maxTierDrop: 2 },
  { id: 2,  name: 'Épica',       color: '#a855f7', costGems: 55,   hits: 6,  minTierDrop: 1,  maxTierDrop: 3 },
  { id: 3,  name: 'Legendaria',  color: '#f59e0b', costGems: 110,  hits: 6,  minTierDrop: 2,  maxTierDrop: 4 },
  { id: 4,  name: 'VIP',         color: '#10b981', costGems: 200,  hits: 7,  minTierDrop: 3,  maxTierDrop: 5 },
  { id: 5,  name: 'Mítica',      color: '#ec4899', costGems: 350,  hits: 7,  minTierDrop: 4,  maxTierDrop: 6 },
  { id: 6,  name: 'MAX',         color: '#ef4444', costGems: 600,  hits: 8,  minTierDrop: 5,  maxTierDrop: 7 },
  { id: 7,  name: 'PRO',         color: '#06b6d4', costGems: 1000, hits: 8,  minTierDrop: 6,  maxTierDrop: 8 },
  { id: 8,  name: 'Inigualable', color: '#8b5cf6', costGems: 1750, hits: 9,  minTierDrop: 8,  maxTierDrop: 8 },
  { id: 9,  name: 'Legado',      color: '#eab308', costGems: 3000, hits: 10, minTierDrop: 9,  maxTierDrop: 9 },
  { id: 10, name: 'Final Boss',  color: '#ff0055', costGems: 5500, hits: 12, minTierDrop: 10, maxTierDrop: 10 },
];

export const RELICS_CATALOG: RelicDef[] = [
  { id: 'rel_0_1', tier: 0,  name: 'Chip de Silicio',        icon: '💾', type: 'energy', val: 0.06,  desc: '+6% Energía total' },
  { id: 'rel_0_2', tier: 0,  name: 'Batería Alcalina',       icon: '🔋', type: 'cps',    val: 0.08,  desc: '+8% Producción pasiva' },
  { id: 'rel_0_3', tier: 0,  name: 'Lente Focal',            icon: '🔍', type: 'crit',   val: 0.01,  desc: '+1% Prob. Crítico' },
  { id: 'rel_1_1', tier: 1,  name: 'Prisma de Neón',         icon: '💠', type: 'gems',   val: 0.12,  desc: '+12% Cristales ganados' },
  { id: 'rel_1_2', tier: 1,  name: 'Bobina Tesla',           icon: '🔌', type: 'energy', val: 0.14,  desc: '+14% Energía total' },
  { id: 'rel_1_3', tier: 1,  name: 'Giroscopio Óptico',      icon: '🧭', type: 'cps',    val: 0.16,  desc: '+16% Producción pasiva' },
  { id: 'rel_2_1', tier: 2,  name: 'Condensador de Flujo',   icon: '⚡', type: 'energy', val: 0.25,  desc: '+25% Energía total' },
  { id: 'rel_2_2', tier: 2,  name: 'Guantelete Cinético',    icon: '🦾', type: 'crit',   val: 0.025, desc: '+2.5% Prob. Crítico' },
  { id: 'rel_2_3', tier: 2,  name: 'Reloj de Taquiones',     icon: '⏳', type: 'cps',    val: 0.28,  desc: '+28% Producción pasiva' },
  { id: 'rel_3_1', tier: 3,  name: 'Corazón de Supernova',   icon: '🌟', type: 'energy', val: 0.42,  desc: '+42% Energía total' },
  { id: 'rel_3_2', tier: 3,  name: 'Cáliz de Cristal',       icon: '🏆', type: 'gems',   val: 0.25,  desc: '+25% Cristales ganados' },
  { id: 'rel_3_3', tier: 3,  name: 'Motor de Antimateria',   icon: '⚛️', type: 'cps',    val: 0.48,  desc: '+48% Producción pasiva' },
  { id: 'rel_4_1', tier: 4,  name: 'Tarjeta Negra VIP',      icon: '💳', type: 'gems',   val: 0.40,  desc: '+40% Cristales ganados' },
  { id: 'rel_4_2', tier: 4,  name: 'Diamante Cibernético',   icon: '💎', type: 'energy', val: 0.65,  desc: '+65% Energía total' },
  { id: 'rel_4_3', tier: 4,  name: 'Satélite Privado',       icon: '🛰️', type: 'cps',    val: 0.70,  desc: '+70% Producción pasiva' },
  { id: 'rel_5_1', tier: 5,  name: 'Orbe del Fénix',         icon: '🔥', type: 'energy', val: 0.95,  desc: '+95% Energía total' },
  { id: 'rel_5_2', tier: 5,  name: 'Ojo de la Tormenta',     icon: '🌪️', type: 'crit',   val: 0.04,  desc: '+4% Prob. Crítico' },
  { id: 'rel_5_3', tier: 5,  name: 'Tridente de Plasma',     icon: '🔱', type: 'cps',    val: 1.05,  desc: '+105% Producción pasiva' },
  { id: 'rel_6_1', tier: 6,  name: 'Overclocker MAX-9000',   icon: '🚀', type: 'energy', val: 1.40,  desc: '+140% Energía total' },
  { id: 'rel_6_2', tier: 6,  name: 'Reactor Hiper-MAX',      icon: '☢️', type: 'cps',    val: 1.55,  desc: '+155% Producción pasiva' },
  { id: 'rel_6_3', tier: 6,  name: 'Mira Láser MAX',         icon: '🎯', type: 'crit',   val: 0.05,  desc: '+5% Prob. Crítico' },
  { id: 'rel_7_1', tier: 7,  name: 'Algoritmo PRO-AI',       icon: '🧠', type: 'energy', val: 2.00,  desc: '+200% Energía total' },
  { id: 'rel_7_2', tier: 7,  name: 'Bóveda PRO Cuántica',    icon: '🔐', type: 'gems',   val: 0.65,  desc: '+65% Cristales ganados' },
  { id: 'rel_7_3', tier: 7,  name: 'Enjambre PRO Autónomo',  icon: '🛸', type: 'cps',    val: 2.20,  desc: '+220% Producción pasiva' },
  { id: 'rel_8_1', tier: 8,  name: 'Singularidad Única',     icon: '🕳️', type: 'energy', val: 3.20,  desc: '+320% Energía total' },
  { id: 'rel_8_2', tier: 8,  name: 'Fragmento del Cosmos',   icon: '🌌', type: 'cps',    val: 3.50,  desc: '+350% Producción pasiva' },
  { id: 'rel_8_3', tier: 8,  name: 'Prisma Inigualable',     icon: '🌈', type: 'gems',   val: 1.00,  desc: '+100% Cristales ganados' },
  { id: 'rel_9_1', tier: 9,  name: 'Corona del Fundador',    icon: '👑', type: 'energy', val: 5.00,  desc: '+500% Energía total' },
  { id: 'rel_9_2', tier: 9,  name: 'Códice Eterno',          icon: '📜', type: 'cps',    val: 5.50,  desc: '+550% Producción pasiva' },
  { id: 'rel_9_3', tier: 9,  name: 'Cetro del Legado',       icon: '🪄', type: 'crit',   val: 0.08,  desc: '+8% Prob. Crítico' },
  { id: 'rel_10_1', tier: 10, name: 'Núcleo Final Boss',     icon: '👹', type: 'energy', val: 8.50,  desc: '+850% Energía total' },
  { id: 'rel_10_2', tier: 10, name: 'Trono del Overdrive',   icon: '⚔️', type: 'cps',    val: 9.00,  desc: '+900% Producción pasiva' },
  { id: 'rel_10_3', tier: 10, name: 'Gema del Infinito',     icon: '☄️', type: 'gems',   val: 1.75,  desc: '+175% Cristales ganados' },
];

export const SKINS_CATALOG: SkinDef[] = [
  { id: 'sk_0_1',  tier: 0,  name: 'Neón Cian',          border: '3px solid #00f3ff', shadow: '0 0 20px #00f3ff', fx: '' },
  { id: 'sk_0_2',  tier: 0,  name: 'Acero Pulido',       border: '3px solid #94a3b8', shadow: '0 0 18px #94a3b8', fx: '' },
  { id: 'sk_0_3',  tier: 0,  name: 'Pulso Verde',        border: '3px solid #22c55e', shadow: '0 0 20px #22c55e', fx: '' },
  { id: 'sk_1_1',  tier: 1,  name: 'Zafiro Eléctrico',   border: '3px solid #38bdf8', shadow: '0 0 24px #38bdf8', fx: '' },
  { id: 'sk_1_2',  tier: 1,  name: 'Cobalto Profundo',   border: '4px dashed #60a5fa', shadow: '0 0 22px #60a5fa', fx: '' },
  { id: 'sk_1_3',  tier: 1,  name: 'Aqua Láser',         border: '3px solid #2dd4bf', shadow: '0 0 24px #2dd4bf', fx: '' },
  { id: 'sk_2_1',  tier: 2,  name: 'Amatista Void',      border: '4px solid #a855f7', shadow: '0 0 28px #a855f7', fx: 'skin-fx-pulse' },
  { id: 'sk_2_2',  tier: 2,  name: 'Orquídea Plasma',     border: '4px double #d946ef', shadow: '0 0 28px #d946ef', fx: '' },
  { id: 'sk_2_3',  tier: 2,  name: 'Nebulosa Violeta',   border: '4px solid #8b5cf6', shadow: '0 0 30px #c084fc', fx: 'skin-fx-pulse' },
  { id: 'sk_3_1',  tier: 3,  name: 'Fuego Solar',        border: '4px solid #f59e0b', shadow: '0 0 32px #f59e0b', fx: 'skin-fx-pulse' },
  { id: 'sk_3_2',  tier: 3,  name: 'Magma Fundido',      border: '4px solid #ea580c', shadow: '0 0 34px #f97316', fx: 'skin-fx-pulse' },
  { id: 'sk_3_3',  tier: 3,  name: 'Aurora Dorada',      border: '4px double #fbbf24', shadow: '0 0 34px #fbbf24', fx: '' },
  { id: 'sk_4_1',  tier: 4,  name: 'Esmeralda VIP',      border: '4px solid #10b981', shadow: '0 0 34px #34d399', fx: 'skin-fx-pulse' },
  { id: 'sk_4_2',  tier: 4,  name: 'Platino Exclusivo',  border: '5px double #e2e8f0', shadow: '0 0 34px #10b981', fx: '' },
  { id: 'sk_4_3',  tier: 4,  name: 'Jade Imperial',      border: '4px solid #059669', shadow: '0 0 36px #6ee7b7', fx: 'skin-fx-pulse' },
  { id: 'sk_5_1',  tier: 5,  name: 'Rosa Cibernético',   border: '4px solid #ec4899', shadow: '0 0 36px #f472b6', fx: 'skin-fx-pulse' },
  { id: 'sk_5_2',  tier: 5,  name: 'Fénix Carmesí',      border: '5px solid #f43f5e', shadow: '0 0 38px #fb7185', fx: 'skin-fx-pulse' },
  { id: 'sk_5_3',  tier: 5,  name: 'Eclipse Mítico',     border: '4px double #db2777', shadow: '0 0 38px #a855f7', fx: 'skin-fx-pulse' },
  { id: 'sk_6_1',  tier: 6,  name: 'Sobrecarga MAX',     border: '5px solid #ef4444', shadow: '0 0 40px #ef4444', fx: 'skin-fx-pulse' },
  { id: 'sk_6_2',  tier: 6,  name: 'Turbina Roja MAX',   border: '5px dashed #dc2626', shadow: '0 0 40px #f87171', fx: 'skin-fx-pulse' },
  { id: 'sk_6_3',  tier: 6,  name: 'Núcleo Crítico MAX', border: '5px double #b91c1c', shadow: '0 0 42px #fca5a5', fx: 'skin-fx-pulse' },
  { id: 'sk_7_1',  tier: 7,  name: 'Holograma PRO',      border: '5px solid #06b6d4', shadow: '0 0 42px #22d3ee', fx: 'skin-fx-pulse' },
  { id: 'sk_7_2',  tier: 7,  name: 'Matriz PRO-X',       border: '5px double #0891b2', shadow: '0 0 42px #67e8f9', fx: 'skin-fx-pulse' },
  { id: 'sk_7_3',  tier: 7,  name: 'Cromo PRO Élite',    border: '5px solid #38bdf8', shadow: '0 0 44px #00f3ff', fx: 'skin-fx-pulse' },
  { id: 'sk_8_1',  tier: 8,  name: 'Prisma Inigualable', border: '5px solid #8b5cf6', shadow: '0 0 45px #8b5cf6', fx: 'skin-fx-rainbow' },
  { id: 'sk_8_2',  tier: 8,  name: 'Galaxia Infinita',   border: '5px double #a78bfa', shadow: '0 0 45px #c4b5fd', fx: 'skin-fx-rainbow' },
  { id: 'sk_8_3',  tier: 8,  name: 'Quásar Inigualable', border: '5px solid #7c3aed', shadow: '0 0 48px #ddd6fe', fx: 'skin-fx-rainbow' },
  { id: 'sk_9_1',  tier: 9,  name: 'Oro del Legado',     border: '6px double #eab308', shadow: '0 0 50px #fde047', fx: 'skin-fx-pulse' },
  { id: 'sk_9_2',  tier: 9,  name: 'Reliquia Ancestral', border: '6px solid #ca8a04', shadow: '0 0 50px #fef08a', fx: 'skin-fx-pulse' },
  { id: 'sk_9_3',  tier: 9,  name: 'Trono Celestial',    border: '6px double #facc15', shadow: '0 0 52px #ffffff', fx: 'skin-fx-pulse' },
  { id: 'sk_10_1', tier: 10, name: 'Aura Final Boss',    border: '6px solid #ff0055', shadow: '0 0 55px #ff0055', fx: 'skin-fx-rainbow' },
  { id: 'sk_10_2', tier: 10, name: 'Apocalipsis Omega',  border: '6px double #ff0055', shadow: '0 0 60px #ff4d88', fx: 'skin-fx-rainbow' },
  { id: 'sk_10_3', tier: 10, name: 'Dios Overdrive',     border: '6px solid #ffffff', shadow: '0 0 65px #ff0055', fx: 'skin-fx-rainbow' },
];

export const UPGRADES_CATALOG: UpgradeDef[] = [
  { id: 'clickPower',  cat: 'active',  name: 'Núcleo de Impacto',      icon: '⚡', desc: '+2 Energía base por click',         baseCost: 15,      mult: 1.40, max: 200 },
  { id: 'critChance',  cat: 'active',  name: 'Sensor de Precisión',    icon: '🎯', desc: '+2% Probabilidad de Golpe Crítico', baseCost: 60,      mult: 1.62, max: 40 },
  { id: 'critDamage',  cat: 'active',  name: 'Sobrecarga Crítica',     icon: '💥', desc: '+0.6x Multiplicador Crítico',       baseCost: 120,     mult: 1.70, max: 50 },
  { id: 'comboMaster', cat: 'active',  name: 'Condensador Racha',      icon: '🔥', desc: '+Combo máximo y duración racha',    baseCost: 150,     mult: 1.75, max: 30 },
  { id: 'magnetSize',  cat: 'active',  name: 'Campo Gravitatorio',     icon: '🧲', desc: '+4px tamaño y frena velocidad',     baseCost: 200,     mult: 1.90, max: 15 },
  { id: 'gemMiner',    cat: 'active',  name: 'Extractor de Cristales', icon: '💎', desc: '+1% prob. de hallar 1💎 al clickar',  baseCost: 1500,    mult: 2.15, max: 15 },
  { id: 'droneScout',  cat: 'passive', name: 'Micro-Dron Recolector',  icon: '🛸', desc: '+3 Energía automática / seg',       baseCost: 40,      mult: 1.36, max: 150 },
  { id: 'laserTurret', cat: 'passive', name: 'Torreta Láser Orbital',  icon: '🔫', desc: '+22 Energía automática / seg',      baseCost: 350,     mult: 1.40, max: 150 },
  { id: 'quantumCore', cat: 'passive', name: 'Reactor Cuántico',       icon: '⚛️', desc: '+160 Energía automática / seg',     baseCost: 3000,    mult: 1.45, max: 150 },
  { id: 'dysonSwarm',  cat: 'passive', name: 'Enjambre de Dyson',      icon: '☀️', desc: '+1,400 Energía automática / seg',   baseCost: 25000,   mult: 1.50, max: 150 },
  { id: 'galaxyForge', cat: 'passive', name: 'Forja Galáctica',        icon: '🌌', desc: '+12,500 Energía automática / seg',  baseCost: 220000,  mult: 1.55, max: 150 },
  { id: 'omegaMatrix', cat: 'passive', name: 'Matriz Omega Overdrive', icon: '👑', desc: '+110,000 Energía automática / seg', baseCost: 2000000, mult: 1.60, max: 150 },
];

export const MINIGAMES_CATALOG: MinigameDef[] = [
  { lvl: 10,  type: 'pinball_duel',  name: 'Duelo Pinball Automático', icon: '🎱', desc: 'Dos bolas (Tu Avatar vs Rival) bajan por obstáculos sin intervención. ¡La ganadora se queda como tu foto!' },
  { lvl: 20,  type: 'geo_dash',      name: 'Cyber Dash',               icon: '🟦', desc: 'Salta con tu avatar sobre pinchos láser al estilo Geometry Dash hasta cruzar el portal.' },
  { lvl: 30,  type: 'spike_circuit', name: 'Circuito Caída a Pinchos', icon: '⚙️', desc: 'Circuito automático de rampas y trampolines hasta caer en los pinchos finales.' },
  { lvl: 40,  type: 'flappy',        name: 'Flappy Cyber',             icon: '🪽', desc: 'Pulsa para impulsar tu avatar entre 6 compuertas láser sin chocar.' },
  { lvl: 50,  type: 'arkanoid',      name: 'Rompebloques Neón',        icon: '🧱', desc: 'Mueve la barra inferior para rebotar la esfera y destruir todos los bloques.' },
  { lvl: 60,  type: 'meteor_dodge',  name: 'Lluvia de Meteoritos',     icon: '☄️', desc: 'Esquiva meteoritos de plasma durante 12 segundos moviéndote izquierda/derecha.' },
  { lvl: 70,  type: 'target_shoot',  name: 'Tiro al Blanco Láser',     icon: '🎯', desc: 'Destruye 12 objetivos móviles haciendo click lo más rápido posible.' },
  { lvl: 80,  type: 'memory',        name: 'Memory Cuántico',          icon: '🃏', desc: 'Encuentra las 6 parejas de símbolos cibernéticos en el menor tiempo.' },
  { lvl: 90,  type: 'snake',         name: 'Serpiente Neón',           icon: '🐍', desc: 'Dirige tu avatar para recolectar 8 núcleos de energía sin chocarte contigo mismo.' },
  { lvl: 100, type: 'simon',         name: 'Simón Dice Cibernético',   icon: '🎛️', desc: 'Memoriza y repite una secuencia luminosa de 5 pasos.' },
  { lvl: 110, type: 'doodle_jump',   name: 'Salto Orbital',            icon: '🚀', desc: 'Rebota de plataforma en plataforma hacia arriba hasta alcanzar la meta.' },
  { lvl: 120, type: 'bomb_defuse',   name: 'Desactivación de Código',  icon: '📟', desc: 'Descifra el código secreto de 4 dígitos con pistas de Mayor/Menor.' },
  { lvl: 130, type: 'pong',          name: 'Pong Turbo IA',            icon: '🏓', desc: 'Marca 3 goles contra la IA usando tu avatar como bola energética.' },
  { lvl: 140, type: 'maze',          name: 'Laberinto Relámpago',      icon: '🌀', desc: 'Guía tu avatar por el laberinto neón hasta el portal verde.' },
  { lvl: 150, type: 'invaders',      name: 'Invasores Espaciales',     icon: '👾', desc: 'Dispara hacia arriba y elimina la escuadra de 12 drones invasores.' },
  { lvl: 160, type: 'whac_node',     name: 'Caza del Nodo Crítico',    icon: '🔨', desc: 'Golpea 12 nodos que emergen en la rejilla antes de que se oculten.' },
  { lvl: 170, type: 'gravity_hold',  name: 'Equilibrio Gravitacional', icon: '⚖️', desc: 'Mantén pulsado para sostener tu avatar dentro de la franja verde durante 8s.' },
  { lvl: 180, type: 'lane_runner',   name: 'Autopista Cuántica',       icon: '🏎️', desc: 'Cambia entre 3 carriles para esquivar 12 barreras a alta velocidad.' },
  { lvl: 190, type: 'boss_omega',    name: 'Jefe: Núcleo Omega',       icon: '👹', desc: 'Golpea al Jefe Omega 22 veces para agotar su barra de vida.' },
  { lvl: 200, type: 'final_ascend',  name: 'Ascensión Suprema Nv.200', icon: '👑', desc: 'Prueba final definitiva: sobrecarga el núcleo maestro 35 veces para el Renacimiento.' },
];

export const DOPAMINE_CHEST_TIERS: DopamineChestTier[] = [
  { id: 0, name: 'Viral',     color: '#22d3ee', costGems: 15, hits: 4 },
  { id: 1, name: 'Caótico',   color: '#c084fc', costGems: 35, hits: 5 },
  { id: 2, name: 'Overdrive', color: '#facc15', costGems: 65, hits: 6 },
];

export const DOPAMINE_CATALOG: DopamineItemDef[] = [
  { id: 'dop_67',        chestTier: 0, name: 'Número 67 Glitch',       icon: '6️⃣', desc: 'Un "67" gigante neón rebota y pulsa en el fondo con destellos cyber.' },
  { id: 'dop_parrot',    chestTier: 0, name: 'Loro Animador',          icon: '🦜', desc: 'Un loro colorido baila en el fondo animándote sin parar.' },
  { id: 'dop_dvd',       chestTier: 0, name: 'Logo Rebote DVD',        icon: '📀', desc: 'El mítico logo flotante rebotando y cambiando de color al tocar los bordes.' },
  { id: 'dop_confetti',  chestTier: 0, name: 'Lluvia de Confeti Neón', icon: '🎊', desc: 'Cascada continua de confeti y destellos festivos tras la bola.' },
  { id: 'dop_towers',    chestTier: 1, name: 'Avión y Torres Cayendo', icon: '✈️', desc: 'Un avión impacta contra dos torres neón haciéndolas colapsar en escombros.' },
  { id: 'dop_nyan',      chestTier: 1, name: 'Gato Arcoíris Espacial', icon: '🌈', desc: 'Un gato cibernético cruza el fondo dejando una estela arcoíris.' },
  { id: 'dop_ufo',       chestTier: 1, name: 'OVNI Rayo Tractor',      icon: '🛸', desc: 'Un platillo volante patrulla el cielo proyectando un rayo de plasma.' },
  { id: 'dop_matrix',    chestTier: 1, name: 'Cascada Matrix',         icon: '🟩', desc: 'Lluvia de código digital cayendo en segundo plano.' },
  { id: 'dop_bomb_2m',   chestTier: 2, name: 'Bomba en el Mapa (2m)',  icon: '💣', desc: 'Cada 2 minutos cae una bomba sobre el mapa con onda expansiva gigante.' },
  { id: 'dop_photo_5m',  chestTier: 2, name: 'Tu Foto Gigante (5m)',   icon: '🖼️', desc: 'Cada 5 minutos aparece en grande la foto que elijas en el fondo.' },
  { id: 'dop_parkour',   chestTier: 2, name: 'Carril Runner Infinito', icon: '🏃', desc: 'Un corredor neón hace parkour infinito en la parte baja del fondo.' },
  { id: 'dop_fireworks', chestTier: 2, name: 'Fuegos Artificiales',     icon: '🎆', desc: 'Explosiones periódicas de fuegos artificiales luminosos en el cielo.' },
];

export function createDefaultState(): GameState {
  return {
    energy: 0,
    totalEnergyEarned: 0,
    gems: 15,
    level: 1,
    rebirths: 0,
    upgrades: {
      clickPower: 0,
      critChance: 0,
      critDamage: 0,
      comboMaster: 0,
      magnetSize: 0,
      gemMiner: 0,
      droneScout: 0,
      laserTurret: 0,
      quantumCore: 0,
      dysonSwarm: 0,
      galaxyForge: 0,
      omegaMatrix: 0,
    },
    relics: [],
    unlockedSkins: ['sk_0_1'],
    equippedSkin: 'sk_0_1',
    unlockedDopamine: [],
    enabledDopamine: [],
    dopaminePhotoSrc: '',
    claimedMilestones: [],
    triggeredMinigameLevels: [],
    completedMinigames: [],
    minigameRecords: {},
    missions: [],
    missionCounter: 0,
    slotMedia: [
      { type: 'default', src: '' },
      { type: 'default', src: '' },
      { type: 'default', src: '' },
      { type: 'default', src: '' },
    ],
    stabilizer: true,
    stats: {
      totalClicks: 0,
      totalCrits: 0,
      maxCombo: 1.0,
      upgradesBought: 0,
      anticheatInfractions: 0,
    },
  };
}

export function loadGameState(): GameState {
  const def = createDefaultState();
  try {
    const raw = localStorage.getItem(SAVE_STORAGE_KEY);
    if (!raw) return def;
    const parsed = JSON.parse(raw) as Partial<GameState>;
    const cleanMedia = (parsed.slotMedia || def.slotMedia).map((m) => {
      if (m && m.type === 'video' && typeof m.src === 'string' && m.src.startsWith('blob:')) {
        return { type: 'default' as const, src: '' };
      }
      return m || { type: 'default' as const, src: '' };
    });
    return {
      ...def,
      ...parsed,
      upgrades: { ...def.upgrades, ...(parsed.upgrades || {}) },
      stats: { ...def.stats, ...(parsed.stats || {}) },
      unlockedDopamine: Array.isArray(parsed.unlockedDopamine) ? parsed.unlockedDopamine : [],
      enabledDopamine: Array.isArray(parsed.enabledDopamine) ? parsed.enabledDopamine : [],
      dopaminePhotoSrc: typeof parsed.dopaminePhotoSrc === 'string' ? parsed.dopaminePhotoSrc : '',
      slotMedia: cleanMedia,
    };
  } catch {
    return def;
  }
}

export function saveGameState(state: GameState) {
  const serializable: GameState = {
    ...state,
    slotMedia: state.slotMedia.map((m) =>
      m.type === 'video' && m.src && m.src.startsWith('blob:')
        ? { type: 'default', src: '' }
        : m,
    ),
  };
  try {
    localStorage.setItem(SAVE_STORAGE_KEY, JSON.stringify(serializable));
  } catch {
    const safeClone: GameState = {
      ...serializable,
      dopaminePhotoSrc:
        serializable.dopaminePhotoSrc.length > 250_000 ? '' : serializable.dopaminePhotoSrc,
      slotMedia: serializable.slotMedia.map((m) =>
        m.src && m.src.length > 250_000 ? { type: 'default', src: '' } : m,
      ),
    };
    try {
      localStorage.setItem(SAVE_STORAGE_KEY, JSON.stringify(safeClone));
    } catch {
      // Ignore quota exceeded
    }
  }
}

export function getRebirthMultiplier(rebirths: number): number {
  return Math.pow(2.5, rebirths);
}

export function getUnlockedSlotCount(rebirths: number): number {
  if (rebirths === 0) return 1;
  if (rebirths === 1) return 2;
  if (rebirths === 2) return 3;
  return 4;
}

/**
 * Curva estrictamente creciente desde Nv.1 (0) -> Nv.2 (10) -> ... -> Nv.200 (50M).
 * Corrige el fallo matemático original donde Nv.2 daba 0 (división por cero en barra XP).
 */
export function getEnergyForLevel(lvl: number): number {
  if (lvl <= 1) return 0;
  if (lvl >= MAX_LEVEL) return MAX_ENERGY;
  const linearBase = 10 * (lvl - 1);
  const expPart = (MAX_ENERGY - 10 * (MAX_LEVEL - 1)) * Math.pow((lvl - 1) / (MAX_LEVEL - 1), 3.8);
  return Math.floor(linearBase + expPart);
}

export function getCurrentRank(lvl: number) {
  let current = RANKS[0];
  for (const r of RANKS) {
    if (lvl >= r.minLvl) current = r;
    else break;
  }
  return current;
}

export function getRelicBonuses(relicIds: string[]) {
  let energyMult = 0;
  let cpsMult = 0;
  let critBonus = 0;
  let gemMult = 0;
  for (const id of relicIds) {
    const r = RELICS_CATALOG.find((x) => x.id === id);
    if (!r) continue;
    if (r.type === 'energy') energyMult += r.val;
    if (r.type === 'cps') cpsMult += r.val;
    if (r.type === 'crit') critBonus += r.val;
    if (r.type === 'gems') gemMult += r.val;
  }
  return { energyMult, cpsMult, critBonus, gemMult };
}

export function getClickStats(state: GameState) {
  const rank = getCurrentRank(state.level);
  const rel = getRelicBonuses(state.relics);
  const rebMult = getRebirthMultiplier(state.rebirths);

  const baseClick =
    1 +
    state.upgrades.clickPower * 2 +
    Math.floor(Math.pow(state.upgrades.clickPower, 1.48));
  const globalMult = (1 + rank.bonus + rel.energyMult) * rebMult;
  const clickValue = Math.max(1, Math.floor(baseClick * globalMult));

  const critChance = Math.min(
    0.9,
    0.05 + state.upgrades.critChance * 0.02 + rel.critBonus,
  );
  const critMultiplier = 2.0 + state.upgrades.critDamage * 0.6;

  return { clickValue, critChance, critMultiplier, globalMult };
}

export function getPassiveCPS(state: GameState): number {
  const rank = getCurrentRank(state.level);
  const rel = getRelicBonuses(state.relics);
  const rebMult = getRebirthMultiplier(state.rebirths);

  const rawCps =
    state.upgrades.droneScout * 3 +
    state.upgrades.laserTurret * 22 +
    state.upgrades.quantumCore * 160 +
    state.upgrades.dysonSwarm * 1400 +
    state.upgrades.galaxyForge * 12500 +
    state.upgrades.omegaMatrix * 110000;

  const totalMult = (1 + rank.bonus + rel.energyMult + rel.cpsMult) * rebMult;
  return Math.floor(rawCps * totalMult);
}

export function getUpgradeCost(upg: UpgradeDef, currentLvl: number): number {
  return Math.floor(upg.baseCost * Math.pow(upg.mult, currentLvl));
}

export function formatNumber(num: number): string {
  if (num < 10_000) return Math.floor(num).toLocaleString('es-ES');
  if (num < 1e6) return (num / 1e3).toFixed(2) + 'K';
  if (num < 1e9) return (num / 1e6).toFixed(2) + 'M';
  if (num < 1e12) return (num / 1e9).toFixed(2) + 'B';
  return (num / 1e12).toFixed(2) + 'T';
}
