class SoundEngine {
  private ctx: AudioContext | null = null;
  public muted = false;

  public init() {
    if (!this.ctx) {
      const AudioCtx =
        window.AudioContext ||
        (window as unknown as { webkitAudioContext?: typeof AudioContext })
          .webkitAudioContext;
      if (AudioCtx) {
        this.ctx = new AudioCtx();
      }
    }
    if (this.ctx && this.ctx.state === 'suspended') {
      this.ctx.resume().catch(() => {});
    }
  }

  public tone(
    freq: number,
    endFreq: number,
    dur: number,
    type: OscillatorType = 'triangle',
    vol = 0.14,
    delay = 0,
  ) {
    if (this.muted) return;
    this.init();
    if (!this.ctx) return;

    const now = this.ctx.currentTime + delay;
    const osc = this.ctx.createOscillator();
    const gain = this.ctx.createGain();
    osc.type = type;
    osc.frequency.setValueAtTime(Math.max(20, freq), now);
    if (endFreq) {
      osc.frequency.exponentialRampToValueAtTime(Math.max(20, endFreq), now + dur);
    }
    gain.gain.setValueAtTime(vol, now);
    gain.gain.exponentialRampToValueAtTime(0.001, now + dur + 0.01);
    osc.connect(gain);
    gain.connect(this.ctx.destination);
    osc.start(now);
    osc.stop(now + dur + 0.02);
  }

  public playClick(combo = 1) {
    const f = 300 + Math.min(combo * 20, 480);
    this.tone(f, f * 1.45, 0.065, 'triangle', 0.13);
  }

  public playCrit() {
    this.tone(520, 1180, 0.16, 'sawtooth', 0.18);
    this.tone(260, 780, 0.16, 'sine', 0.16);
  }

  public playCrack(progress: number) {
    const f = 220 + progress * 550;
    this.tone(f, f * 0.7, 0.09, 'square', 0.16);
  }

  public playFuseTick(progress: number) {
    const f = 450 + progress * 750;
    this.tone(f, f * 1.15, 0.06, 'sawtooth', 0.15);
  }

  public playExplosion() {
    this.tone(160, 35, 0.45, 'sawtooth', 0.28);
    this.tone(90, 28, 0.5, 'square', 0.25);
    this.tone(523.25, 1046.5, 0.3, 'triangle', 0.18, 0.15);
  }

  public playBuy() {
    this.tone(587.33, 587.33, 0.12, 'sine', 0.14, 0);
    this.tone(880, 880, 0.14, 'sine', 0.14, 0.06);
  }

  public playLevelUp() {
    [440, 554.37, 659.25, 880].forEach((f, i) =>
      this.tone(f, f, 0.22, 'triangle', 0.16, i * 0.07),
    );
  }

  public playAlert() {
    for (let i = 0; i < 3; i++) {
      this.tone(190, 130, 0.14, 'sawtooth', 0.22, i * 0.18);
    }
  }
}

export const sfx = new SoundEngine();
