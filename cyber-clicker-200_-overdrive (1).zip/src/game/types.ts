export type MediaType = 'default' | 'image' | 'gif' | 'video';

export interface SlotMedia {
  type: MediaType;
  src: string;
}

export type UpgradeKey =
  | 'clickPower'
  | 'critChance'
  | 'critDamage'
  | 'comboMaster'
  | 'magnetSize'
  | 'gemMiner'
  | 'droneScout'
  | 'laserTurret'
  | 'quantumCore'
  | 'dysonSwarm'
  | 'galaxyForge'
  | 'omegaMatrix';

export interface UpgradeDef {
  id: UpgradeKey;
  cat: 'active' | 'passive';
  name: string;
  icon: string;
  desc: string;
  baseCost: number;
  mult: number;
  max: number;
}

export interface TierDef {
  id: number;
  name: string;
  color: string;
  costGems: number;
  hits: number;
  minTierDrop: number;
  maxTierDrop: number;
}

export interface RelicDef {
  id: string;
  tier: number;
  name: string;
  icon: string;
  type: 'energy' | 'cps' | 'crit' | 'gems';
  val: number;
  desc: string;
}

export interface SkinDef {
  id: string;
  tier: number;
  name: string;
  border: string;
  shadow: string;
  fx: string;
}

export type MinigameType =
  | 'pinball_duel'
  | 'geo_dash'
  | 'spike_circuit'
  | 'flappy'
  | 'arkanoid'
  | 'meteor_dodge'
  | 'target_shoot'
  | 'memory'
  | 'snake'
  | 'simon'
  | 'doodle_jump'
  | 'bomb_defuse'
  | 'pong'
  | 'maze'
  | 'invaders'
  | 'whac_node'
  | 'gravity_hold'
  | 'lane_runner'
  | 'boss_omega'
  | 'final_ascend';

export interface MinigameDef {
  lvl: number;
  type: MinigameType;
  name: string;
  icon: string;
  desc: string;
}

export type MissionType = 'clicks' | 'crits' | 'combo' | 'energy';

export interface Mission {
  id: string;
  type: MissionType;
  title: string;
  target: number;
  progress: number;
  isThreshold: boolean;
  rewardGems: number;
  completed: boolean;
}

export interface GameStats {
  totalClicks: number;
  totalCrits: number;
  maxCombo: number;
  upgradesBought: number;
  anticheatInfractions: number;
}

export interface DopamineItemDef {
  id: string;
  chestTier: number;
  name: string;
  icon: string;
  desc: string;
}

export interface DopamineChestTier {
  id: number;
  name: string;
  color: string;
  costGems: number;
  hits: number;
}

export interface GameState {
  energy: number;
  totalEnergyEarned: number;
  gems: number;
  level: number;
  rebirths: number;
  upgrades: Record<UpgradeKey, number>;
  relics: string[];
  unlockedSkins: string[];
  equippedSkin: string;
  unlockedDopamine: string[];
  enabledDopamine: string[];
  dopaminePhotoSrc: string;
  claimedMilestones: number[];
  triggeredMinigameLevels: number[];
  completedMinigames: number[];
  minigameRecords: Record<number, number>;
  missions: Mission[];
  missionCounter: number;
  slotMedia: SlotMedia[];
  stabilizer: boolean;
  stats: GameStats;
}

export type ToastTheme = 'cyan' | 'purple' | 'gold' | 'rose';

export interface ToastItem {
  id: string;
  title: string;
  subtitle: string;
  theme: ToastTheme;
}

export type DrawerTab =
  | 'upgrades'
  | 'capsules'
  | 'bombs'
  | 'chests'
  | 'dopamine'
  | 'missions'
  | 'relics'
  | 'skins'
  | 'rebirth'
  | 'stats';

export interface UnboxState {
  kind: 'capsule' | 'bomb' | 'chest';
  tier: TierDef;
  hits: number;
  maxHits: number;
  done: boolean;
  wonRelic?: RelicDef;
  wonSkin?: SkinDef;
  wonDopamine?: DopamineItemDef;
}
